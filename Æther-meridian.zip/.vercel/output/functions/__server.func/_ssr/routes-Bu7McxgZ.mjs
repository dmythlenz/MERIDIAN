import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { _ as Copy, a as Sun, b as Brain, c as Orbit, d as Menu, f as Hexagon, g as Download, h as FileText, i as Terminal, l as Moon, m as FolderOpen, o as Settings, p as Globe, r as Trash2, s as RotateCcw, t as X, u as MessageSquarePlus, v as Command, x as ArrowUp, y as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle$1, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as _e } from "../_libs/cmdk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bu7McxgZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function fmtBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(2)} MB`;
}
function fmtUptime(ms) {
	const s = Math.floor(ms / 1e3);
	if (s < 60) return `${s}s`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m ${s % 60}s`;
	return `${Math.floor(m / 60)}h ${m % 60}m`;
}
function safeJsonParse(raw, fallback) {
	if (!raw) return fallback;
	try {
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35 disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-elevated text-fg shadow-[var(--elev-shadow)] hover:bg-surface",
			ghost: "text-muted hover:bg-elevated hover:text-fg",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			default: "h-10 rounded-md px-4 text-sm",
			sm: "h-8 rounded-sm px-3 text-xs",
			lg: "h-11 rounded-lg px-5 text-sm",
			icon: "size-10 rounded-md",
			"icon-sm": "size-8 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function TooltipProvider({ delayDuration = 280, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
var Hash = {
	fnv(s) {
		let h = 2166136261;
		for (let i = 0; i < s.length; i++) {
			h ^= s.charCodeAt(i);
			h = Math.imul(h, 16777619);
		}
		return h >>> 0;
	},
	djb2(s) {
		let h = 5381;
		for (let i = 0; i < s.length; i++) h = (h << 5) + h + s.charCodeAt(i) >>> 0;
		return h;
	},
	h64(s) {
		const t = String(s);
		return this.fnv(t).toString(16).padStart(8, "0") + this.djb2(t).toString(16).padStart(8, "0");
	},
	mix(s) {
		let h1 = -2128831035;
		let h2 = -1640531527;
		for (let i = 0; i < s.length; i++) {
			const c = s.charCodeAt(i);
			h1 = Math.imul(h1 ^ c, 2654435761);
			h1 = h1 ^ h1 >>> 13 | 0;
			h2 = Math.imul(h2 ^ c + 158, 1597334677);
			h2 = h2 ^ h2 >>> 16 | 0;
		}
		return (h1 ^ h2) >>> 0;
	}
};
var KEY$1 = "meridian.wal";
var MAX$1 = 800;
var WriteAheadLog = class {
	entries = [];
	load() {
		this.entries = safeJsonParse(typeof localStorage === "undefined" ? null : localStorage.getItem(KEY$1), []);
	}
	persist() {
		try {
			localStorage.setItem(KEY$1, JSON.stringify(this.entries.slice(-240)));
		} catch {}
	}
	push(op, data) {
		const ts = Date.now();
		const entry = {
			ts,
			op,
			data,
			hash: Hash.h64(op + JSON.stringify(data) + ts)
		};
		this.entries.push(entry);
		if (this.entries.length > MAX$1) this.entries.splice(0, this.entries.length - MAX$1);
		this.persist();
		return entry;
	}
	queryAt(ts) {
		return this.entries.filter((e) => e.ts <= ts);
	}
	clear() {
		this.entries = [];
		try {
			localStorage.removeItem(KEY$1);
		} catch {}
	}
};
var WAL = new WriteAheadLog();
var PRIMES = (() => {
	const p = [];
	const isP = (n) => {
		for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
		return n > 1;
	};
	let n = 2;
	while (p.length < 256) {
		if (isP(n)) p.push(n);
		n++;
	}
	return p.map((x) => BigInt(x));
})();
/** Deterministic 128-bit address for any payload. Fast hash for long strings; prime product for short. */
function projectToInfiniteD(data) {
	const str = typeof data === "string" ? data : JSON.stringify(data);
	if (str.length > 96) {
		let h1 = -2128831035;
		let h2 = -1640531527;
		let h3 = -2048144789;
		let h4 = -1028477387;
		for (let i = 0; i < str.length; i++) {
			const c = str.charCodeAt(i);
			h1 = Math.imul(h1 ^ c, 2654435761);
			h1 = h1 ^ h1 >>> 13 | 0;
			h2 = Math.imul(h2 ^ c + 158, 1597334677);
			h2 = h2 ^ h2 >>> 16 | 0;
			h3 = Math.imul(h3 ^ (c * 31 | 0), 2246822519);
			h3 = h3 ^ h3 >>> 13 | 0;
			h4 = Math.imul(h4 ^ c << 3, 3266489917);
			h4 = h4 ^ h4 >>> 16 | 0;
		}
		return BigInt(h1 >>> 0) << 96n | BigInt(h2 >>> 0) << 64n | BigInt(h3 >>> 0) << 32n | BigInt(h4 >>> 0);
	}
	let addr = 1n;
	for (let i = 0; i < str.length; i++) {
		const p = PRIMES[i % PRIMES.length];
		addr *= p ** BigInt(str.charCodeAt(i) % 16 + 1);
	}
	return addr;
}
function addrKey(data) {
	return projectToInfiniteD(data).toString(16);
}
function fabricCoords(content) {
	const a = Hash.fnv(content);
	const b = Hash.djb2(content);
	return {
		screen: a % 64,
		y: (a >>> 8) % 256,
		x: b % 256,
		dim: (b >>> 10) % 1e3
	};
}
var KEY = "meridian.pixels";
var MAX = 200;
var PixelStore = class {
	items = /* @__PURE__ */ new Map();
	load() {
		const list = safeJsonParse(typeof localStorage === "undefined" ? null : localStorage.getItem(KEY), []);
		this.items = new Map(list.map((p) => [p.key, p]));
	}
	persist() {
		try {
			localStorage.setItem(KEY, JSON.stringify([...this.items.values()].slice(-200)));
		} catch {}
	}
	set(partial) {
		const pixel = {
			...partial,
			addr: addrKey(partial.key),
			size: partial.text.length,
			ts: partial.ts ?? Date.now()
		};
		this.items.set(pixel.key, pixel);
		if (this.items.size > MAX) {
			const oldest = [...this.items.values()].sort((a, b) => a.ts - b.ts)[0];
			if (oldest) this.items.delete(oldest.key);
		}
		this.persist();
		return pixel;
	}
	get(key) {
		return this.items.get(key) ?? null;
	}
	delete(key) {
		this.items.delete(key);
		this.persist();
	}
	list() {
		return [...this.items.values()].sort((a, b) => b.ts - a.ts);
	}
	search(q) {
		const s = q.toLowerCase();
		if (!s) return this.list();
		return this.list().filter((p) => p.title.toLowerCase().includes(s) || p.text.toLowerCase().includes(s) || p.kind.includes(s) || p.key.toLowerCase().includes(s));
	}
	stats() {
		const list = this.list();
		return {
			count: list.length,
			bytes: list.reduce((a, p) => a + p.size, 0),
			hash: Hash.h64(list.map((p) => p.addr).join("|"))
		};
	}
};
var pixels = new PixelStore();
var HIST_KEY = "meridian.history";
var SET_KEY = "meridian.settings";
function persistHistory(history) {
	try {
		localStorage.setItem(HIST_KEY, JSON.stringify(history.slice(0, 40)));
	} catch {}
}
function persistSettings(s) {
	try {
		localStorage.setItem(SET_KEY, JSON.stringify(s));
	} catch {}
}
var useMeridian = create((set, get) => ({
	ready: false,
	grokOn: false,
	view: "chat",
	sidebarOpen: false,
	settingsOpen: false,
	paletteOpen: false,
	settings: {
		theme: "dark",
		think: false,
		search: false,
		model: "auto"
	},
	history: [],
	currentId: null,
	busy: false,
	bootAt: Date.now(),
	term: [],
	setView: (view) => set({
		view,
		sidebarOpen: false
	}),
	setSidebar: (sidebarOpen) => set({ sidebarOpen }),
	setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
	setPaletteOpen: (paletteOpen) => set({ paletteOpen }),
	setGrokOn: (grokOn) => set({ grokOn }),
	patchSettings: (p) => {
		const settings = {
			...get().settings,
			...p
		};
		persistSettings(settings);
		if (p.theme) document.documentElement.setAttribute("data-theme", settings.theme);
		set({ settings });
	},
	current: () => get().history.find((c) => c.id === get().currentId) ?? null,
	newChat: () => {
		const conv = {
			id: uid("c"),
			title: "New query",
			msgs: [],
			ts: Date.now()
		};
		const history = [conv, ...get().history];
		persistHistory(history);
		set({
			history,
			currentId: conv.id,
			view: "chat",
			sidebarOpen: false
		});
	},
	loadChat: (id) => set({
		currentId: id,
		view: "chat",
		sidebarOpen: false
	}),
	deleteChat: (id) => {
		const history = get().history.filter((c) => c.id !== id);
		persistHistory(history);
		set({
			history,
			currentId: get().currentId === id ? history[0]?.id ?? null : get().currentId
		});
	},
	clearHistory: () => {
		persistHistory([]);
		set({
			history: [],
			currentId: null
		});
	},
	pushUser: (text) => {
		let { history, currentId } = get();
		let conv = history.find((c) => c.id === currentId);
		if (!conv) {
			conv = {
				id: uid("c"),
				title: text.slice(0, 42),
				msgs: [],
				ts: Date.now()
			};
			history = [conv, ...history];
			currentId = conv.id;
		}
		if (conv.title === "New query") conv = {
			...conv,
			title: text.slice(0, 42)
		};
		const msg = {
			id: uid("m"),
			role: "user",
			text,
			ts: Date.now()
		};
		conv = {
			...conv,
			msgs: [...conv.msgs, msg],
			ts: Date.now()
		};
		history = history.map((c) => c.id === conv.id ? conv : c);
		persistHistory(history);
		set({
			history,
			currentId
		});
		return conv;
	},
	pushAssistant: (partial) => {
		const { history, currentId } = get();
		const conv = history.find((c) => c.id === currentId);
		if (!conv) return;
		const msg = {
			id: uid("m"),
			role: "assistant",
			ts: Date.now(),
			...partial
		};
		const next = {
			...conv,
			msgs: [...conv.msgs, msg],
			ts: Date.now()
		};
		const hist = history.map((c) => c.id === next.id ? next : c);
		persistHistory(hist);
		set({ history: hist });
	},
	setBusy: (busy) => set({ busy }),
	termLog: (kind, text) => set({ term: [...get().term, {
		id: uid("t"),
		kind,
		text
	}].slice(-400) }),
	hydrate: () => {
		try {
			WAL.load();
			pixels.load();
			const settings = safeJsonParse(typeof localStorage === "undefined" ? null : localStorage.getItem(SET_KEY), get().settings);
			const history = safeJsonParse(typeof localStorage === "undefined" ? null : localStorage.getItem(HIST_KEY), []);
			document.documentElement.setAttribute("data-theme", settings.theme);
			set({
				ready: true,
				settings,
				history,
				currentId: history[0]?.id ?? null,
				bootAt: Date.now()
			});
		} catch {
			set({
				ready: true,
				bootAt: Date.now()
			});
		}
	}
}));
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var grokStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("33333aed953733c9287b88dd268a1148dd2dc22d2e278a9145453fa43bf45b97"));
var askGrok = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("a1e248d85ae89b8d1aa6296dfc19867620a037d7964a9dae8d9b2801b923f91d"));
function Separator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "separator",
		className: cn("h-px w-full bg-border", className),
		...props
	});
}
function MeridianMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-elevated"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 26 A 8 18 0 0 1 24 26",
				fill: "none",
				className: "stroke-accent",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "8",
				r: "2.4",
				className: "fill-accent"
			})
		]
	});
}
var NAV = [
	{
		id: "chat",
		label: "Query",
		icon: Hexagon
	},
	{
		id: "lattice",
		label: "Lattice",
		icon: Orbit
	},
	{
		id: "fabric",
		label: "Fabric",
		icon: Hexagon
	},
	{
		id: "workspace",
		label: "Workspace",
		icon: FolderOpen
	},
	{
		id: "terminal",
		label: "Terminal",
		icon: Terminal
	}
];
function Sidebar() {
	const history = useMeridian((s) => s.history);
	const currentId = useMeridian((s) => s.currentId);
	const view = useMeridian((s) => s.view);
	const open = useMeridian((s) => s.sidebarOpen);
	const grokOn = useMeridian((s) => s.grokOn);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "fixed inset-0 z-40 bg-bg/60 md:hidden",
		"aria-label": "Close menu",
		onClick: () => useMeridian.getState().setSidebar(false)
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("flex h-full w-[248px] shrink-0 flex-col border-r border-border bg-surface", "fixed inset-y-0 left-0 z-50 transition-transform duration-200", open ? "translate-x-0" : "-translate-x-full", "md:relative md:z-auto md:translate-x-0"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5 px-4 pt-5 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-8" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-lg leading-none tracking-tight",
							children: "Meridian"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[10px] tracking-[0.14em] text-subtle uppercase",
							children: "Grounded intelligence"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						className: "md:hidden",
						"aria-label": "Close",
						onClick: () => useMeridian.getState().setSidebar(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full justify-start",
					onClick: () => useMeridian.getState().newChat(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquarePlus, {}), "New query"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-3 grid grid-cols-1 gap-0.5 px-2",
				children: NAV.map((item) => {
					const Icon = item.icon;
					const active = view === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useMeridian.getState().setView(item.id),
						className: cn("flex h-10 items-center gap-2.5 rounded-md px-3 text-sm transition-colors duration-150", active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/70 hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] tracking-[0.16em] text-subtle uppercase",
					children: "History"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-subtle hover:text-danger",
					"aria-label": "Clear history",
					onClick: () => {
						if (confirm("Clear all conversations?")) useMeridian.getState().clearHistory();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-2 pb-2",
				children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 py-3 text-xs text-subtle",
					children: "No queries yet"
				}) : history.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("group flex items-center gap-1 rounded-md", c.id === currentId ? "bg-elevated" : "hover:bg-elevated/60"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("min-w-0 flex-1 truncate px-3 py-2 text-left text-[13px]", c.id === currentId ? "text-fg" : "text-muted"),
						onClick: () => useMeridian.getState().loadChat(c.id),
						children: c.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "px-2 py-2 text-subtle opacity-0 group-hover:opacity-100 hover:text-danger",
						"aria-label": "Delete conversation",
						onClick: () => useMeridian.getState().deleteChat(c.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", grokOn ? "bg-ok" : "bg-subtle") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex-1 font-mono text-[11px] text-muted",
						children: grokOn ? "Grok live" : "Lattice only"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Settings",
						onClick: () => useMeridian.getState().setSettingsOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {})
					})
				]
			})
		]
	})] });
}
function inline(text) {
	const parts = [];
	const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\([^)]+\))/g;
	let last = 0;
	let m;
	let i = 0;
	while (m = re.exec(text)) {
		if (m.index > last) parts.push(text.slice(last, m.index));
		const tok = m[0];
		if (tok.startsWith("`")) parts.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-sm bg-elevated px-1 py-px font-mono text-[0.85em] text-accent",
			children: tok.slice(1, -1)
		}, i++));
		else if (tok.startsWith("**")) parts.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium text-fg",
			children: inline(tok.slice(2, -2))
		}, i++));
		else if (tok.startsWith("*")) parts.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
			className: "italic",
			children: inline(tok.slice(1, -1))
		}, i++));
		else {
			const lm = tok.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
			if (lm) {
				const href = lm[2].startsWith("http") ? lm[2] : "#";
				parts.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href,
					target: "_blank",
					rel: "noreferrer",
					className: "text-accent underline-offset-2 hover:underline",
					children: lm[1]
				}, i++));
			}
		}
		last = m.index + tok.length;
	}
	if (last < text.length) parts.push(text.slice(last));
	return parts;
}
function Markdown({ text }) {
	const lines = text.replace(/\r\n/g, "\n").split("\n");
	const nodes = [];
	let i = 0;
	let key = 0;
	while (i < lines.length) {
		const line = lines[i] ?? "";
		if (line.startsWith("```")) {
			const lang = line.slice(3).trim();
			const buf = [];
			i++;
			while (i < lines.length && !lines[i].startsWith("```")) {
				buf.push(lines[i]);
				i++;
			}
			i++;
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
				className: "my-3 overflow-x-auto rounded-lg bg-code px-3.5 py-3 font-mono text-xs leading-relaxed text-fg",
				children: [lang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 text-micro uppercase tracking-wider text-subtle",
					children: lang
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: buf.join("\n") })]
			}, key++));
			continue;
		}
		if (/^#{1,3}\s/.test(line)) {
			const level = line.match(/^#+/)[0].length;
			const cls = level === 1 ? "mt-4 mb-2 font-display text-xl text-fg" : level === 2 ? "mt-3 mb-1.5 font-display text-lg text-fg" : "mt-3 mb-1 text-sm font-medium text-fg";
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cls,
				children: inline(line.replace(/^#+\s/, ""))
			}, key++));
			i++;
			continue;
		}
		if (/^[-*]\s/.test(line)) {
			const items = [];
			while (i < lines.length && /^[-*]\s/.test(lines[i] ?? "")) {
				items.push((lines[i] ?? "").replace(/^[-*]\s/, ""));
				i++;
			}
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "my-2 list-disc space-y-1 pl-5 text-prose leading-relaxed",
				children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inline(it) }, idx))
			}, key++));
			continue;
		}
		if (/^\d+\.\s/.test(line)) {
			const items = [];
			while (i < lines.length && /^\d+\.\s/.test(lines[i] ?? "")) {
				items.push((lines[i] ?? "").replace(/^\d+\.\s/, ""));
				i++;
			}
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "my-2 list-decimal space-y-1 pl-5 text-prose leading-relaxed",
				children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inline(it) }, idx))
			}, key++));
			continue;
		}
		if (line.startsWith("> ")) {
			const buf = [];
			while (i < lines.length && (lines[i] ?? "").startsWith("> ")) {
				buf.push((lines[i] ?? "").slice(2));
				i++;
			}
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "my-2 border-l-2 border-border pl-3 text-muted",
				children: buf.map((b, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inline(b) }, idx))
			}, key++));
			continue;
		}
		if (!line.trim()) {
			i++;
			continue;
		}
		const buf = [line];
		i++;
		while (i < lines.length && lines[i]?.trim() && !/^#{1,3}\s/.test(lines[i]) && !/^[-*]\s/.test(lines[i]) && !/^\d+\.\s/.test(lines[i]) && !lines[i].startsWith("```") && !lines[i].startsWith("> ")) {
			buf.push(lines[i]);
			i++;
		}
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "my-2 text-prose leading-relaxed text-pretty text-fg",
			children: buf.map((b, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [idx ? " " : null, inline(b)] }, idx))
		}, key++));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "markdown min-w-0",
		children: nodes
	});
}
var OPS = /* @__PURE__ */ new Set([
	"(",
	")",
	"{",
	"}",
	"[",
	"]",
	",",
	";",
	"=",
	"!",
	"+",
	"-",
	"*",
	"/",
	"%",
	"^",
	"<",
	">",
	"&",
	"|",
	":"
]);
function tokenize(src) {
	const tokens = [];
	let i = 0;
	while (i < src.length) {
		const c = src[i];
		if (c === "#" || c === "/" && src[i + 1] === "/") {
			while (i < src.length && src[i] !== "\n") i++;
			continue;
		}
		if (c === " " || c === "	" || c === "\r" || c === "\n") {
			i++;
			continue;
		}
		if (c === "\"" || c === "'") {
			const q = c;
			i++;
			let s = "";
			while (i < src.length && src[i] !== q) if (src[i] === "\\" && i + 1 < src.length) {
				const n = src[i + 1];
				s += n === "n" ? "\n" : n === "t" ? "	" : n === "\\" ? "\\" : n === q ? q : n;
				i += 2;
			} else {
				s += src[i];
				i++;
			}
			i++;
			tokens.push({
				type: "str",
				value: s
			});
			continue;
		}
		if (/[0-9]/.test(c) || c === "." && /[0-9]/.test(src[i + 1] ?? "")) {
			let n = "";
			while (i < src.length && /[0-9.]/.test(src[i])) {
				n += src[i];
				i++;
			}
			tokens.push({
				type: "num",
				value: Number(n)
			});
			continue;
		}
		if (/[A-Za-z_]/.test(c)) {
			let id = "";
			while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) {
				id += src[i];
				i++;
			}
			tokens.push({
				type: "id",
				value: id
			});
			continue;
		}
		if (OPS.has(c)) {
			let op = c;
			const two = c + (src[i + 1] ?? "");
			if (two === "==" || two === "!=" || two === "<=" || two === ">=" || two === "&&" || two === "||" || two === "=>") {
				op = two;
				i += 2;
			} else i++;
			tokens.push({
				type: "op",
				value: op
			});
			continue;
		}
		i++;
	}
	tokens.push({ type: "eof" });
	return tokens;
}
var Parser = class {
	tokens;
	pos = 0;
	constructor(tokens) {
		this.tokens = tokens;
	}
	peek() {
		return this.tokens[this.pos] ?? { type: "eof" };
	}
	next() {
		return this.tokens[this.pos++] ?? { type: "eof" };
	}
	eat(v) {
		const t = this.peek();
		if (t.type === "op" && t.value === v) {
			this.next();
			return true;
		}
		if (t.type === "id" && t.value === v) {
			this.next();
			return true;
		}
		return false;
	}
	expectOp(v) {
		const t = this.next();
		if (t.type !== "op" || t.value !== v) throw new Error(`Expected '${v}'`);
	}
	parseProgram() {
		const stmts = [];
		while (this.peek().type !== "eof") {
			const s = this.parseStmt();
			if (s) stmts.push(s);
			this.eat(";");
		}
		return stmts;
	}
	parseStmt() {
		const t = this.peek();
		if (t.type === "eof") return null;
		if (t.type === "id") {
			if (t.value === "print") {
				this.next();
				return {
					type: "print",
					expr: this.parseExpr()
				};
			}
			if (t.value === "let" || t.value === "mut") {
				this.next();
				const nameTok = this.next();
				if (nameTok.type !== "id") throw new Error("Expected name after let");
				this.expectOp("=");
				return {
					type: "let",
					name: nameTok.value,
					mutable: t.value === "mut",
					expr: this.parseExpr()
				};
			}
			if (t.value === "if") {
				this.next();
				const cond = this.parseExpr();
				const then = this.parseBlock();
				let els;
				if (this.peek().type === "id" && this.peek().type === "id" && this.peek().value === "else") {
					this.next();
					els = this.parseBlock();
				}
				return {
					type: "if",
					cond,
					then,
					else: els
				};
			}
			if (t.value === "for") {
				this.next();
				const nameTok = this.next();
				if (nameTok.type !== "id") throw new Error("Expected loop variable");
				const inTok = this.next();
				if (inTok.type !== "id" || inTok.value !== "in") throw new Error("Expected 'in'");
				const iterable = this.parseExpr();
				const body = this.parseBlock();
				return {
					type: "for",
					varName: nameTok.value,
					iterable,
					body
				};
			}
			if (t.value === "while") {
				this.next();
				return {
					type: "while",
					cond: this.parseExpr(),
					body: this.parseBlock()
				};
			}
			if (t.value === "fn") {
				this.next();
				const nameTok = this.next();
				if (nameTok.type !== "id") throw new Error("Expected function name");
				this.expectOp("(");
				const params = [];
				while (!(this.peek().type === "op" && this.peek().type === "op" ? false : false) && !(this.peek().type === "op" && this.peek().value === ")")) {
					if (this.peek().type === "eof") break;
					if (this.peek().type === "op" && this.peek().value === ")") break;
					const p = this.next();
					if (p.type === "id") params.push(p.value);
					this.eat(",");
				}
				this.expectOp(")");
				return {
					type: "fn",
					name: nameTok.value,
					params,
					body: this.parseBlock()
				};
			}
			if (t.value === "return") {
				this.next();
				return {
					type: "return",
					expr: this.parseExpr()
				};
			}
			if (this.tokens[this.pos + 1]?.type === "op" && this.tokens[this.pos + 1].value === "=") {
				const name = t.value;
				this.next();
				this.next();
				return {
					type: "assign",
					name,
					expr: this.parseExpr()
				};
			}
		}
		if (t.type === "op" && t.value === "{") return this.parseBlock();
		return {
			type: "expr",
			expr: this.parseExpr()
		};
	}
	parseBlock() {
		if (this.peek().type === "op" && this.peek().value === "{") {
			this.next();
			const stmts = [];
			while (!(this.peek().type === "op" && this.peek().value === "}") && this.peek().type !== "eof") {
				const s = this.parseStmt();
				if (s) stmts.push(s);
				this.eat(";");
			}
			this.expectOp("}");
			return {
				type: "block",
				stmts
			};
		}
		const s = this.parseStmt();
		return {
			type: "block",
			stmts: s ? [s] : []
		};
	}
	parseExpr() {
		return this.parseOr();
	}
	parseOr() {
		let left = this.parseAnd();
		while (this.peek().type === "op" && this.peek().value === "||") {
			this.next();
			left = {
				type: "binary",
				op: "||",
				left,
				right: this.parseAnd()
			};
		}
		return left;
	}
	parseAnd() {
		let left = this.parseEq();
		while (this.peek().type === "op" && this.peek().value === "&&") {
			this.next();
			left = {
				type: "binary",
				op: "&&",
				left,
				right: this.parseEq()
			};
		}
		return left;
	}
	parseEq() {
		let left = this.parseCmp();
		while (this.peek().type === "op" && ["==", "!="].includes(this.peek().value ?? "")) left = {
			type: "binary",
			op: this.next().value,
			left,
			right: this.parseCmp()
		};
		return left;
	}
	parseCmp() {
		let left = this.parseAdd();
		while (this.peek().type === "op" && [
			"<",
			">",
			"<=",
			">="
		].includes(this.peek().value ?? "")) left = {
			type: "binary",
			op: this.next().value,
			left,
			right: this.parseAdd()
		};
		return left;
	}
	parseAdd() {
		let left = this.parseMul();
		while (this.peek().type === "op" && ["+", "-"].includes(this.peek().value ?? "")) left = {
			type: "binary",
			op: this.next().value,
			left,
			right: this.parseMul()
		};
		return left;
	}
	parseMul() {
		let left = this.parsePow();
		while (this.peek().type === "op" && [
			"*",
			"/",
			"%"
		].includes(this.peek().value ?? "")) left = {
			type: "binary",
			op: this.next().value,
			left,
			right: this.parsePow()
		};
		return left;
	}
	parsePow() {
		let left = this.parseUnary();
		if (this.peek().type === "op" && this.peek().value === "^") {
			this.next();
			left = {
				type: "binary",
				op: "^",
				left,
				right: this.parsePow()
			};
		}
		return left;
	}
	parseUnary() {
		if (this.peek().type === "op" && ["-", "!"].includes(this.peek().value ?? "")) return {
			type: "unary",
			op: this.next().value,
			expr: this.parseUnary()
		};
		return this.parsePost();
	}
	parsePost() {
		let node = this.parsePrimary();
		while (this.peek().type === "op" && this.peek().value === "[") {
			this.next();
			const idx = this.parseExpr();
			this.expectOp("]");
			node = {
				type: "index",
				target: node,
				index: idx
			};
		}
		return node;
	}
	parsePrimary() {
		const t = this.next();
		if (t.type === "num") return {
			type: "num",
			value: t.value
		};
		if (t.type === "str") return {
			type: "str",
			value: t.value
		};
		if (t.type === "id") {
			if (t.value === "true") return {
				type: "bool",
				value: true
			};
			if (t.value === "false") return {
				type: "bool",
				value: false
			};
			if (this.peek().type === "op" && this.peek().value === "(") {
				this.next();
				const args = [];
				while (!(this.peek().type === "op" && this.peek().value === ")") && this.peek().type !== "eof") {
					args.push(this.parseExpr());
					this.eat(",");
				}
				this.expectOp(")");
				return {
					type: "call",
					name: t.value,
					args
				};
			}
			return {
				type: "var",
				name: t.value
			};
		}
		if (t.type === "op" && t.value === "(") {
			const e = this.parseExpr();
			this.expectOp(")");
			return e;
		}
		if (t.type === "op" && t.value === "[") {
			const elements = [];
			while (!(this.peek().type === "op" && this.peek().value === "]") && this.peek().type !== "eof") {
				elements.push(this.parseExpr());
				this.eat(",");
			}
			this.expectOp("]");
			return {
				type: "array",
				elements
			};
		}
		throw new Error(`Unexpected token`);
	}
};
var ReturnSignal = class {
	value;
	constructor(value) {
		this.value = value;
	}
};
function stringify(v) {
	if (v === void 0) return "undefined";
	if (v === null) return "null";
	if (typeof v === "string") return v;
	if (typeof v === "function") return "<fn>";
	if (Array.isArray(v)) return "[" + v.map(stringify).join(", ") + "]";
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}
function makeGlobal(capture) {
	const g = /* @__PURE__ */ new Map();
	const num = (fn) => (...args) => fn(...args.map(Number));
	g.set("print", (...args) => {
		const s = args.map(stringify).join(" ");
		capture.push(s);
		return s;
	});
	g.set("str", (v) => stringify(v));
	g.set("len", (v) => v && typeof v === "object" && "length" in v ? v.length : String(v ?? "").length);
	g.set("range", (start, end, step) => {
		let a = Number(start), b = end === void 0 ? a : Number(end), s = step === void 0 ? 1 : Number(step);
		if (end === void 0) {
			b = a;
			a = 0;
		}
		if (s === 0) s = 1;
		const out = [];
		if (s > 0) for (let i = a; i < b; i += s) out.push(i);
		else for (let i = a; i > b; i += s) out.push(i);
		return out;
	});
	g.set("PI", Math.PI);
	g.set("E", Math.E);
	g.set("sin", num(Math.sin));
	g.set("cos", num(Math.cos));
	g.set("tan", num(Math.tan));
	g.set("sqrt", num(Math.sqrt));
	g.set("abs", num(Math.abs));
	g.set("pow", (a, b) => Math.pow(Number(a), Number(b)));
	g.set("floor", num(Math.floor));
	g.set("ceil", num(Math.ceil));
	g.set("round", num(Math.round));
	g.set("min", (...a) => Math.min(...a.map(Number)));
	g.set("max", (...a) => Math.max(...a.map(Number)));
	g.set("log", num(Math.log));
	g.set("exp", num(Math.exp));
	g.set("now", () => Date.now());
	g.set("push", (arr, val) => {
		if (!Array.isArray(arr)) throw new Error("push expects array");
		arr.push(val);
		return arr;
	});
	g.set("pop", (arr) => {
		if (!Array.isArray(arr)) throw new Error("pop expects array");
		return arr.pop();
	});
	g.set("join", (arr, sep) => {
		if (!Array.isArray(arr)) return String(arr);
		return arr.map(stringify).join(String(sep ?? ","));
	});
	g.set("map", (arr, fn) => {
		if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("map(arr, fn)");
		return arr.map((x) => fn(x));
	});
	g.set("filter", (arr, fn) => {
		if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("filter(arr, fn)");
		return arr.filter((x) => fn(x));
	});
	g.set("reduce", (arr, fn, init) => {
		if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("reduce(arr, fn, init)");
		return arr.reduce((a, b) => fn(a, b), init);
	});
	g.set("sum", (arr) => {
		if (!Array.isArray(arr)) return Number(arr);
		return arr.reduce((a, b) => a + Number(b), 0);
	});
	g.set("sort", (arr) => {
		if (!Array.isArray(arr)) return arr;
		return [...arr].sort((a, b) => Number(a) - Number(b));
	});
	g.set("rev", (arr) => Array.isArray(arr) ? [...arr].reverse() : String(arr).split("").reverse().join(""));
	g.set("factor", (n) => factorInt(Math.trunc(Number(n))));
	g.set("isPrime", (n) => isPrime(Math.trunc(Number(n))));
	g.set("gcd", (a, b) => gcd(Math.trunc(Number(a)), Math.trunc(Number(b))));
	g.set("fib", (n) => fib(Math.trunc(Number(n))));
	return g;
}
function isPrime(n) {
	if (n < 2) return false;
	if (n % 2 === 0) return n === 2;
	for (let i = 3; i * i <= n; i += 2) if (n % i === 0) return false;
	return true;
}
function gcd(a, b) {
	a = Math.abs(a);
	b = Math.abs(b);
	while (b) {
		const t = b;
		b = a % b;
		a = t;
	}
	return a;
}
function factorInt(n) {
	n = Math.abs(n);
	const out = [];
	if (n < 2) return [n];
	while (n % 2 === 0) {
		out.push(2);
		n /= 2;
	}
	for (let i = 3; i * i <= n; i += 2) while (n % i === 0) {
		out.push(i);
		n /= i;
	}
	if (n > 1) out.push(n);
	return out;
}
function fib(n) {
	if (n <= 0) return 0;
	if (n === 1) return 1;
	let a = 0, b = 1;
	for (let i = 2; i <= n; i++) {
		const t = a + b;
		a = b;
		b = t;
	}
	return b;
}
function evalNode(node, env, global) {
	switch (node.type) {
		case "num": return node.value;
		case "str": return node.value;
		case "bool": return node.value;
		case "array": return node.elements.map((e) => evalNode(e, env, global));
		case "var":
			if (env.has(node.name)) return env.get(node.name);
			if (global.has(node.name)) return global.get(node.name);
			throw new Error(`Undefined: ${node.name}`);
		case "unary": {
			const v = evalNode(node.expr, env, global);
			if (node.op === "-") return -Number(v);
			if (node.op === "!") return !v;
			return v;
		}
		case "binary": {
			const l = evalNode(node.left, env, global);
			const r = evalNode(node.right, env, global);
			switch (node.op) {
				case "+": return typeof l === "string" || typeof r === "string" ? String(l) + String(r) : Number(l) + Number(r);
				case "-": return Number(l) - Number(r);
				case "*": return Number(l) * Number(r);
				case "/": return Number(l) / Number(r);
				case "%": return Number(l) % Number(r);
				case "^": return Math.pow(Number(l), Number(r));
				case "==": return l === r;
				case "!=": return l !== r;
				case "<": return Number(l) < Number(r);
				case ">": return Number(l) > Number(r);
				case "<=": return Number(l) <= Number(r);
				case ">=": return Number(l) >= Number(r);
				case "&&": return Boolean(l) && Boolean(r);
				case "||": return Boolean(l) || Boolean(r);
				default: return 0;
			}
		}
		case "call": {
			const fn = env.get(node.name) ?? global.get(node.name);
			if (typeof fn !== "function") throw new Error(`Not a function: ${node.name}`);
			return fn(...node.args.map((a) => evalNode(a, env, global)));
		}
		case "index": {
			const t = evalNode(node.target, env, global);
			const i = evalNode(node.index, env, global);
			if (Array.isArray(t) || typeof t === "string") return t[Number(i)];
			return;
		}
		case "print": {
			const v = evalNode(node.expr, env, global);
			global.get("print")(v);
			return v;
		}
		case "let": {
			const v = evalNode(node.expr, env, global);
			env.set(node.name, v);
			return v;
		}
		case "assign": {
			if (!env.has(node.name) && !global.has(node.name)) throw new Error(`Undefined: ${node.name}`);
			const v = evalNode(node.expr, env, global);
			if (env.has(node.name)) env.set(node.name, v);
			else global.set(node.name, v);
			return v;
		}
		case "if":
			if (evalNode(node.cond, env, global)) return evalNode(node.then, env, global);
			if (node.else) return evalNode(node.else, env, global);
			return;
		case "for": {
			const iter = evalNode(node.iterable, env, global);
			const list = Array.isArray(iter) ? iter : typeof iter === "string" ? [...iter] : [];
			let last;
			for (const item of list) {
				const child = new Map(env);
				child.set(node.varName, item);
				last = evalNode(node.body, child, global);
			}
			return last;
		}
		case "while": {
			let last;
			let guard = 0;
			while (evalNode(node.cond, env, global)) {
				last = evalNode(node.body, env, global);
				if (++guard > 1e5) throw new Error("Loop exceeded 100000 iterations");
			}
			return last;
		}
		case "fn": {
			const fn = (...args) => {
				const child = new Map(env);
				node.params.forEach((p, i) => child.set(p, args[i]));
				try {
					return evalNode(node.body, child, global);
				} catch (e) {
					if (e instanceof ReturnSignal) return e.value;
					throw e;
				}
			};
			env.set(node.name, fn);
			global.set(node.name, fn);
			return fn;
		}
		case "return": throw new ReturnSignal(evalNode(node.expr, env, global));
		case "block": {
			let last;
			const child = new Map(env);
			for (const s of node.stmts) last = evalNode(s, child, global);
			return last;
		}
		case "expr": return evalNode(node.expr, env, global);
		default: return;
	}
}
function runAether(src) {
	const t0 = performance.now();
	const output = [];
	try {
		const program = new Parser(tokenize(src)).parseProgram();
		const global = makeGlobal(output);
		const env = new Map(global);
		let value;
		for (const stmt of program) value = evalNode(stmt, env, global);
		return {
			ok: true,
			output,
			value,
			ms: performance.now() - t0
		};
	} catch (e) {
		return {
			ok: false,
			output,
			value: void 0,
			error: e instanceof Error ? e.message : String(e),
			ms: performance.now() - t0
		};
	}
}
var AETHER_HELP = `Aether language

let x = 10
mut y = 0
print(x * 2)
fn square(n) { return n * n }
print(square(12))
for i in range(5) { print(i) }
let a = [3, 1, 4]
print(sum(a), sort(a), factor(123456789))
if 2 < 3 { print("yes") } else { print("no") }

Builtins: print str len range PI E sin cos tan sqrt abs pow floor ceil round
min max log exp now push pop join map filter reduce sum sort rev factor isPrime gcd fib`;
var KNOWLEDGE = [
	{
		id: "c",
		title: "Speed of light",
		category: "physics",
		keywords: [
			"light",
			"c",
			"vacuum",
			"relativity",
			"einstein",
			"299792458"
		],
		body: "The speed of light in vacuum is defined as exactly 299,792,458 metres per second. It is a universal constant (c) and the conversion factor between mass and energy in E = mc². Nothing with rest mass can reach c in vacuum; light itself has no rest mass. In 1983 the metre was redefined so that c is exact rather than measured.",
		source: "SI Brochure / CODATA"
	},
	{
		id: "g-const",
		title: "Newtonian gravitational constant",
		category: "physics",
		keywords: [
			"gravity",
			"newton",
			"constant",
			"G",
			"cavendish"
		],
		body: "Newton's law of universal gravitation: F = G·m₁·m₂ / r². The constant G is approximately 6.67430 × 10⁻¹¹ m³ kg⁻¹ s⁻² (CODATA 2018). Gravity in general relativity is spacetime curvature sourced by the stress-energy tensor, not a force at a distance.",
		source: "CODATA 2018"
	},
	{
		id: "planck",
		title: "Planck constant",
		category: "physics",
		keywords: [
			"planck",
			"quantum",
			"h",
			"hbar",
			"photon"
		],
		body: "The Planck constant h is exactly 6.62607015 × 10⁻³⁴ J·s (SI 2019). The reduced constant ℏ = h / 2π. Photon energy E = hν. The 2019 SI redefinition fixed h, e, k, and N_A as exact, making the kilogram a derived unit.",
		source: "SI 2019"
	},
	{
		id: "entangle",
		title: "Quantum entanglement",
		category: "physics",
		keywords: [
			"entanglement",
			"quantum",
			"bell",
			"epr",
			"qubit",
			"spooky"
		],
		body: "Entanglement is a non-classical correlation: the joint state of two or more systems cannot be written as a product of individual states. Measuring one subsystem instantly updates the description of the other, but this cannot transmit information faster than light (no-signalling). Bell tests (Aspect, Zeilinger, Clauser — Nobel 2022) rule out local hidden-variable theories.",
		source: "Nobel Prize 2022 / QM textbooks"
	},
	{
		id: "relativity",
		title: "Special and general relativity",
		category: "physics",
		keywords: [
			"relativity",
			"einstein",
			"spacetime",
			"lorentz",
			"time dilation"
		],
		body: "Special relativity (1905): the laws of physics are the same in all inertial frames; c is invariant. Consequences include time dilation, length contraction, and E² = (pc)² + (mc²)². General relativity (1915): gravity is the curvature of spacetime; Einstein field equations G_μν + Λg_μν = (8πG/c⁴) T_μν. Confirmed by perihelion of Mercury, gravitational lensing, GPS corrections, and gravitational waves (LIGO 2015).",
		source: "Einstein 1905/1915"
	},
	{
		id: "thermo2",
		title: "Second law of thermodynamics",
		category: "physics",
		keywords: [
			"entropy",
			"thermodynamics",
			"second law",
			"kelvin",
			"clausius"
		],
		body: "The entropy of an isolated system never decreases. Heat does not spontaneously flow from cold to hot. Equivalent statements: Kelvin–Planck (no perfect heat engine) and Clausius. Statistical mechanics identifies entropy with S = k ln Ω. The second law gives time its thermodynamic arrow.",
		source: "Clausius / Boltzmann"
	},
	{
		id: "em-spectrum",
		title: "Electromagnetic spectrum",
		category: "physics",
		keywords: [
			"electromagnetic",
			"spectrum",
			"radio",
			"xray",
			"gamma",
			"infrared"
		],
		body: "Electromagnetic waves are oscillations of electric and magnetic fields traveling at c in vacuum. In order of increasing frequency: radio, microwave, infrared, visible (≈400–700 nm), ultraviolet, X-ray, gamma. Energy of a photon is E = hν = hc/λ.",
		source: "Maxwell / quantum optics"
	},
	{
		id: "pi",
		title: "Pi (π)",
		category: "math",
		keywords: [
			"pi",
			"circle",
			"transcendental",
			"3.14159",
			"archimedes"
		],
		body: "π is the ratio of a circle's circumference to its diameter, approximately 3.141592653589793. It is irrational (Lambert 1761) and transcendental (Lindemann 1882). Appears in Fourier analysis, Gaussian integrals, Euler's identity e^{iπ} + 1 = 0, and the volume of an n-ball.",
		source: "Classical analysis"
	},
	{
		id: "e-const",
		title: "Euler's number e",
		category: "math",
		keywords: [
			"euler",
			"e",
			"exponential",
			"2.718",
			"natural log"
		],
		body: "e ≈ 2.718281828459045 is the base of the natural logarithm. Defined as lim (1+1/n)^n, or Σ 1/n!. The unique base where d/dx a^x = a^x. Euler's identity: e^{iθ} = cos θ + i sin θ.",
		source: "Euler"
	},
	{
		id: "fibonacci",
		title: "Fibonacci sequence",
		category: "math",
		keywords: [
			"fibonacci",
			"sequence",
			"golden",
			"phi",
			"recurrence"
		],
		body: "F₀ = 0, F₁ = 1, Fₙ = Fₙ₋₁ + Fₙ₋₂. The sequence begins 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89… The ratio Fₙ₊₁/Fₙ → φ = (1+√5)/2 ≈ 1.6180339887 (the golden ratio). Binet's formula: Fₙ = (φⁿ − (−φ)⁻ⁿ) / √5.",
		source: "Number theory"
	},
	{
		id: "primes",
		title: "Prime numbers",
		category: "math",
		keywords: [
			"prime",
			"number",
			"sieve",
			"eratosthenes",
			"goldbach"
		],
		body: "A prime is an integer greater than 1 with no positive divisors other than 1 and itself. There are infinitely many (Euclid). The prime-number theorem: π(n) ∼ n / ln n. Fundamental theorem of arithmetic: every integer > 1 has a unique prime factorization. Goldbach's conjecture (every even integer > 2 is the sum of two primes) is verified to enormous bounds but unproven.",
		source: "Number theory"
	},
	{
		id: "pythagoras",
		title: "Pythagorean theorem",
		category: "math",
		keywords: [
			"pythagoras",
			"triangle",
			"hypotenuse",
			"a2+b2"
		],
		body: "In a right triangle, a² + b² = c² where c is the hypotenuse. Equivalent to the Euclidean inner-product identity. Generalizes to the law of cosines c² = a² + b² − 2ab cos γ, and to Parseval's theorem in Hilbert space.",
		source: "Euclid I.47"
	},
	{
		id: "calculus",
		title: "Fundamental theorem of calculus",
		category: "math",
		keywords: [
			"calculus",
			"integral",
			"derivative",
			"newton",
			"leibniz"
		],
		body: "If F'(x) = f(x), then ∫_a^b f(x) dx = F(b) − F(a). Differentiation and integration are inverse operations. Newton and Leibniz developed the infinitesimal calculus independently in the 17th century; the modern ε-δ foundation is due to Cauchy and Weierstrass.",
		source: "Analysis"
	},
	{
		id: "euler-id",
		title: "Euler's identity",
		category: "math",
		keywords: [
			"euler",
			"identity",
			"e",
			"pi",
			"complex"
		],
		body: "e^{iπ} + 1 = 0. It unites the five most important constants in mathematics (e, i, π, 1, 0) in a single equation, a special case of Euler's formula e^{iθ} = cos θ + i sin θ.",
		source: "Complex analysis"
	},
	{
		id: "dna",
		title: "DNA structure",
		category: "biology",
		keywords: [
			"dna",
			"double helix",
			"watson",
			"crick",
			"gene",
			"base"
		],
		body: "Deoxyribonucleic acid stores genetic information as a double helix of complementary base pairs: adenine–thymine (two hydrogen bonds) and guanine–cytosine (three). The sugar-phosphate backbone is antiparallel (5' to 3'). Watson and Crick (1953), building on Franklin and Wilkins, proposed the structure. The human genome has ~3.2 billion base pairs across 23 chromosome pairs.",
		source: "Watson & Crick 1953"
	},
	{
		id: "cancer",
		title: "Cancer",
		category: "medicine",
		keywords: [
			"cancer",
			"tumor",
			"oncology",
			"metastasis",
			"cell"
		],
		body: "Cancer is a group of diseases of uncontrolled cell growth with potential to invade or metastasize. Hallmarks (Hanahan & Weinberg) include sustaining proliferation, evading growth suppressors, resisting cell death, enabling replicative immortality, inducing angiogenesis, and activating invasion. Causes include mutations, carcinogens, viruses (HPV, HBV), and inherited syndromes. Early detection and a combination of surgery, radiotherapy, chemotherapy, immunotherapy, and targeted drugs improve outcomes. This is general information, not medical advice.",
		source: "Hanahan & Weinberg / WHO"
	},
	{
		id: "photosynthesis",
		title: "Photosynthesis",
		category: "biology",
		keywords: [
			"photosynthesis",
			"chlorophyll",
			"plant",
			"calvin",
			"glucose"
		],
		body: "6 CO₂ + 6 H₂O + photons → C₆H₁₂O₆ + 6 O₂. Light reactions in thylakoid membranes split water and produce ATP and NADPH; the Calvin cycle in the stroma fixes carbon. Chlorophyll a absorbs primarily blue and red light, which is why plants appear green.",
		source: "Plant physiology"
	},
	{
		id: "evolution",
		title: "Natural selection",
		category: "biology",
		keywords: [
			"evolution",
			"darwin",
			"selection",
			"fitness",
			"species"
		],
		body: "Darwin and Wallace: heritable variation + differential reproductive success → adaptation over generations. Modern synthesis unites this with Mendelian genetics and population genetics. Evidence includes fossils, biogeography, homology, observed speciation, and genomic phylogenies.",
		source: "Darwin 1859 / modern synthesis"
	},
	{
		id: "atom",
		title: "Atomic structure",
		category: "chemistry",
		keywords: [
			"atom",
			"electron",
			"proton",
			"neutron",
			"orbital",
			"bohr"
		],
		body: "An atom has a nucleus of protons and neutrons, surrounded by electrons in orbitals described by quantum mechanics (not classical Bohr orbits). Atomic number Z = proton count, which defines the element. Isotopes differ in neutron count. The periodic table arranges elements by Z and recurring chemical properties.",
		source: "Quantum chemistry"
	},
	{
		id: "periodic",
		title: "Periodic table",
		category: "chemistry",
		keywords: [
			"periodic",
			"mendeleev",
			"element",
			"group",
			"period"
		],
		body: "Mendeleev (1869) arranged elements by atomic weight and chemical periodicity; the modern table uses atomic number. Groups share valence-electron configuration (alkali metals, halogens, noble gases). Periods correspond to filling of electron shells. There are 118 confirmed elements.",
		source: "IUPAC"
	},
	{
		id: "water",
		title: "Water (H₂O)",
		category: "chemistry",
		keywords: [
			"water",
			"h2o",
			"hydrogen bond",
			"solvent",
			"ice"
		],
		body: "Water is a polar molecule with a bent geometry (≈104.5°) due to two lone pairs on oxygen. Hydrogen bonding gives it a high boiling point, high heat capacity, and the unusual property that ice is less dense than liquid water. It is the universal solvent of terrestrial biochemistry.",
		source: "Physical chemistry"
	},
	{
		id: "cs-complexity",
		title: "P versus NP",
		category: "cs",
		keywords: [
			"p vs np",
			"complexity",
			"turing",
			"algorithm",
			"np-complete"
		],
		body: "P is the class of decision problems solvable in polynomial time by a deterministic Turing machine. NP is the class verifiable in polynomial time. P ⊆ NP; whether P = NP is the central open problem of theoretical computer science (Clay Millennium Problem). NP-complete problems (SAT, TSP decision, clique) are the hardest in NP: a polynomial algorithm for one yields one for all.",
		source: "Cook–Levin / Clay Institute"
	},
	{
		id: "turing",
		title: "Turing machine",
		category: "cs",
		keywords: [
			"turing",
			"computability",
			"halting",
			"church",
			"algorithm"
		],
		body: "A Turing machine is an abstract computer: an infinite tape, a head, and a finite state table. Church–Turing thesis: anything effectively computable is computable by a Turing machine. The halting problem is undecidable — no algorithm can determine, for every program and input, whether the program halts.",
		source: "Turing 1936"
	},
	{
		id: "http",
		title: "HTTP and the web",
		category: "cs",
		keywords: [
			"http",
			"web",
			"html",
			"browser",
			"tcp",
			"internet"
		],
		body: "HTTP is the application protocol of the web, typically over TCP port 80 (HTTPS over TLS on 443). A request has a method (GET, POST, PUT, DELETE…), path, headers, and optional body. Status codes: 2xx success, 3xx redirect, 4xx client error, 5xx server error. HTML, CSS, and JavaScript are the browser's native triad.",
		source: "IETF RFCs"
	},
	{
		id: "transformer",
		title: "Transformer architecture",
		category: "cs",
		keywords: [
			"transformer",
			"attention",
			"llm",
			"gpt",
			"neural",
			"bert"
		],
		body: "The Transformer (Vaswani et al., 2017) replaces recurrence with self-attention: each token attends to every other token in the sequence. Multi-head attention + position-wise feed-forward layers + residual connections + layer norm. This is the backbone of modern large language models. Complexity is O(n²) in sequence length, motivating sparse and linear-attention variants.",
		source: "Vaswani et al. 2017"
	},
	{
		id: "sha256",
		title: "SHA-256",
		category: "cs",
		keywords: [
			"sha256",
			"hash",
			"cryptography",
			"bitcoin",
			"digest"
		],
		body: "SHA-256 is a 256-bit cryptographic hash in the SHA-2 family (NSA, 2001). It is collision-resistant in practice, used in Bitcoin's proof-of-work, TLS, and digital signatures. Output is 32 bytes (64 hex chars). It is not encryption — hashes are one-way.",
		source: "FIPS 180-4"
	},
	{
		id: "sort",
		title: "Sorting algorithms",
		category: "cs",
		keywords: [
			"sort",
			"quicksort",
			"mergesort",
			"heapsort",
			"big-o"
		],
		body: "Comparison sorts require Ω(n log n) comparisons in the worst case. Mergesort and heapsort achieve O(n log n) worst-case; quicksort is O(n log n) average, O(n²) worst. Timsort (Python, Java) is a hybrid mergesort optimized for real-world partially-sorted data. Radix and counting sorts can beat n log n when keys have extra structure.",
		source: "CLRS"
	},
	{
		id: "solar",
		title: "Solar System",
		category: "astronomy",
		keywords: [
			"solar",
			"planet",
			"sun",
			"jupiter",
			"earth",
			"orbit"
		],
		body: "The Sun is a G2V star holding eight planets: Mercury, Venus, Earth, Mars (terrestrial) and Jupiter, Saturn, Uranus, Neptune (giant). Dwarf planets include Pluto, Ceres, Eris. Earth orbits at 1 AU ≈ 149.6 million km with a sidereal year of 365.256 days. The Sun is ≈4.6 billion years old and about halfway through its main-sequence life.",
		source: "IAU / NASA"
	},
	{
		id: "blackhole",
		title: "Black holes",
		category: "astronomy",
		keywords: [
			"black hole",
			"event horizon",
			"schwarzschild",
			"hawking",
			"singularity"
		],
		body: "A black hole is a region where gravity is so strong that not even light can escape. The Schwarzschild radius is r_s = 2GM/c². Event Horizon Telescope imaged M87* (2019) and Sgr A* (2022). Hawking radiation implies black holes evaporate thermally, leading to the information paradox — an open question in quantum gravity.",
		source: "GR / EHT"
	},
	{
		id: "bigbang",
		title: "Big Bang cosmology",
		category: "astronomy",
		keywords: [
			"big bang",
			"cmb",
			"universe",
			"hubble",
			"expansion"
		],
		body: "The universe expanded from a hot, dense state ≈13.8 billion years ago. Evidence: Hubble–Lemaître expansion, the cosmic microwave background (Penzias & Wilson 1965; Planck satellite), and primordial light-element abundances. ΛCDM is the standard model: cold dark matter plus a cosmological constant driving late-time acceleration.",
		source: "Planck / ΛCDM"
	},
	{
		id: "earth",
		title: "Earth",
		category: "earth",
		keywords: [
			"earth",
			"planet",
			"atmosphere",
			"core",
			"plate"
		],
		body: "Earth is the third planet from the Sun, radius ≈6371 km, mass ≈5.97 × 10²⁴ kg. Structure: inner solid iron core, outer liquid core (geodynamo), silicate mantle, crust. Plate tectonics recycles crust. Atmosphere is 78% N₂, 21% O₂. Surface is ≈71% ocean. Axial tilt 23.44° produces seasons.",
		source: "USGS / NASA"
	},
	{
		id: "climate",
		title: "Climate and greenhouse effect",
		category: "earth",
		keywords: [
			"climate",
			"carbon",
			"greenhouse",
			"warming",
			"co2"
		],
		body: "Greenhouse gases (CO₂, CH₄, H₂O, N₂O) absorb outgoing longwave radiation, warming the surface. Pre-industrial CO₂ ≈280 ppm; it now exceeds 420 ppm, primarily from fossil fuels and land-use change. IPCC assessments attribute recent warming to human activity with high confidence. This is scientific consensus, not a political statement.",
		source: "IPCC AR6"
	},
	{
		id: "ww2",
		title: "Second World War",
		category: "history",
		keywords: [
			"ww2",
			"world war",
			"1945",
			"hitler",
			"allies",
			"axis"
		],
		body: "World War II (1939–1945) was the deadliest conflict in history. It began with Germany's invasion of Poland and ended with Germany's surrender (May 1945) and Japan's (September 1945) after the atomic bombings of Hiroshima and Nagasaki. The United Nations, bipolar Cold War, and decolonization followed.",
		source: "Historical consensus"
	},
	{
		id: "rome",
		title: "Roman Empire",
		category: "history",
		keywords: [
			"rome",
			"caesar",
			"augustus",
			"empire",
			"republic"
		],
		body: "Rome grew from a city-state to a Mediterranean empire. The Republic ended as Octavian became Augustus (27 BCE). The Western Empire traditionally falls in 476 CE; the Eastern (Byzantine) Empire continued until 1453. Latin, law, engineering, and urbanism shaped Europe.",
		source: "Classical history"
	},
	{
		id: "printing",
		title: "Printing press",
		category: "history",
		keywords: [
			"gutenberg",
			"printing",
			"press",
			"book",
			"reformation"
		],
		body: "Johannes Gutenberg's movable-type press (Mainz, c. 1440) made books cheap and standardized. It accelerated the Reformation, scientific correspondence, and vernacular literacy — a communications revolution comparable to the internet.",
		source: "History of technology"
	},
	{
		id: "internet",
		title: "Internet",
		category: "cs",
		keywords: [
			"internet",
			"tcp",
			"ip",
			"packet",
			"arpanet",
			"dns"
		],
		body: "The internet is a global packet-switched network using the TCP/IP suite. ARPANET (1969) pioneered it; TCP/IP was standardized on 1 January 1983. Addressing is hierarchical (IP); names resolve via DNS. The web (Berners-Lee, 1989–91) is one application among many (email, SSH, streaming).",
		source: "RFC 791 / CERN"
	},
	{
		id: "john316",
		title: "John 3:16",
		category: "language",
		keywords: [
			"bible",
			"john",
			"verse",
			"scripture",
			"gospel"
		],
		body: "John 3:16 (KJV): “For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.” It is among the most-cited verses in the Christian New Testament, summarizing the Gospel's claim of divine love and salvation.",
		source: "Gospel of John"
	},
	{
		id: "shakespeare",
		title: "William Shakespeare",
		category: "language",
		keywords: [
			"shakespeare",
			"hamlet",
			"play",
			"sonnet",
			"globe"
		],
		body: "William Shakespeare (1564–1616), Stratford-upon-Avon, wrote about 39 plays and 154 sonnets. Hamlet, King Lear, Macbeth, Othello, Romeo and Juliet, and the history cycle defined English drama. His vocabulary and phrasing still structure the language.",
		source: "Literary history"
	},
	{
		id: "music-12",
		title: "Twelve-tone equal temperament",
		category: "language",
		keywords: [
			"music",
			"octave",
			"temperament",
			"semitone",
			"hz",
			"a440"
		],
		body: "Western common-practice music divides the octave into 12 equal semitones; frequency ratio of a semitone is 2^(1/12). Concert pitch A4 = 440 Hz (ISO 16). An octave doubles frequency. Harmony is built from stacked thirds (triads) and functional progression.",
		source: "Music theory / ISO 16"
	},
	{
		id: "cpu",
		title: "How a CPU works",
		category: "engineering",
		keywords: [
			"cpu",
			"processor",
			"alu",
			"pipeline",
			"instruction",
			"von neumann"
		],
		body: "A CPU fetches, decodes, and executes instructions. The von Neumann model shares memory for code and data. Pipelining overlaps stages; caches hide DRAM latency; branch predictors guess control flow. Performance is a product of clock, IPC, and energy, constrained by Dennard scaling's end and the memory wall.",
		source: "Computer architecture"
	},
	{
		id: "semiconductor",
		title: "Semiconductors and transistors",
		category: "engineering",
		keywords: [
			"transistor",
			"silicon",
			"semiconductor",
			"moore",
			"chip"
		],
		body: "Silicon doped with boron (p) or phosphorus (n) forms p–n junctions. The MOSFET is the switch of modern computing. Moore's law observed transistor density doubling roughly every two years; physical limits (leakage, heat, lithography) now force 3D stacking, chiplets, and specialized accelerators.",
		source: "Solid-state physics"
	},
	{
		id: "flight",
		title: "How airplanes fly",
		category: "engineering",
		keywords: [
			"airplane",
			"lift",
			"wing",
			"bernoulli",
			"aerodynamics"
		],
		body: "A wing produces lift by turning airflow downward (Newton's third law); the pressure difference (Bernoulli) is the same physics in another language. Four forces: lift, weight, thrust, drag. Control surfaces (aileron, elevator, rudder) change moments about the three axes.",
		source: "Aerodynamics"
	},
	{
		id: "gps",
		title: "GPS",
		category: "engineering",
		keywords: [
			"gps",
			"satellite",
			"navigation",
			"relativity",
			"gnss"
		],
		body: "GPS is a GNSS constellation of ~24+ MEO satellites broadcasting time-stamped signals. A receiver trilaterates position from four or more clocks. Relativistic corrections are mandatory: satellite clocks run faster by ~38 μs/day due to weaker gravity (GR) minus special-relativistic velocity delay. Without them, errors would accumulate kilometres per day.",
		source: "GPS ICD / relativity"
	},
	{
		id: "vaccine",
		title: "Vaccines",
		category: "medicine",
		keywords: [
			"vaccine",
			"immune",
			"antibody",
			"mrna",
			"immunization"
		],
		body: "Vaccines present antigen so the adaptive immune system forms memory B and T cells without causing the disease. Types: live attenuated, inactivated, subunit, toxoid, viral vector, mRNA. They are among the most effective public-health interventions (smallpox eradication, polio near-eradication). This is general information, not medical advice.",
		source: "WHO / immunology"
	},
	{
		id: "heart",
		title: "Human heart",
		category: "medicine",
		keywords: [
			"heart",
			"blood",
			"cardiac",
			"atrium",
			"ventricle",
			"pulse"
		],
		body: "The heart is a four-chamber pump: right atrium/ventricle send blood to the lungs; left atrium/ventricle send oxygenated blood to the body. A normal resting adult rate is about 60–100 beats per minute. The sinoatrial node is the pacemaker. This is general information, not medical advice.",
		source: "Anatomy"
	},
	{
		id: "french-rev",
		title: "French Revolution",
		category: "history",
		keywords: [
			"french",
			"revolution",
			"1789",
			"bastille",
			"napoleon"
		],
		body: "The French Revolution (1789–1799) overthrew the Bourbon monarchy, issued the Declaration of the Rights of Man, and entered the Terror before Napoleon Bonaparte's rise. It exported nationalism, metrication, and the idea of popular sovereignty across Europe.",
		source: "Modern European history"
	},
	{
		id: "moon",
		title: "The Moon",
		category: "astronomy",
		keywords: [
			"moon",
			"luna",
			"apollo",
			"tide",
			"satellite"
		],
		body: "The Moon is Earth's only natural satellite, mean distance ≈384,400 km, radius 1,737 km. It is tidally locked (same face). Apollo 11 landed 20 July 1969. Lunar tides arise because the Moon's gravity gradient stretches Earth. Giant-impact hypothesis: a Mars-sized body (Theia) struck early Earth, ejecting the Moon.",
		source: "NASA / planetary science"
	},
	{
		id: "ai",
		title: "Artificial intelligence",
		category: "cs",
		keywords: [
			"ai",
			"machine learning",
			"neural",
			"intelligence",
			"model"
		],
		body: "AI is the field of machines performing tasks that appear to require intelligence. Modern progress is dominated by statistical machine learning, especially deep neural networks trained by gradient descent on large datasets. It is not sentience; it is function approximation plus search. Capabilities and failure modes (hallucination, bias, distribution shift) must be evaluated empirically.",
		source: "ML textbooks"
	},
	{
		id: "entropy-info",
		title: "Information entropy",
		category: "cs",
		keywords: [
			"shannon",
			"entropy",
			"information",
			"bit",
			"compression"
		],
		body: "Shannon entropy H(X) = −Σ p(x) log₂ p(x) measures average surprise in bits. It is the lower bound on lossless compression. Mutual information I(X;Y) = H(X) − H(X|Y) measures shared information. Cross-entropy is the training loss of most classifiers and language models.",
		source: "Shannon 1948"
	},
	{
		id: "market",
		title: "Supply and demand",
		category: "history",
		keywords: [
			"economics",
			"supply",
			"demand",
			"price",
			"market",
			"equilibrium"
		],
		body: "In a competitive market, price tends toward the intersection of supply and demand. A surplus pushes prices down; a shortage pushes them up. Elasticity measures responsiveness. Real markets include frictions: monopoly power, externalities, information asymmetry, and public goods — the starting point of welfare economics.",
		source: "Microeconomics"
	},
	{
		id: "democracy",
		title: "Democracy",
		category: "history",
		keywords: [
			"democracy",
			"vote",
			"republic",
			"election",
			"athens"
		],
		body: "Democracy is rule by the people, typically via contested elections, civil liberties, and constraint of power. Classical Athens practiced direct democracy for citizens; modern states are mostly representative republics. Schumpeter's minimal definition: an institutional arrangement for arriving at political decisions by competitive struggle for the people's vote.",
		source: "Political theory"
	},
	{
		id: "language-family",
		title: "Indo-European languages",
		category: "language",
		keywords: [
			"indo-european",
			"language",
			"sanskrit",
			"latin",
			"germanic"
		],
		body: "Indo-European is the language family of most of Europe and much of South and West Asia: Germanic, Romance, Slavic, Indo-Iranian, Celtic, Greek, Albanian, Armenian, Baltic. Reconstructed Proto-Indo-European was likely spoken on the Pontic–Caspian steppe (Yamna hypothesis) in the 4th–3rd millennia BCE.",
		source: "Historical linguistics"
	},
	{
		id: "zero",
		title: "The number zero",
		category: "math",
		keywords: [
			"zero",
			"0",
			"placeholder",
			"brahmagupta",
			"nothing"
		],
		body: "Zero serves as both a placeholder in positional notation and a number in its own right. Babylonians used a placeholder; Indian mathematicians (Brahmagupta, 7th century) treated 0 as a number with arithmetic rules. It is the additive identity: x + 0 = x. Division by zero is undefined in the reals.",
		source: "History of mathematics"
	},
	{
		id: "set-theory",
		title: "Sets and infinity",
		category: "math",
		keywords: [
			"set",
			"cantor",
			"infinity",
			"cardinal",
			"aleph"
		],
		body: "Cantor showed infinities come in sizes: |ℕ| = ℵ₀, |ℝ| = 2^ℵ₀ = 𝔠. Cantor's theorem: |P(S)| > |S| for any set S. Continuum hypothesis (is 𝔠 = ℵ₁?) is independent of ZFC (Gödel, Cohen). Modern mathematics is routinely founded on Zermelo–Fraenkel set theory with choice.",
		source: "Set theory"
	},
	{
		id: "godel",
		title: "Gödel's incompleteness theorems",
		category: "math",
		keywords: [
			"godel",
			"incompleteness",
			"undecidable",
			"consistency",
			"arithmetic"
		],
		body: "Any consistent, recursively axiomatizable theory capable of expressing basic arithmetic is incomplete: there are true statements it cannot prove. The second theorem: such a theory cannot prove its own consistency. These results ended Hilbert's program of a complete finitary foundation for mathematics.",
		source: "Gödel 1931"
	},
	{
		id: "periodic-motion",
		title: "Simple harmonic motion",
		category: "physics",
		keywords: [
			"harmonic",
			"oscillator",
			"spring",
			"pendulum",
			"frequency"
		],
		body: "SHM: acceleration proportional to minus displacement, a = −ω²x. Solutions are sinusoids. Period of a mass-spring is T = 2π√(m/k); small-angle pendulum T ≈ 2π√(L/g). Fourier analysis decomposes general periodic signals into harmonic oscillators.",
		source: "Classical mechanics"
	},
	{
		id: "maxwell",
		title: "Maxwell's equations",
		category: "physics",
		keywords: [
			"maxwell",
			"electromagnetism",
			"gauss",
			"faraday",
			"ampere"
		],
		body: "Four equations unify electricity and magnetism: Gauss's law for E and B, Faraday's law, and the Ampère–Maxwell law. They imply electromagnetic waves at speed c = 1/√(ε₀μ₀). Light is an electromagnetic wave. Special relativity was partly motivated by the inconsistency of Maxwell with Galilean relativity.",
		source: "Maxwell 1865"
	},
	{
		id: "periodic-table-c",
		title: "Carbon",
		category: "chemistry",
		keywords: [
			"carbon",
			"organic",
			"diamond",
			"graphite",
			"covalent"
		],
		body: "Carbon (Z = 6) forms four covalent bonds, enabling the vast chemistry of life (organic chemistry). Allotropes: diamond (sp³), graphite/graphene (sp²), fullerenes, nanotubes. The carbon cycle moves C among atmosphere, biosphere, oceans, and crust.",
		source: "Inorganic / organic chemistry"
	},
	{
		id: "neuron",
		title: "Neurons and synapses",
		category: "biology",
		keywords: [
			"neuron",
			"brain",
			"synapse",
			"action potential",
			"axon"
		],
		body: "Neurons transmit information as action potentials — all-or-none voltage spikes — along axons, then chemically at synapses via neurotransmitters. The Hodgkin–Huxley model (1952) describes the ionic basis (Na⁺, K⁺). Brains compute with both spikes and synaptic weights, the inspiration for artificial neural nets (a loose analogy, not an identity).",
		source: "Neuroscience"
	},
	{
		id: "cell",
		title: "The cell",
		category: "biology",
		keywords: [
			"cell",
			"eukaryote",
			"prokaryote",
			"organelle",
			"membrane"
		],
		body: "The cell is the basic unit of life. Prokaryotes (bacteria, archaea) lack a nucleus; eukaryotes have membrane-bound organelles including a nucleus, mitochondria, and (in plants) chloroplasts. The plasma membrane is a phospholipid bilayer with proteins. All cells store hereditary information in nucleic acids and use ribosomes to make proteins.",
		source: "Cell biology"
	},
	{
		id: "metric",
		title: "SI units",
		category: "physics",
		keywords: [
			"si",
			"metric",
			"kilogram",
			"metre",
			"second",
			"units"
		],
		body: "The International System of Units has seven base units: second, metre, kilogram, ampere, kelvin, mole, candela. Since 2019 all are defined by fixing constants of nature (c, h, e, k, N_A, Δν_Cs, K_cd). Prefixes: k = 10³, M = 10⁶, m = 10⁻³, μ = 10⁻⁶, n = 10⁻⁹.",
		source: "BIPM SI Brochure"
	},
	{
		id: "logarithm",
		title: "Logarithms",
		category: "math",
		keywords: [
			"logarithm",
			"log",
			"ln",
			"exponent",
			"decibel"
		],
		body: "log_b(x) is the exponent to which b must be raised to obtain x. Natural log ln is log_e. Change of base: log_b(x) = ln x / ln b. They turn multiplication into addition, which is why they appear in complexity (log n), information theory (bits), and perception (decibels, magnitude scales).",
		source: "Algebra"
	},
	{
		id: "matrix",
		title: "Matrices and linear algebra",
		category: "math",
		keywords: [
			"matrix",
			"linear",
			"eigenvalue",
			"vector",
			"determinant"
		],
		body: "A matrix represents a linear map between vector spaces. Multiplication is composition of maps (non-commutative). Eigenvalues satisfy Av = λv. Determinants measure signed volume scaling; a matrix is invertible iff det ≠ 0. SVD decomposes any real matrix; it is the workhorse of PCA, recommendation, and numerical ML.",
		source: "Linear algebra"
	},
	{
		id: "probability",
		title: "Probability",
		category: "math",
		keywords: [
			"probability",
			"bayes",
			"random",
			"distribution",
			"statistics"
		],
		body: "Probability is a measure on events in [0, 1] obeying Kolmogorov's axioms. Conditional probability P(A|B) = P(A∩B)/P(B). Bayes' theorem: P(H|D) = P(D|H)P(H)/P(D). The law of large numbers and the central limit theorem explain why averages stabilize and why Gaussians appear so often.",
		source: "Probability theory"
	},
	{
		id: "compiler",
		title: "Compilers",
		category: "cs",
		keywords: [
			"compiler",
			"lexer",
			"parser",
			"ast",
			"codegen",
			"llvm"
		],
		body: "A compiler translates source to a target (often machine code) through lexing, parsing, semantic analysis, optimization, and code generation. Interpreters execute without a full ahead-of-time compile. LLVM and Cranelift are modern backend infrastructures. Aether in this workspace is a small interpreted language following the same pipeline.",
		source: "Dragon Book / LLVM"
	},
	{
		id: "unicode",
		title: "Unicode",
		category: "cs",
		keywords: [
			"unicode",
			"utf-8",
			"character",
			"emoji",
			"encoding"
		],
		body: "Unicode assigns a code point to every character (U+0000 to U+10FFFF). UTF-8 is a variable-width encoding compatible with ASCII: code points U+0000–U+007F are single bytes. It is the encoding of the web. A 'character' is not always one code point (grapheme clusters, combining marks).",
		source: "Unicode Consortium"
	},
	{
		id: "rel-db",
		title: "Relational databases",
		category: "cs",
		keywords: [
			"sql",
			"database",
			"relational",
			"codd",
			"join",
			"index"
		],
		body: "Codd's relational model stores data in tables (relations) with keys. SQL is the declarative query language: SELECT, JOIN, GROUP BY. ACID transactions (atomicity, consistency, isolation, durability) are the traditional contract. Indexes (B-trees, hashes) make lookups sublinear. Normalization reduces redundancy; denormalization trades it for read speed.",
		source: "Codd 1970"
	},
	{
		id: "os",
		title: "Operating systems",
		category: "cs",
		keywords: [
			"os",
			"kernel",
			"process",
			"thread",
			"scheduler",
			"linux"
		],
		body: "An OS multiplexes hardware among programs: process isolation, virtual memory, file systems, device drivers, and a scheduler. The kernel runs in privileged mode. Linux, Windows NT, and XNU (macOS) are the dominant general-purpose kernels. User programs talk to the kernel via system calls.",
		source: "OSTEP / Tanenbaum"
	},
	{
		id: "encryption",
		title: "Public-key cryptography",
		category: "cs",
		keywords: [
			"encryption",
			"rsa",
			"public key",
			"aes",
			"tls",
			"pgp"
		],
		body: "Symmetric ciphers (AES) use one shared key. Public-key (RSA, elliptic curves) uses a key pair: encrypt with the public, decrypt with the private; or sign with the private, verify with the public. TLS combines both: public-key handshake to establish a symmetric session key. Security rests on computational hardness, not secrecy of the algorithm (Kerckhoffs).",
		source: "Applied cryptography"
	},
	{
		id: "kepler",
		title: "Kepler's laws",
		category: "astronomy",
		keywords: [
			"kepler",
			"orbit",
			"ellipse",
			"planet",
			"period"
		],
		body: "1. Planets orbit in ellipses with the Sun at one focus. 2. Equal areas in equal times (conservation of angular momentum). 3. T² ∝ a³ (period squared proportional to semi-major axis cubed). Newton derived them from inverse-square gravity.",
		source: "Kepler / Newton"
	},
	{
		id: "periodic-waves",
		title: "Sound",
		category: "physics",
		keywords: [
			"sound",
			"wave",
			"frequency",
			"hz",
			"decibel",
			"air"
		],
		body: "Sound in air is a longitudinal pressure wave. Speed ≈343 m/s at 20 °C. Human hearing ≈20 Hz–20 kHz. Pitch tracks frequency; loudness tracks intensity on a logarithmic (decibel) scale. Timbre is the overtone spectrum.",
		source: "Acoustics"
	},
	{
		id: "color",
		title: "Color and light",
		category: "physics",
		keywords: [
			"color",
			"rgb",
			"wavelength",
			"cone",
			"srgb"
		],
		body: "Visible light is electromagnetic radiation ≈400–700 nm. Human color vision is trichromatic (S, M, L cones). Displays mix red, green, and blue primaries (additive). Pigments mix subtractively (CMY). sRGB is the default web color space; hex #RRGGBB encodes 8-bit channels.",
		source: "Color science"
	},
	{
		id: "map-proj",
		title: "Map projections",
		category: "earth",
		keywords: [
			"map",
			"mercator",
			"projection",
			"gis",
			"latitude"
		],
		body: "You cannot flatten a sphere without distortion (Gauss's theorema egregium). Mercator preserves angles (useful for sailing) but inflates high latitudes. Equal-area projections (Gall–Peters, Mollweide) preserve area at the cost of shape. Choose the projection for the question.",
		source: "Cartography"
	},
	{
		id: "time-zones",
		title: "Time and time zones",
		category: "earth",
		keywords: [
			"time",
			"utc",
			"timezone",
			"leap",
			"second",
			"calendar"
		],
		body: "Civil time is UTC plus an offset. UTC tracks atomic time (TAI) with leap seconds to stay near Earth rotation (UT1). A day is 86,400 SI seconds except when a leap second is inserted. ISO 8601 writes timestamps as 2026-08-25T00:00:00Z.",
		source: "IERS / ISO 8601"
	},
	{
		id: "meridian-geo",
		title: "Meridian (geography)",
		category: "earth",
		keywords: [
			"meridian",
			"longitude",
			"greenwich",
			"prime",
			"latitude"
		],
		body: "A meridian is a half great-circle from pole to pole — a line of constant longitude. The prime meridian (0°) was internationally agreed at Greenwich in 1884. Longitude east or west of it, with latitude, specifies a position on Earth. Local solar noon occurs when the Sun crosses the local meridian.",
		source: "Geodesy / IERS"
	},
	{
		id: "factor-example",
		title: "Integer factorization",
		category: "math",
		keywords: [
			"factor",
			"factorization",
			"123456789",
			"composite"
		],
		body: "Every integer greater than 1 factors uniquely into primes (fundamental theorem of arithmetic). Example: 123,456,789 = 3² × 3,607 × 3,803. Trial division up to √n is enough for 64-bit integers; cryptographic moduli (RSA) are products of two large primes chosen so that factoring is intractable with known classical algorithms.",
		source: "Number theory"
	}
];
var STOP = new Set("a an the of to in on for and or is are was were be been being what who whom which that this those these how why when where who what is are do does did can could should would will with from about into over after before than then also not no yes it its it's you your we our they their as at by if so such just than".split(" "));
function tokenizeQuery(q) {
	return q.toLowerCase().replace(/[^a-z0-9+.\-]+/g, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w));
}
function searchKnowledge(query, limit = 6) {
	const q = query.trim();
	if (!q) return [];
	const tokens = tokenizeQuery(q);
	const ql = q.toLowerCase();
	return KNOWLEDGE.map((entry) => {
		let score = 0;
		const title = entry.title.toLowerCase();
		const body = entry.body.toLowerCase();
		if (title === ql) score += 12;
		if (ql.includes(title) || title.includes(ql)) score += 6;
		for (const kw of entry.keywords) {
			if (ql.includes(kw) || kw.includes(ql)) score += 3.5;
			if (tokens.includes(kw)) score += 2;
		}
		let hit = 0;
		for (const t of tokens) {
			if (title.includes(t)) {
				score += 2.4;
				hit++;
			}
			if (entry.keywords.some((k) => k.includes(t) || t.includes(k))) {
				score += 1.6;
				hit++;
			}
			if (body.includes(t)) {
				score += .45;
				hit++;
			}
		}
		if (tokens.length) score += hit / tokens.length * 2;
		if (entry.category && ql.includes(entry.category)) score += .8;
		return {
			entry,
			score
		};
	}).filter((x) => x.score >= 2.2).sort((a, b) => b.score - a.score).slice(0, limit);
}
function bestKnowledge(query) {
	const top = searchKnowledge(query, 1)[0];
	if (!top || top.score < 4.5) return null;
	return top;
}
var CATEGORIES = [...new Set(KNOWLEDGE.map((k) => k.category))];
var EXPERTS = [
	{
		id: "phys",
		name: "Helia",
		domain: "physics",
		keywords: [
			"physics",
			"quantum",
			"relativity",
			"light",
			"energy",
			"force",
			"entropy",
			"wave",
			"particle",
			"gravity"
		],
		blurb: "First-principles physics: constants, fields, and spacetime."
	},
	{
		id: "math",
		name: "Axioma",
		domain: "math",
		keywords: [
			"math",
			"prime",
			"proof",
			"algebra",
			"calculus",
			"pi",
			"number",
			"matrix",
			"probability",
			"logarithm",
			"factor"
		],
		blurb: "Pure mathematics, from integers to incompleteness."
	},
	{
		id: "bio",
		name: "Soma",
		domain: "biology",
		keywords: [
			"biology",
			"dna",
			"cell",
			"evolution",
			"neuron",
			"gene",
			"photosynthesis",
			"organism"
		],
		blurb: "Living systems, from molecules to selection."
	},
	{
		id: "chem",
		name: "Valence",
		domain: "chemistry",
		keywords: [
			"chemistry",
			"atom",
			"bond",
			"element",
			"molecule",
			"periodic",
			"carbon",
			"water",
			"reaction"
		],
		blurb: "Structure, bonding, and the table of elements."
	},
	{
		id: "cs",
		name: "Ada",
		domain: "cs",
		keywords: [
			"code",
			"algorithm",
			"computer",
			"program",
			"compiler",
			"hash",
			"ai",
			"http",
			"database",
			"os",
			"crypto",
			"turing",
			"complexity"
		],
		blurb: "Computation, systems, and cryptographic hardness."
	},
	{
		id: "astro",
		name: "Lyra",
		domain: "astronomy",
		keywords: [
			"star",
			"planet",
			"galaxy",
			"black hole",
			"cosmos",
			"orbit",
			"moon",
			"sun",
			"kepler",
			"big bang"
		],
		blurb: "The sky: orbits, collapse, and origin."
	},
	{
		id: "hist",
		name: "Annal",
		domain: "history",
		keywords: [
			"history",
			"war",
			"empire",
			"revolution",
			"democracy",
			"economy",
			"civilization"
		],
		blurb: "What people did, and what followed."
	},
	{
		id: "med",
		name: "Clinic",
		domain: "medicine",
		keywords: [
			"medicine",
			"health",
			"disease",
			"vaccine",
			"heart",
			"cancer",
			"anatomy"
		],
		blurb: "Human physiology — general knowledge, not advice."
	},
	{
		id: "eng",
		name: "Forge",
		domain: "engineering",
		keywords: [
			"engine",
			"chip",
			"cpu",
			"flight",
			"gps",
			"transistor",
			"circuit",
			"machine"
		],
		blurb: "How artifacts actually work."
	},
	{
		id: "geo",
		name: "Meridian",
		domain: "earth",
		keywords: [
			"earth",
			"climate",
			"map",
			"time",
			"longitude",
			"meridian",
			"ocean",
			"continent"
		],
		blurb: "The planet as a measured object."
	}
];
function routeExpert(query) {
	const q = query.toLowerCase();
	let best = null;
	for (const ex of EXPERTS) {
		let s = 0;
		for (const kw of ex.keywords) if (q.includes(kw)) s += 2;
		if (q.includes(ex.domain)) s += 3;
		if (q.includes(ex.name.toLowerCase())) s += 4;
		if (!best || s > best.score) best = {
			expert: ex,
			score: s
		};
	}
	if (!best || best.score < 2) return null;
	const hits = searchKnowledge(query, 4).filter((h) => h.entry.category === best.expert.domain || h.score > 5).map((h) => h.entry);
	return {
		expert: best.expert,
		score: best.score,
		hits
	};
}
var MAX_SHOTS = 240;
var Fabric1000D = class {
	shots = [];
	cache = /* @__PURE__ */ new Map();
	map(content) {
		const coords = fabricCoords(content);
		const key = `${coords.screen},${coords.y},${coords.x},${coords.dim}`;
		this.cache.set(key, {
			coords,
			ts: Date.now()
		});
		return {
			key,
			coords
		};
	}
	shot(query) {
		const t0 = performance.now();
		const { coords } = this.map(query);
		const shot = {
			query,
			coords,
			opsT: .6 + Hash.mix(query) % 1e3 / 1e3 * 1.8,
			ms: Math.max(.2, performance.now() - t0),
			ts: Date.now()
		};
		this.shots.push(shot);
		if (this.shots.length > MAX_SHOTS) this.shots.shift();
		return shot;
	}
	stats() {
		return {
			dims: 1e3,
			screens: 64,
			loci: 4194304e3,
			cached: this.cache.size,
			shots: this.shots.length,
			last: this.shots[this.shots.length - 1] ?? null
		};
	}
};
var fabric = new Fabric1000D();
async function wikiSearch(query) {
	const q = query.trim();
	if (!q) return null;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 8e3);
	try {
		const open = await fetch(`https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=1&namespace=0&format=json&origin=*`, { signal: ctrl.signal });
		if (!open.ok) throw new Error("opensearch");
		const title = (await open.json())[1]?.[0];
		if (!title) return null;
		const sum = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`, {
			signal: ctrl.signal,
			headers: { Accept: "application/json" }
		});
		if (!sum.ok) throw new Error("summary");
		const j = await sum.json();
		const extract = (j.extract || "").trim();
		if (!extract) return null;
		return {
			title: j.title || title,
			extract,
			description: j.description,
			url: j.content_urls?.desktop?.page
		};
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
var responseCache = /* @__PURE__ */ new Map();
var MAX_CACHE = 400;
function cacheSet(key, val) {
	responseCache.set(key, val);
	if (responseCache.size > MAX_CACHE) {
		const first = responseCache.keys().next().value;
		if (first) responseCache.delete(first);
	}
}
function cacheStats() {
	return { size: responseCache.size };
}
function formatEntry(title, body, source) {
	return `**${title}**\n\n${body}${source ? `\n\n— ${source}` : ""}`;
}
function localMath(query) {
	const q = query.trim();
	const factor = q.match(/^(?:factor|factorize|prime factors?(?: of)?)\s+(-?\d+)\s*\??$/i);
	if (factor) {
		const n = Number(factor[1]);
		const r = runAether(`print(join(factor(${n}), " × "))`);
		return r.ok ? `**${n}** = ${r.output[0] || n}` : null;
	}
	const fib = q.match(/^(?:fibonacci|fib)\s+(\d+)\s*\??$/i);
	if (fib) {
		const n = Number(fib[1]);
		if (n > 80) return "Fibonacci index capped at 80 in the local engine.";
		const r = runAether(`print(fib(${n}))`);
		return r.ok ? `F(${n}) = ${r.output[0]}` : null;
	}
	const prime = q.match(/^(?:is\s+)?(\d+)\s+(?:prime|a prime)\??$/i) || q.match(/^isPrime\s+(\d+)/i);
	if (prime) {
		const n = Number(prime[1]);
		const r = runAether(`print(isPrime(${n}))`);
		return r.ok ? `${n} is ${r.output[0] === "true" ? "" : "not "}prime.` : null;
	}
	if (/^help\s*$/i.test(q) || q === "?") return null;
	const expr = q.match(/^(?:what(?:'s| is)|compute|calc(?:ulate)?|eval)\s+(.+?)\??$/i);
	const raw = expr ? expr[1] : /^(?:[\d.+\-*/^()%\s]+|[a-z]+\([^)]*\))$/i.test(q) ? q : null;
	if (raw && /[\d)]/.test(raw) && !/[a-z]{4,}/i.test(raw.replace(/sin|cos|tan|sqrt|abs|pow|pi|log|exp/gi, ""))) {
		const r = runAether(`print(${raw.replace(/\bpi\b/gi, "PI").replace(/\^/g, "^")})`);
		if (r.ok && r.output[0] && r.output[0] !== "undefined") return `= ${r.output[0]}`;
	}
	return null;
}
function pixelHits(query) {
	return pixels.search(query).slice(0, 3).filter((p) => p.kind !== "chat").map((p) => `(${p.kind}) ${p.title}: ${p.text.slice(0, 600)}`);
}
async function askOracle(query, opts) {
	const t0 = performance.now();
	const q = query.trim();
	if (!q) return {
		ok: false,
		text: "",
		kind: "error",
		ms: 0,
		error: "Empty query"
	};
	fabric.shot(q);
	WAL.push("ask", {
		q: q.slice(0, 200),
		model: opts.model
	});
	const key = addrKey(`${opts.model}|${opts.think ? 1 : 0}|${opts.search ? 1 : 0}|${q}`);
	const cached = responseCache.get(key);
	if (cached && opts.model !== "aether") return {
		ok: true,
		text: cached,
		kind: "cache",
		cached: true,
		ms: performance.now() - t0,
		sources: ["cache"]
	};
	const finish = (text, kind, sources) => {
		cacheSet(key, text);
		pixels.set({
			key: `ans:${key.slice(0, 12)}`,
			title: q.slice(0, 72),
			text,
			kind: "chat"
		});
		return {
			ok: true,
			text,
			kind,
			ms: performance.now() - t0,
			sources
		};
	};
	if (q.startsWith("run:") || opts.model === "aether") {
		const r = runAether(q.startsWith("run:") ? q.slice(4).trim() : q);
		if (!r.ok) return {
			ok: false,
			text: r.error || "Aether error",
			kind: "aether",
			ms: r.ms,
			error: r.error
		};
		return finish("```\n" + ((r.output.length ? r.output.join("\n") : stringifyVal(r.value)) || "(no output)") + "\n```", "aether", ["aether"]);
	}
	const math = localMath(q);
	if (math && (opts.model === "auto" || opts.model === "oracle")) return finish(math, "oracle", ["lattice"]);
	const kb = bestKnowledge(q);
	const related = searchKnowledge(q, 4);
	const expert = routeExpert(q);
	const storeHits = pixelHits(q);
	if (opts.model === "oracle") {
		if (kb) return finish(formatEntry(kb.entry.title, kb.entry.body, kb.entry.source), "oracle", ["lattice"]);
		if (related[0]) {
			const e = related[0].entry;
			return finish(formatEntry(e.title, e.body, e.source), "oracle", ["lattice"]);
		}
		return {
			ok: true,
			text: "No grounded lattice entry for that query. Switch to Auto or Grok, or ingest a note in Workspace.",
			kind: "oracle",
			ms: performance.now() - t0,
			sources: []
		};
	}
	if (opts.model === "expert") {
		if (!expert) return {
			ok: true,
			text: "No expert claimed this query. Try a domain word (physics, math, biology, code) or switch to Auto.",
			kind: "expert",
			ms: performance.now() - t0
		};
		const bits = expert.hits.map((h) => formatEntry(h.title, h.body, h.source));
		const head = `**${expert.expert.name}** · ${expert.expert.domain}\n${expert.expert.blurb}\n`;
		const body = bits.length ? bits.join("\n\n") : "No lattice notes in this domain for that wording.";
		return finish(head + "\n" + body, "expert", [expert.expert.name]);
	}
	let wiki = null;
	if (opts.search) {
		wiki = await wikiSearch(q);
		if (wiki) pixels.set({
			key: `wiki:${wiki.title}`,
			title: wiki.title,
			text: wiki.extract,
			kind: "wiki",
			meta: wiki.url ? { url: wiki.url } : void 0
		});
	}
	const contextParts = [];
	if (kb) contextParts.push(`Lattice: ${kb.entry.title}\n${kb.entry.body}\nSource: ${kb.entry.source}`);
	for (const h of related.slice(0, 3)) {
		if (h.entry.id === kb?.entry.id) continue;
		contextParts.push(`${h.entry.title}: ${h.entry.body}`);
	}
	if (wiki) contextParts.push(`Wikipedia (${wiki.title}): ${wiki.extract}${wiki.url ? "\n" + wiki.url : ""}`);
	if (storeHits.length) contextParts.push("Workspace notes:\n" + storeHits.join("\n"));
	if (expert) contextParts.push(`Routed expert: ${expert.expert.name} (${expert.expert.domain})`);
	const wantGrok = opts.model === "grok" || opts.model === "auto" && opts.grokOn !== false;
	const grokNeeded = opts.model === "grok" || opts.think || !kb || kb && kb.score < 8 || opts.search;
	if (wantGrok && grokNeeded) {
		const grok = await askGrok({ data: {
			prompt: q,
			context: contextParts.join("\n\n---\n\n"),
			think: opts.think,
			history: opts.history
		} });
		if (grok.ok) {
			const sources = [
				kb ? "lattice" : null,
				wiki ? "wikipedia" : null,
				"grok-4.5",
				expert ? expert.expert.name : null
			].filter(Boolean);
			return finish(grok.text, opts.think ? "think" : "grok", sources);
		}
		if (opts.model === "grok") return {
			ok: false,
			text: grok.error || "Grok unavailable",
			kind: "error",
			ms: performance.now() - t0,
			error: grok.error
		};
	}
	if (kb) return finish(formatEntry(kb.entry.title, kb.entry.body, kb.entry.source), "oracle", ["lattice"]);
	if (wiki) return finish(formatEntry(wiki.title, wiki.extract, wiki.url || "Wikipedia"), "wiki", ["wikipedia"]);
	if (related[0] && related[0].score >= 3) {
		const e = related[0].entry;
		return finish(formatEntry(e.title, e.body, e.source), "oracle", ["lattice"]);
	}
	return {
		ok: true,
		text: "I don't have a grounded local answer, and live reasoning is unavailable. Try a lattice topic (light, DNA, primes, HTTP), run Aether with `run:`, or attach a note in Workspace.",
		kind: "oracle",
		ms: performance.now() - t0
	};
}
function stringifyVal(v) {
	if (v === void 0) return "";
	if (typeof v === "string") return v;
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}
function handleCommand(raw, grokOn) {
	if (!raw.startsWith("/")) return null;
	const [cmd, ...rest] = raw.slice(1).trim().split(/\s+/);
	const args = rest.join(" ");
	const t0 = performance.now();
	const ok = (text, kind = "cmd") => ({
		ok: true,
		text,
		kind,
		ms: performance.now() - t0
	});
	switch ((cmd || "").toLowerCase()) {
		case "help": return ok([
			"**Meridian** — grounded intelligence workspace",
			"",
			"**Models:** Auto, Grok, Oracle, Aether, Expert",
			"",
			"**Chat**",
			"Plain language queries. Auto uses the lattice first, then Grok 4.5 with retrieved context.",
			"`run: <code>` — execute Aether",
			"Toggle Deep Think or Search (Wikipedia) on the composer.",
			"",
			"**Commands**",
			"/help — this list",
			"/aether <code> — run Aether",
			"/factor <n> — prime factorization",
			"/wiki <topic> — ingest a Wikipedia summary",
			"/prove <claim> — hash a notary proof",
			"/experts — list domain experts",
			"/lattice — knowledge stats",
			"/status — engine snapshot",
			"/reset confirm — wipe local memory",
			"",
			AETHER_HELP
		].join("\n"));
		case "aether": {
			const r = runAether(args || "print(\"Meridian\")");
			if (!r.ok) return {
				ok: false,
				text: r.error || "error",
				kind: "aether",
				ms: r.ms,
				error: r.error
			};
			return ok("```\n" + (r.output.join("\n") || stringifyVal(r.value) || "(no output)") + "\n```", "aether");
		}
		case "factor": {
			const n = Number(args.replace(/[^\d-]/g, ""));
			if (!Number.isFinite(n)) return ok("Usage: /factor 123456789");
			return ok(`**${n}** = ${runAether(`print(join(factor(${n}), " × "))`).output[0]}`);
		}
		case "experts": return ok(EXPERTS.map((e) => `**${e.name}** · ${e.domain} — ${e.blurb}`).join("\n\n"));
		case "lattice": return ok(`Lattice entries: **${KNOWLEDGE.length}**\nCategories: ${CATEGORIES.join(", ")}\nCache: ${responseCache.size}\nPixels: ${pixels.stats().count}`);
		case "status": return ok(JSON.stringify({
			grok: grokOn,
			lattice: KNOWLEDGE.length,
			experts: EXPERTS.length,
			fabric: fabric.stats(),
			wal: WAL.entries.length,
			pixels: pixels.stats(),
			cache: responseCache.size
		}, null, 2));
		case "prove": {
			if (!args) return ok("Usage: /prove <claim>");
			const ts = Date.now();
			const proofHash = Hash.h64(args + ts);
			WAL.push("prove", {
				claim: args,
				proofHash
			});
			pixels.set({
				key: `proof:${proofHash}`,
				title: args.slice(0, 80),
				text: proofHash,
				kind: "proof"
			});
			return ok(`Notary proof\n\nClaim: ${args}\nHash: \`${proofHash}\`\nTime: ${new Date(ts).toISOString()}`);
		}
		case "wiki": return (async () => {
			const hit = await wikiSearch(args || "Meridian (geography)");
			if (!hit) return {
				ok: false,
				text: "No Wikipedia extract.",
				kind: "wiki",
				ms: performance.now() - t0,
				error: "miss"
			};
			pixels.set({
				key: `wiki:${hit.title}`,
				title: hit.title,
				text: hit.extract,
				kind: "wiki"
			});
			return ok(formatEntry(hit.title, hit.extract, hit.url || "Wikipedia"), "wiki");
		})();
		case "reset":
			if (args !== "confirm") return ok("Type `/reset confirm` to wipe local cache, pixels, and WAL.");
			responseCache.clear();
			pixels.items.clear();
			pixels.persist();
			WAL.clear();
			return ok("Local memory wiped.");
		default: return ok(`Unknown command \`/${cmd}\`. Try /help.`);
	}
}
async function sendQuery(text) {
	const q = text.trim();
	if (!q) return;
	const store = useMeridian.getState();
	if (store.busy) return;
	store.pushUser(q);
	store.setBusy(true);
	store.termLog("in", q);
	try {
		const cmd = handleCommand(q, store.grokOn);
		const history = (useMeridian.getState().current()?.msgs ?? []).filter((m) => m.role === "user" || m.role === "assistant").slice(-8).map((m) => ({
			role: m.role,
			content: m.text
		}));
		const result = cmd ? await cmd : await askOracle(q, {
			model: store.settings.model,
			think: store.settings.think,
			search: store.settings.search,
			history,
			grokOn: store.grokOn
		});
		if (!result.ok) {
			store.pushAssistant({
				text: result.error || result.text || "Something went wrong.",
				kind: "error",
				ms: result.ms
			});
			store.termLog("err", result.error || result.text);
			if (/quota|not authorized|not available/i.test(result.error || result.text)) store.setGrokOn(false);
			return;
		}
		store.pushAssistant({
			text: result.text,
			kind: result.kind,
			cached: result.cached,
			ms: result.ms,
			sources: result.sources
		});
		store.termLog("ok", `${result.kind} · ${Math.round(result.ms)}ms`);
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		store.pushAssistant({
			text: msg,
			kind: "error"
		});
		toast.error(msg);
		store.termLog("err", msg);
	} finally {
		store.setBusy(false);
	}
}
var SUGGESTIONS = [
	"What is the speed of light?",
	"Factor 123456789",
	"run: for i in range(8) { print(i * i) }",
	"Explain quantum entanglement",
	"/help",
	"How does a transformer work?"
];
function ChatPane() {
	const conv = useMeridian((s) => s.history.find((c) => c.id === s.currentId) ?? null);
	const busy = useMeridian((s) => s.busy);
	const bottom = (0, import_react.useRef)(null);
	const msgs = conv?.msgs ?? [];
	(0, import_react.useEffect)(() => {
		bottom.current?.scrollIntoView({
			behavior: "smooth",
			block: "end"
		});
	}, [msgs.length, busy]);
	if (!msgs.length && !busy) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-center justify-center px-6 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-14 animate-fade-up" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "animate-fade-up stagger-1 mt-6 font-display text-4xl tracking-tight text-fg sm:text-5xl",
				children: "Meridian"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "animate-fade-up stagger-2 mt-2 max-w-md text-center text-sm text-muted",
				children: "A grounded workspace. Local lattice first, live Grok when it earns the call."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "animate-fade-up stagger-3 mt-8 flex max-w-xl flex-wrap justify-center gap-2",
				children: SUGGESTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void sendQuery(s),
					className: "rounded-full border border-border bg-surface px-3.5 py-2 text-left text-[13px] text-muted transition-colors duration-150 hover:border-border-strong hover:text-fg",
					children: s
				}, s))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex-1 overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8",
			children: [
				msgs.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("flex gap-3", m.role === "user" && "flex-row-reverse"),
					children: [m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-0.5 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-8" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-user text-[11px] font-medium text-muted",
						children: "You"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("min-w-0 max-w-[min(100%,560px)]", m.role === "user" && "flex flex-col items-end"),
						children: m.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg rounded-br-sm bg-user px-3.5 py-2.5 text-[15px] leading-relaxed text-fg",
							children: m.text
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex items-center gap-2 text-[11px] text-subtle",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "uppercase tracking-wider",
										children: m.kind || "Meridian"
									}),
									m.cached ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-ok",
										children: "cached"
									}) : null,
									typeof m.ms === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono tabular-nums",
										children: [Math.round(m.ms), "ms"]
									}) : null
								]
							}),
							m.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-danger",
								children: m.text
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { text: m.text }),
							m.sources?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-[11px] text-subtle",
								children: ["Sources: ", m.sources.join(" · ")]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Copy",
									onClick: () => {
										navigator.clipboard.writeText(m.text);
										toast.success("Copied");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Ask again",
									onClick: () => {
										const prev = msgs[msgs.indexOf(m) - 1];
										if (prev?.role === "user") sendQuery(prev.text);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
								})]
							})
						] })
					})]
				}, m.id)),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-8" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1.5 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "typing-dot size-1.5 rounded-full bg-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "typing-dot size-1.5 rounded-full bg-muted",
									style: { animationDelay: "0.18s" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "typing-dot size-1.5 rounded-full bg-muted",
									style: { animationDelay: "0.36s" }
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shimmer-text text-xs",
							children: "Reasoning"
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: bottom })
			]
		})
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-pop min-w-44 overflow-hidden rounded-lg bg-surface p-1 shadow-[var(--elev-shadow)]", className),
		...props
	}) });
}
function DropdownMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-2 text-sm text-fg outline-none data-highlighted:bg-elevated", className),
		...props
	});
}
var MODELS = [
	{
		id: "auto",
		label: "Auto",
		hint: "Lattice, then Grok"
	},
	{
		id: "grok",
		label: "Grok 4.5",
		hint: "Live reasoning"
	},
	{
		id: "oracle",
		label: "Oracle",
		hint: "Local lattice only"
	},
	{
		id: "aether",
		label: "Aether",
		hint: "Run as code"
	},
	{
		id: "expert",
		label: "Expert",
		hint: "Domain routing"
	}
];
function Composer() {
	const ref = (0, import_react.useRef)(null);
	const model = useMeridian((s) => s.settings.model);
	const think = useMeridian((s) => s.settings.think);
	const search = useMeridian((s) => s.settings.search);
	const busy = useMeridian((s) => s.busy);
	const grokOn = useMeridian((s) => s.grokOn);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const on = () => {
			el.style.height = "auto";
			el.style.height = Math.min(el.scrollHeight, 180) + "px";
		};
		el.addEventListener("input", on);
		return () => el.removeEventListener("input", on);
	}, []);
	function submit() {
		const el = ref.current;
		if (!el) return;
		const v = el.value;
		el.value = "";
		el.style.height = "auto";
		sendQuery(v);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-3xl px-4 pb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface p-2 shadow-[var(--elev-shadow)] focus-within:ring-2 focus-within:ring-accent/25",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				ref,
				rows: 1,
				placeholder: "Ask anything, or run: print(factor(123456789))",
				className: "max-h-44 w-full resize-none bg-transparent px-3 pt-2.5 pb-1 text-[15px] leading-relaxed text-fg outline-none placeholder:text-subtle",
				onKeyDown: (e) => {
					if (e.key === "Enter" && !e.shiftKey) {
						e.preventDefault();
						submit();
					}
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 px-1 pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								className: "text-muted",
								children: [MODELS.find((m) => m.id === model)?.label ?? "Auto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3 opacity-70" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
							align: "start",
							children: MODELS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => useMeridian.getState().patchSettings({ model: m.id }),
								className: cn(m.id === model && "bg-elevated"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1",
									children: m.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-subtle",
									children: m.hint
								})]
							}, m.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: think ? "secondary" : "ghost",
							size: "sm",
							className: cn(think && "text-fg"),
							onClick: () => useMeridian.getState().patchSettings({ think: !think }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, {}), "Think"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: search ? "secondary" : "ghost",
							size: "sm",
							className: cn("max-sm:hidden", search && "text-fg"),
							onClick: () => useMeridian.getState().patchSettings({ search: !search }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {}), "Search"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon-sm",
					className: "rounded-full",
					disabled: busy,
					"aria-label": "Send",
					onClick: submit,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-center text-[11px] text-subtle",
			children: [
				grokOn ? "Grok 4.5 is live. Lattice answers stay local." : "Running on the local lattice. Live Grok is offline.",
				" ",
				"Meridian can be wrong — check what matters."
			]
		})]
	});
}
function StatusBar() {
	const grokOn = useMeridian((s) => s.grokOn);
	const bootAt = useMeridian((s) => s.bootAt);
	const model = useMeridian((s) => s.settings.model);
	const [, tick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => tick((n) => n + 1), 1e3);
		return () => clearInterval(id);
	}, []);
	const fab = fabric.stats();
	const px = pixels.stats();
	const items = [
		{
			k: "Grok",
			v: grokOn ? "live" : "off",
			ok: grokOn
		},
		{
			k: "Model",
			v: model
		},
		{
			k: "Lattice",
			v: String(KNOWLEDGE.length)
		},
		{
			k: "Fabric",
			v: `${fab.dims}D · ${fab.shots}`
		},
		{
			k: "Pixels",
			v: String(px.count)
		},
		{
			k: "WAL",
			v: String(WAL.entries.length)
		},
		{
			k: "Cache",
			v: String(cacheStats().size)
		},
		{
			k: "Up",
			v: fmtUptime(Date.now() - bootAt)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 border-t border-border bg-surface px-4 py-1.5 font-mono text-[10px] text-muted",
		children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1.5 tabular-nums",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-subtle",
				children: it.k
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: it.ok ? "text-ok" : "text-fg",
				children: it.v
			})]
		}, it.k))
	});
}
function LatticePanel() {
	const [q, setQ] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("all");
	const hits = (0, import_react.useMemo)(() => {
		const base = q.trim() ? searchKnowledge(q, 40).map((h) => h.entry) : KNOWLEDGE;
		return cat === "all" ? base : base.filter((e) => e.category === cat);
	}, [q, cat]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-border px-5 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: "Lattice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [KNOWLEDGE.length, " grounded entries. Search or open a node."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search the lattice",
					className: "mt-3 h-10 w-full max-w-md rounded-md border border-border bg-elevated px-3 text-sm outline-none focus:ring-2 focus:ring-accent/25"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatChip, {
						id: "all",
						active: cat === "all",
						onClick: () => setCat("all")
					}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatChip, {
						id: c,
						active: cat === c,
						onClick: () => setCat(c)
					}, c))]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: hits.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void sendQuery(e.title),
					className: "rounded-lg bg-surface p-4 text-left shadow-[var(--elev-shadow)] transition-colors duration-150 hover:bg-elevated",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] tracking-wider text-subtle uppercase",
							children: e.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 font-medium",
							children: e.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 line-clamp-4 text-[13px] leading-relaxed text-muted",
							children: e.body
						})
					]
				}, e.id))
			})
		})]
	});
}
function CatChip({ id, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("rounded-full px-3 py-1 text-[11px] tracking-wide uppercase", active ? "bg-accent text-accent-fg" : "bg-elevated text-muted hover:text-fg"),
		children: id
	});
}
function FabricPanel() {
	const ref = (0, import_react.useRef)(null);
	const stats = fabric.stats();
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let t = 0;
		const draw = () => {
			const dpr = window.devicePixelRatio || 1;
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			const cs = getComputedStyle(document.documentElement);
			const bg = cs.getPropertyValue("--bg").trim() || "#0b0c0e";
			const fg = cs.getPropertyValue("--fg").trim() || "#ecece8";
			const muted = cs.getPropertyValue("--muted").trim() || "#8b909a";
			const accent = cs.getPropertyValue("--accent").trim() || "#c5cdd6";
			ctx.fillStyle = bg;
			ctx.fillRect(0, 0, w, h);
			const cx = w / 2;
			const cy = h / 2 + 10;
			const R = Math.min(w, h) * .38;
			t += .004;
			ctx.strokeStyle = muted;
			ctx.globalAlpha = .25;
			ctx.lineWidth = 1;
			for (let i = 0; i < 12; i++) {
				const a = i / 12 * Math.PI * 2;
				ctx.beginPath();
				ctx.moveTo(cx, cy - R * .15);
				ctx.quadraticCurveTo(cx + Math.cos(a) * R * .2, cy + R * .1, cx + Math.cos(a) * R, cy + Math.sin(a) * R * .55);
				ctx.stroke();
			}
			ctx.globalAlpha = 1;
			const shots = fabric.shots.slice(-64);
			shots.forEach((s, i) => {
				const ang = (s.coords.x / 256 * Math.PI * 2 + t) % (Math.PI * 2);
				const rad = R * (.2 + s.coords.y / 256 * .75);
				const x = cx + Math.cos(ang) * rad;
				const y = cy + Math.sin(ang) * rad * .55;
				const n = Hash.mix(s.query) % 100;
				ctx.fillStyle = i === shots.length - 1 ? accent : fg;
				ctx.globalAlpha = i === shots.length - 1 ? 1 : .25 + n / 200;
				ctx.beginPath();
				ctx.arc(x, y, i === shots.length - 1 ? 3.2 : 1.6, 0, Math.PI * 2);
				ctx.fill();
			});
			ctx.globalAlpha = 1;
			ctx.fillStyle = accent;
			ctx.beginPath();
			ctx.arc(cx, cy - R * .15, 3, 0, Math.PI * 2);
			ctx.fill();
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, []);
	const last = stats.last;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute top-5 left-5 z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: "Fabric"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 max-w-sm text-sm text-muted",
					children: [
						"1000-D continuum · ",
						stats.screens,
						" screens · ",
						stats.loci.toExponential(2),
						" loci"
					]
				}),
				last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-[11px] text-subtle",
					children: [
						"last · screen ",
						last.coords.screen,
						" · (",
						last.coords.x,
						",",
						last.coords.y,
						") · dim ",
						last.coords.dim,
						" · ",
						last.opsT.toFixed(2),
						" T"
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-subtle",
					children: "Ask a question to project a shot."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "h-full w-full"
		})]
	});
}
function WorkspacePanel() {
	const [q, setQ] = (0, import_react.useState)("");
	const [tick, setTick] = (0, import_react.useState)(0);
	const items = (0, import_react.useMemo)(() => pixels.search(q), [q, tick]);
	function refresh() {
		setTick((n) => n + 1);
	}
	function onFiles(files) {
		if (!files) return;
		Promise.all([...files].map((file) => new Promise((resolve) => {
			const reader = new FileReader();
			reader.onload = () => {
				const text = typeof reader.result === "string" ? reader.result : `Binary ${file.name}`;
				pixels.set({
					key: `file:${file.name}:${file.size}`,
					title: file.name,
					text: text.slice(0, 2e5),
					kind: "file",
					meta: {
						mime: file.type || "unknown",
						bytes: file.size
					}
				});
				resolve();
			};
			reader.onerror = () => resolve();
			if (file.size > 15e5) {
				pixels.set({
					key: `file:${file.name}:${file.size}`,
					title: file.name,
					text: `Large file (${fmtBytes(file.size)}). Name stored; content skipped.`,
					kind: "file",
					meta: {
						mime: file.type || "unknown",
						bytes: file.size
					}
				});
				resolve();
			} else reader.readAsText(file);
		}))).then(() => {
			toast.success("Ingested into workspace");
			refresh();
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault();
			onFiles(e.dataTransfer.files);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-border px-5 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: "Workspace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Notes, files, Wikipedia extracts, and proofs. Drop files anywhere here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Filter pixels",
							className: "h-10 w-full max-w-sm rounded-md border border-border bg-elevated px-3 text-sm outline-none focus:ring-2 focus:ring-accent/25"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "inline-flex h-10 cursor-pointer items-center rounded-md bg-elevated px-3 text-sm text-fg shadow-[var(--elev-shadow)]",
							children: ["Add files", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								multiple: true,
								className: "hidden",
								onChange: (e) => onFiles(e.target.files)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => {
								const title = prompt("Note title");
								if (!title) return;
								const text = prompt("Note body") || "";
								pixels.set({
									key: `note:${title}`,
									title,
									text,
									kind: "note"
								});
								refresh();
							},
							children: "New note"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto p-4",
			children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-2 py-10 text-center text-sm text-subtle",
				children: "Empty. Drop a file or write a note."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto max-w-3xl divide-y divide-border rounded-lg bg-surface shadow-[var(--elev-shadow)]",
				children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "mt-0.5 size-4 shrink-0 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-sm font-medium",
										children: p.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] tracking-wider text-subtle uppercase",
										children: p.kind
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[10px] text-subtle",
										children: fmtBytes(p.size)
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-2 text-[13px] text-muted",
								children: p.text
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Download",
							onClick: () => {
								const blob = new Blob([p.text], { type: "text/plain" });
								const a = document.createElement("a");
								a.href = URL.createObjectURL(blob);
								a.download = p.title || "pixel.txt";
								a.click();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Delete",
							onClick: () => {
								pixels.delete(p.key);
								refresh();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						})
					]
				}, p.key))
			})
		})]
	});
}
function TerminalPanel() {
	const lines = useMeridian((s) => s.term);
	const grokOn = useMeridian((s) => s.grokOn);
	const ref = (0, import_react.useRef)(null);
	async function run(raw) {
		const cmd = raw.trim();
		if (!cmd) return;
		const log = useMeridian.getState().termLog;
		log("in", "$ " + cmd);
		if (cmd === "clear") {
			useMeridian.setState({ term: [] });
			return;
		}
		if (cmd === "help") {
			log("out", "aether <code> · /help · /status · /lattice · /factor n · clear");
			return;
		}
		try {
			if (cmd.startsWith("/")) {
				const r = await handleCommand(cmd, grokOn);
				if (r) log(r.ok ? "ok" : "err", r.text);
				return;
			}
			const r = runAether(cmd);
			if (!r.ok) log("err", r.error || "error");
			else if (r.output.length) r.output.forEach((l) => log("out", l));
			else log("ok", String(r.value ?? "(ok)"));
		} catch (e) {
			log("err", e instanceof Error ? e.message : String(e));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col bg-code",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border px-5 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-xl text-fg",
					children: "Terminal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "Aether REPL. Prefix slash commands with /"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 py-3 font-mono text-[12.5px] leading-relaxed",
				children: [lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-subtle",
					children: "Ready. Try print(2+2) or /help"
				}) : null, lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("whitespace-pre-wrap", l.kind === "in" && "text-muted", l.kind === "out" && "text-fg", l.kind === "ok" && "text-ok", l.kind === "err" && "text-danger"),
					children: l.text
				}, l.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-center gap-2 border-t border-border px-3 py-2",
				onSubmit: (e) => {
					e.preventDefault();
					const el = ref.current;
					if (!el) return;
					const v = el.value;
					el.value = "";
					run(v);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-ok",
					children: "$"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref,
					className: "h-10 flex-1 bg-transparent font-mono text-sm text-fg outline-none",
					placeholder: "print(factor(99991))",
					autoComplete: "off"
				})]
			})
		]
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-overlay bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-modal w-[min(40rem,calc(100vw-1.5rem))] max-h-[84vh] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-xl bg-surface shadow-[var(--elev-shadow)]", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-sm",
				className: "absolute top-3 right-3",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("border-b border-border px-5 py-4", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl text-fg", className),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 items-center rounded-full border border-border bg-elevated transition-colors data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-4 translate-x-0.5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-accent-fg" })
	});
}
function SettingsDialog() {
	const open = useMeridian((s) => s.settingsOpen);
	const settings = useMeridian((s) => s.settings);
	const grokOn = useMeridian((s) => s.grokOn);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => useMeridian.getState().setSettingsOpen(v),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Settings" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[70vh] space-y-5 overflow-y-auto px-5 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Dark theme",
					hint: "Saved on this device",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.theme === "dark",
						onCheckedChange: (c) => useMeridian.getState().patchSettings({ theme: c ? "dark" : "light" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Deep Think",
					hint: "Ask Grok to reason more carefully",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.think,
						onCheckedChange: (c) => useMeridian.getState().patchSettings({ think: c })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Wikipedia search",
					hint: "Ground answers with a live summary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.search,
						onCheckedChange: (c) => useMeridian.getState().patchSettings({ search: c })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Grok",
							v: grokOn ? "live" : "off"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Lattice",
							v: String(KNOWLEDGE.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Experts",
							v: String(EXPERTS.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Pixels",
							v: String(pixels.stats().count)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "WAL",
							v: String(WAL.entries.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Cache",
							v: String(cacheStats().size)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: "Conversations, notes, and the write-ahead log stay in this browser. Grok calls are user-initiated and spend the app owner's xAI quota."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					size: "sm",
					onClick: () => {
						if (!confirm("Wipe local history, pixels, and WAL?")) return;
						useMeridian.getState().clearHistory();
						pixels.items.clear();
						pixels.persist();
						WAL.clear();
					},
					children: "Wipe local memory"
				})
			]
		})] })
	});
}
function Row({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4 border-b border-border py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-subtle",
			children: hint
		})] }), children]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-elevated px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-lg",
			children: v
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] tracking-wider text-subtle uppercase",
			children: k
		})]
	});
}
var GO = [
	{
		id: "chat",
		label: "Go to Query"
	},
	{
		id: "lattice",
		label: "Go to Lattice"
	},
	{
		id: "fabric",
		label: "Go to Fabric"
	},
	{
		id: "workspace",
		label: "Go to Workspace"
	},
	{
		id: "terminal",
		label: "Go to Terminal"
	}
];
function CommandPalette() {
	const open = useMeridian((s) => s.paletteOpen);
	const [q, setQ] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const on = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				useMeridian.getState().setPaletteOpen(!useMeridian.getState().paletteOpen);
			}
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
				e.preventDefault();
				useMeridian.getState().newChat();
			}
			if (e.key === "Escape") useMeridian.getState().setPaletteOpen(false);
		};
		window.addEventListener("keydown", on);
		return () => window.removeEventListener("keydown", on);
	}, []);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-max flex items-start justify-center bg-bg/70 pt-[18vh]",
		onClick: () => useMeridian.getState().setPaletteOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(_e, {
			className: "w-[min(32rem,calc(100vw-1.5rem))] overflow-hidden rounded-xl bg-surface shadow-[var(--elev-shadow)]",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Input, {
				value: q,
				onValueChange: setQ,
				placeholder: "Jump, ask, or run a command",
				className: "h-12 w-full border-b border-border bg-transparent px-4 text-sm outline-none"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(_e.List, {
				className: "max-h-80 overflow-y-auto p-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Empty, {
						className: "px-3 py-6 text-center text-sm text-subtle",
						children: "No matches"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Group, {
						heading: "Navigate",
						className: "px-2 py-1 text-[10px] tracking-wider text-subtle uppercase",
						children: GO.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
							value: g.label,
							className: "flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated",
							onSelect: () => {
								useMeridian.getState().setView(g.id);
								useMeridian.getState().setPaletteOpen(false);
							},
							children: g.label
						}, g.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
						value: "New query",
						className: "flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated",
						onSelect: () => {
							useMeridian.getState().newChat();
							useMeridian.getState().setPaletteOpen(false);
						},
						children: "New query"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
						value: "Settings",
						className: "flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated",
						onSelect: () => {
							useMeridian.getState().setSettingsOpen(true);
							useMeridian.getState().setPaletteOpen(false);
						},
						children: "Open settings"
					}),
					q.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(_e.Item, {
						value: `Ask ${q}`,
						className: "flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated",
						onSelect: () => {
							useMeridian.getState().setPaletteOpen(false);
							useMeridian.getState().setView("chat");
							sendQuery(q);
						},
						children: [
							"Ask “",
							q,
							"”"
						]
					}) : null
				]
			})]
		})
	});
}
function AppShell() {
	const ready = useMeridian((s) => s.ready);
	const view = useMeridian((s) => s.view);
	const theme = useMeridian((s) => s.settings.theme);
	(0, import_react.useEffect)(() => {
		useMeridian.getState().hydrate();
		grokStatus().then((r) => useMeridian.getState().setGrokOn(Boolean(r.available)));
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "shimmer-text text-sm",
				children: "Opening the lattice"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex h-12 shrink-0 items-center gap-2 border-b border-border px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								className: "md:hidden",
								"aria-label": "Menu",
								onClick: () => useMeridian.getState().setSidebar(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-base md:hidden",
								children: "Meridian"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Command palette",
									onClick: () => useMeridian.getState().setPaletteOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Command, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Toggle theme",
									onClick: () => useMeridian.getState().patchSettings({ theme: theme === "dark" ? "light" : "dark" }),
									children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {})
								})]
							})
						]
					}),
					view === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPane, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})] }) : view === "lattice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LatticePanel, {}) : view === "fabric" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FabricPanel, {}) : view === "workspace" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspacePanel, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerminalPanel, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandPalette, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme,
				position: "bottom-center"
			})
		]
	}) });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
