//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-uYst5_UG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BG53j0SZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BG53j0SZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BG048bWx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
