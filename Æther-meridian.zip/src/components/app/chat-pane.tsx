import { useEffect, useRef } from "react";
import { Copy, RotateCcw } from "lucide-react";
import { Markdown } from "@/lib/engine/markdown";
import { useMeridian } from "@/lib/store";
import { sendQuery } from "@/lib/engine/send";
import { Button } from "@/components/ui/button";
import { MeridianMark } from "./mark";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "What is the speed of light?",
  "Factor 123456789",
  "run: for i in range(8) { print(i * i) }",
  "Explain quantum entanglement",
  "/help",
  "How does a transformer work?",
];

export function ChatPane() {
  const conv = useMeridian((s) => s.history.find((c) => c.id === s.currentId) ?? null);
  const busy = useMeridian((s) => s.busy);
  const bottom = useRef<HTMLDivElement>(null);
  const msgs = conv?.msgs ?? [];

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [msgs.length, busy]);

  if (!msgs.length && !busy) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-10">
        <MeridianMark className="size-14 animate-fade-up" />
        <h1 className="animate-fade-up stagger-1 mt-6 font-display text-4xl tracking-tight text-fg sm:text-5xl">
          Meridian
        </h1>
        <p className="animate-fade-up stagger-2 mt-2 max-w-md text-center text-sm text-muted">
          A grounded workspace. Local lattice first, live Grok when it earns the call.
        </p>
        <div className="animate-fade-up stagger-3 mt-8 flex max-w-xl flex-wrap justify-center gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => void sendQuery(s)}
              className="rounded-full border border-border bg-surface px-3.5 py-2 text-left text-[13px] text-muted transition-colors duration-150 hover:border-border-strong hover:text-fg"
            >
              {s}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8">
        {msgs.map((m) => (
          <article key={m.id} className={cn("flex gap-3", m.role === "user" && "flex-row-reverse")}>
            {m.role === "assistant" ? (
              <div className="mt-0.5 shrink-0">
                <MeridianMark className="size-8" />
              </div>
            ) : (
              <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-user text-[11px] font-medium text-muted">
                You
              </div>
            )}
            <div className={cn("min-w-0 max-w-[min(100%,560px)]", m.role === "user" && "flex flex-col items-end")}>
              {m.role === "user" ? (
                <div className="rounded-lg rounded-br-sm bg-user px-3.5 py-2.5 text-[15px] leading-relaxed text-fg">
                  {m.text}
                </div>
              ) : (
                <div>
                  <div className="mb-1 flex items-center gap-2 text-[11px] text-subtle">
                    <span className="uppercase tracking-wider">{m.kind || "Meridian"}</span>
                    {m.cached ? <span className="text-ok">cached</span> : null}
                    {typeof m.ms === "number" ? <span className="font-mono tabular-nums">{Math.round(m.ms)}ms</span> : null}
                  </div>
                  {m.kind === "error" ? (
                    <p className="text-sm text-danger">{m.text}</p>
                  ) : (
                    <Markdown text={m.text} />
                  )}
                  {m.sources?.length ? (
                    <p className="mt-2 text-[11px] text-subtle">Sources: {m.sources.join(" · ")}</p>
                  ) : null}
                  <div className="mt-1 flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="Copy"
                      onClick={() => {
                        void navigator.clipboard.writeText(m.text);
                        toast.success("Copied");
                      }}
                    >
                      <Copy />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="Ask again"
                      onClick={() => {
                        const prev = msgs[msgs.indexOf(m) - 1];
                        if (prev?.role === "user") void sendQuery(prev.text);
                      }}
                    >
                      <RotateCcw />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </article>
        ))}
        {busy ? (
          <div className="flex items-center gap-3">
            <MeridianMark className="size-8" />
            <div className="flex gap-1.5 py-2">
              <i className="typing-dot size-1.5 rounded-full bg-muted" />
              <i className="typing-dot size-1.5 rounded-full bg-muted" style={{ animationDelay: "0.18s" }} />
              <i className="typing-dot size-1.5 rounded-full bg-muted" style={{ animationDelay: "0.36s" }} />
            </div>
            <span className="shimmer-text text-xs">Reasoning</span>
          </div>
        ) : null}
        <div ref={bottom} />
      </div>
    </div>
  );
}
