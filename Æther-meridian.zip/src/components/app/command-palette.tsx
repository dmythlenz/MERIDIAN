import { useEffect, useState } from "react";
import { Command } from "cmdk";
import { useMeridian, type ViewId } from "@/lib/store";
import { sendQuery } from "@/lib/engine/send";

const GO: { id: ViewId; label: string }[] = [
  { id: "chat", label: "Go to Query" },
  { id: "lattice", label: "Go to Lattice" },
  { id: "fabric", label: "Go to Fabric" },
  { id: "workspace", label: "Go to Workspace" },
  { id: "terminal", label: "Go to Terminal" },
];

export function CommandPalette() {
  const open = useMeridian((s) => s.paletteOpen);
  const [q, setQ] = useState("");

  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        useMeridian.getState().setPaletteOpen(!useMeridian.getState().paletteOpen);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        useMeridian.getState().newChat();
      }
      if (e.key === "Escape") useMeridian.getState().setPaletteOpen(false);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, []);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-max flex items-start justify-center bg-bg/70 pt-[18vh]" onClick={() => useMeridian.getState().setPaletteOpen(false)}>
      <Command
        className="w-[min(32rem,calc(100vw-1.5rem))] overflow-hidden rounded-xl bg-surface shadow-[var(--elev-shadow)]"
        onClick={(e) => e.stopPropagation()}
      >
        <Command.Input
          value={q}
          onValueChange={setQ}
          placeholder="Jump, ask, or run a command"
          className="h-12 w-full border-b border-border bg-transparent px-4 text-sm outline-none"
        />
        <Command.List className="max-h-80 overflow-y-auto p-1">
          <Command.Empty className="px-3 py-6 text-center text-sm text-subtle">No matches</Command.Empty>
          <Command.Group heading="Navigate" className="px-2 py-1 text-[10px] tracking-wider text-subtle uppercase">
            {GO.map((g) => (
              <Command.Item
                key={g.id}
                value={g.label}
                className="flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated"
                onSelect={() => {
                  useMeridian.getState().setView(g.id);
                  useMeridian.getState().setPaletteOpen(false);
                }}
              >
                {g.label}
              </Command.Item>
            ))}
          </Command.Group>
          <Command.Item
            value="New query"
            className="flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated"
            onSelect={() => {
              useMeridian.getState().newChat();
              useMeridian.getState().setPaletteOpen(false);
            }}
          >
            New query
          </Command.Item>
          <Command.Item
            value="Settings"
            className="flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated"
            onSelect={() => {
              useMeridian.getState().setSettingsOpen(true);
              useMeridian.getState().setPaletteOpen(false);
            }}
          >
            Open settings
          </Command.Item>
          {q.trim() ? (
            <Command.Item
              value={`Ask ${q}`}
              className="flex cursor-pointer items-center rounded-md px-2 py-2 text-sm data-[selected=true]:bg-elevated"
              onSelect={() => {
                useMeridian.getState().setPaletteOpen(false);
                useMeridian.getState().setView("chat");
                void sendQuery(q);
              }}
            >
              Ask “{q}”
            </Command.Item>
          ) : null}
        </Command.List>
      </Command>
    </div>
  );
}
