import { useEffect, useRef } from "react";
import { ArrowUp, Brain, Globe, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useMeridian } from "@/lib/store";
import { sendQuery } from "@/lib/engine/send";
import { cn } from "@/lib/utils";
import type { ModelId } from "@/lib/engine/oracle";

const MODELS: { id: ModelId; label: string; hint: string }[] = [
  { id: "auto", label: "Auto", hint: "Lattice, then Grok" },
  { id: "grok", label: "Grok 4.5", hint: "Live reasoning" },
  { id: "oracle", label: "Oracle", hint: "Local lattice only" },
  { id: "aether", label: "Aether", hint: "Run as code" },
  { id: "expert", label: "Expert", hint: "Domain routing" },
];

export function Composer() {
  const ref = useRef<HTMLTextAreaElement>(null);
  const model = useMeridian((s) => s.settings.model);
  const think = useMeridian((s) => s.settings.think);
  const search = useMeridian((s) => s.settings.search);
  const busy = useMeridian((s) => s.busy);
  const grokOn = useMeridian((s) => s.grokOn);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const on = () => {
      el.style.height = "auto";
      el.style.height = Math.min(el.scrollHeight, 180) + "px";
    };
    el.addEventListener("input", on);
    return () => el.removeEventListener("input", on);
  }, []);

  function submit() {
    const el = ref.current;
    if (!el) return;
    const v = el.value;
    el.value = "";
    el.style.height = "auto";
    void sendQuery(v);
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-3">
      <div className="rounded-xl bg-surface p-2 shadow-[var(--elev-shadow)] focus-within:ring-2 focus-within:ring-accent/25">
        <textarea
          ref={ref}
          rows={1}
          placeholder="Ask anything, or run: print(factor(123456789))"
          className="max-h-44 w-full resize-none bg-transparent px-3 pt-2.5 pb-1 text-[15px] leading-relaxed text-fg outline-none placeholder:text-subtle"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
        />
        <div className="flex items-center justify-between gap-2 px-1 pb-1">
          <div className="flex min-w-0 items-center gap-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-muted">
                  {MODELS.find((m) => m.id === model)?.label ?? "Auto"}
                  <ChevronDown className="size-3 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {MODELS.map((m) => (
                  <DropdownMenuItem
                    key={m.id}
                    onSelect={() => useMeridian.getState().patchSettings({ model: m.id })}
                    className={cn(m.id === model && "bg-elevated")}
                  >
                    <span className="flex-1">{m.label}</span>
                    <span className="text-[11px] text-subtle">{m.hint}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant={think ? "secondary" : "ghost"}
              size="sm"
              className={cn(think && "text-fg")}
              onClick={() => useMeridian.getState().patchSettings({ think: !think })}
            >
              <Brain />
              Think
            </Button>
            <Button
              variant={search ? "secondary" : "ghost"}
              size="sm"
              className={cn("max-sm:hidden", search && "text-fg")}
              onClick={() => useMeridian.getState().patchSettings({ search: !search })}
            >
              <Globe />
              Search
            </Button>
          </div>
          <Button
            size="icon-sm"
            className="rounded-full"
            disabled={busy}
            aria-label="Send"
            onClick={submit}
          >
            <ArrowUp />
          </Button>
        </div>
      </div>
      <p className="mt-2 text-center text-[11px] text-subtle">
        {grokOn ? "Grok 4.5 is live. Lattice answers stay local." : "Running on the local lattice. Live Grok is offline."}{" "}
        Meridian can be wrong — check what matters.
      </p>
    </div>
  );
}
