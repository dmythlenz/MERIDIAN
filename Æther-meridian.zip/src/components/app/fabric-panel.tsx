import { useEffect, useRef } from "react";
import { fabric } from "@/lib/engine/fabric";
import { Hash } from "@/lib/engine/hash";

export function FabricPanel() {
  const ref = useRef<HTMLCanvasElement>(null);
  const stats = fabric.stats();

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let t = 0;

    const draw = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const cs = getComputedStyle(document.documentElement);
      const bg = cs.getPropertyValue("--bg").trim() || "#0b0c0e";
      const fg = cs.getPropertyValue("--fg").trim() || "#ecece8";
      const muted = cs.getPropertyValue("--muted").trim() || "#8b909a";
      const accent = cs.getPropertyValue("--accent").trim() || "#c5cdd6";
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2 + 10;
      const R = Math.min(w, h) * 0.38;
      t += 0.004;

      ctx.strokeStyle = muted;
      ctx.globalAlpha = 0.25;
      ctx.lineWidth = 1;
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy - R * 0.15);
        ctx.quadraticCurveTo(cx + Math.cos(a) * R * 0.2, cy + R * 0.1, cx + Math.cos(a) * R, cy + Math.sin(a) * R * 0.55);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      const shots = fabric.shots.slice(-64);
      shots.forEach((s, i) => {
        const ang = ((s.coords.x / 256) * Math.PI * 2 + t) % (Math.PI * 2);
        const rad = R * (0.2 + (s.coords.y / 256) * 0.75);
        const x = cx + Math.cos(ang) * rad;
        const y = cy + Math.sin(ang) * rad * 0.55;
        const n = Hash.mix(s.query) % 100;
        ctx.fillStyle = i === shots.length - 1 ? accent : fg;
        ctx.globalAlpha = i === shots.length - 1 ? 1 : 0.25 + n / 200;
        ctx.beginPath();
        ctx.arc(x, y, i === shots.length - 1 ? 3.2 : 1.6, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;

      ctx.fillStyle = accent;
      ctx.beginPath();
      ctx.arc(cx, cy - R * 0.15, 3, 0, Math.PI * 2);
      ctx.fill();

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  const last = stats.last;

  return (
    <div className="relative flex min-h-0 flex-1 flex-col">
      <div className="pointer-events-none absolute top-5 left-5 z-10">
        <h1 className="font-display text-2xl">Fabric</h1>
        <p className="mt-1 max-w-sm text-sm text-muted">
          1000-D continuum · {stats.screens} screens · {stats.loci.toExponential(2)} loci
        </p>
        {last ? (
          <p className="mt-3 font-mono text-[11px] text-subtle">
            last · screen {last.coords.screen} · ({last.coords.x},{last.coords.y}) · dim {last.coords.dim} · {last.opsT.toFixed(2)} T
          </p>
        ) : (
          <p className="mt-3 text-sm text-subtle">Ask a question to project a shot.</p>
        )}
      </div>
      <canvas ref={ref} className="h-full w-full" />
    </div>
  );
}
