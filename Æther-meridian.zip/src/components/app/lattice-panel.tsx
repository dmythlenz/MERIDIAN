import { useMemo, useState } from "react";
import { KNOWLEDGE, CATEGORIES, searchKnowledge } from "@/lib/engine/knowledge";
import { sendQuery } from "@/lib/engine/send";
import { cn } from "@/lib/utils";

export function LatticePanel() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const hits = useMemo(() => {
    const base = q.trim() ? searchKnowledge(q, 40).map((h) => h.entry) : KNOWLEDGE;
    return cat === "all" ? base : base.filter((e) => e.category === cat);
  }, [q, cat]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="border-b border-border px-5 py-4">
        <h1 className="font-display text-2xl">Lattice</h1>
        <p className="mt-1 text-sm text-muted">{KNOWLEDGE.length} grounded entries. Search or open a node.</p>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search the lattice"
          className="mt-3 h-10 w-full max-w-md rounded-md border border-border bg-elevated px-3 text-sm outline-none focus:ring-2 focus:ring-accent/25"
        />
        <div className="mt-3 flex flex-wrap gap-1.5">
          <CatChip id="all" active={cat === "all"} onClick={() => setCat("all")} />
          {CATEGORIES.map((c) => (
            <CatChip key={c} id={c} active={cat === c} onClick={() => setCat(c)} />
          ))}
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        <div className="mx-auto grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {hits.map((e) => (
            <button
              key={e.id}
              type="button"
              onClick={() => void sendQuery(e.title)}
              className="rounded-lg bg-surface p-4 text-left shadow-[var(--elev-shadow)] transition-colors duration-150 hover:bg-elevated"
            >
              <div className="text-[10px] tracking-wider text-subtle uppercase">{e.category}</div>
              <div className="mt-1 font-medium">{e.title}</div>
              <p className="mt-2 line-clamp-4 text-[13px] leading-relaxed text-muted">{e.body}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function CatChip({ id, active, onClick }: { id: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full px-3 py-1 text-[11px] tracking-wide uppercase",
        active ? "bg-accent text-accent-fg" : "bg-elevated text-muted hover:text-fg",
      )}
    >
      {id}
    </button>
  );
}
