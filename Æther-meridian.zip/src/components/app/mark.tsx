import { cn } from "@/lib/utils";

export function MeridianMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden>
      <rect width="32" height="32" rx="8" className="fill-elevated" />
      <path
        d="M8 26 A 8 18 0 0 1 24 26"
        fill="none"
        className="stroke-accent"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <circle cx="16" cy="8" r="2.4" className="fill-accent" />
    </svg>
  );
}
