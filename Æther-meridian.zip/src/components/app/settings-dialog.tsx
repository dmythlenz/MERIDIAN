import type { ReactNode } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useMeridian } from "@/lib/store";
import { KNOWLEDGE } from "@/lib/engine/knowledge";
import { EXPERTS } from "@/lib/engine/experts";
import { pixels } from "@/lib/engine/pixels";
import { WAL } from "@/lib/engine/wal";
import { cacheStats } from "@/lib/engine/oracle";

export function SettingsDialog() {
  const open = useMeridian((s) => s.settingsOpen);
  const settings = useMeridian((s) => s.settings);
  const grokOn = useMeridian((s) => s.grokOn);

  return (
    <Dialog open={open} onOpenChange={(v) => useMeridian.getState().setSettingsOpen(v)}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
        </DialogHeader>
        <div className="max-h-[70vh] space-y-5 overflow-y-auto px-5 py-4">
          <Row label="Dark theme" hint="Saved on this device">
            <Switch
              checked={settings.theme === "dark"}
              onCheckedChange={(c) => useMeridian.getState().patchSettings({ theme: c ? "dark" : "light" })}
            />
          </Row>
          <Row label="Deep Think" hint="Ask Grok to reason more carefully">
            <Switch
              checked={settings.think}
              onCheckedChange={(c) => useMeridian.getState().patchSettings({ think: c })}
            />
          </Row>
          <Row label="Wikipedia search" hint="Ground answers with a live summary">
            <Switch
              checked={settings.search}
              onCheckedChange={(c) => useMeridian.getState().patchSettings({ search: c })}
            />
          </Row>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat k="Grok" v={grokOn ? "live" : "off"} />
            <Stat k="Lattice" v={String(KNOWLEDGE.length)} />
            <Stat k="Experts" v={String(EXPERTS.length)} />
            <Stat k="Pixels" v={String(pixels.stats().count)} />
            <Stat k="WAL" v={String(WAL.entries.length)} />
            <Stat k="Cache" v={String(cacheStats().size)} />
          </div>
          <p className="text-xs leading-relaxed text-muted">
            Conversations, notes, and the write-ahead log stay in this browser. Grok calls are user-initiated and
            spend the app owner's xAI quota.
          </p>
          <Button
            variant="danger"
            size="sm"
            onClick={() => {
              if (!confirm("Wipe local history, pixels, and WAL?")) return;
              useMeridian.getState().clearHistory();
              pixels.items.clear();
              pixels.persist();
              WAL.clear();
            }}
          >
            Wipe local memory
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, hint, children }: { label: string; hint: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-border py-3">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-subtle">{hint}</div>
      </div>
      {children}
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-md bg-elevated px-3 py-2">
      <div className="font-display text-lg">{v}</div>
      <div className="text-[10px] tracking-wider text-subtle uppercase">{k}</div>
    </div>
  );
}
