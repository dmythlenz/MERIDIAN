import { useEffect } from "react";
import { Menu, Moon, Sun, Command as CommandIcon } from "lucide-react";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useMeridian } from "@/lib/store";
import { grokStatus } from "@/lib/ai/grok";
import { Sidebar } from "./sidebar";
import { ChatPane } from "./chat-pane";
import { Composer } from "./composer";
import { StatusBar } from "./status-bar";
import { LatticePanel } from "./lattice-panel";
import { FabricPanel } from "./fabric-panel";
import { WorkspacePanel } from "./workspace-panel";
import { TerminalPanel } from "./terminal-panel";
import { SettingsDialog } from "./settings-dialog";
import { CommandPalette } from "./command-palette";
import { MeridianMark } from "./mark";

export function AppShell() {
  const ready = useMeridian((s) => s.ready);
  const view = useMeridian((s) => s.view);
  const theme = useMeridian((s) => s.settings.theme);

  useEffect(() => {
    useMeridian.getState().hydrate();
    void grokStatus().then((r) => useMeridian.getState().setGrokOn(Boolean(r.available)));
  }, []);

  if (!ready) {
    return (
      <div className="flex h-full items-center justify-center bg-bg text-fg">
        <div className="flex flex-col items-center gap-3">
          <MeridianMark className="size-12" />
          <p className="shimmer-text text-sm">Opening the lattice</p>
        </div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="flex h-full bg-bg text-fg">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-3">
            <Button
              variant="ghost"
              size="icon-sm"
              className="md:hidden"
              aria-label="Menu"
              onClick={() => useMeridian.getState().setSidebar(true)}
            >
              <Menu />
            </Button>
            <span className="font-display text-base md:hidden">Meridian</span>
            <div className="ml-auto flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Command palette"
                onClick={() => useMeridian.getState().setPaletteOpen(true)}
              >
                <CommandIcon />
              </Button>
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Toggle theme"
                onClick={() =>
                  useMeridian.getState().patchSettings({ theme: theme === "dark" ? "light" : "dark" })
                }
              >
                {theme === "dark" ? <Sun /> : <Moon />}
              </Button>
            </div>
          </header>
          {view === "chat" ? (
            <>
              <ChatPane />
              <Composer />
            </>
          ) : view === "lattice" ? (
            <LatticePanel />
          ) : view === "fabric" ? (
            <FabricPanel />
          ) : view === "workspace" ? (
            <WorkspacePanel />
          ) : (
            <TerminalPanel />
          )}
          <StatusBar />
        </div>
        <SettingsDialog />
        <CommandPalette />
        <Toaster theme={theme} position="bottom-center" />
      </div>
    </TooltipProvider>
  );
}
