import { MessageSquarePlus, Trash2, Hexagon, Orbit, FolderOpen, Terminal, Settings, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { MeridianMark } from "./mark";
import { useMeridian, type ViewId } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV: { id: ViewId; label: string; icon: typeof Hexagon }[] = [
  { id: "chat", label: "Query", icon: Hexagon },
  { id: "lattice", label: "Lattice", icon: Orbit },
  { id: "fabric", label: "Fabric", icon: Hexagon },
  { id: "workspace", label: "Workspace", icon: FolderOpen },
  { id: "terminal", label: "Terminal", icon: Terminal },
];

export function Sidebar() {
  const history = useMeridian((s) => s.history);
  const currentId = useMeridian((s) => s.currentId);
  const view = useMeridian((s) => s.view);
  const open = useMeridian((s) => s.sidebarOpen);
  const grokOn = useMeridian((s) => s.grokOn);

  return (
    <>
      {open ? (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-bg/60 md:hidden"
          aria-label="Close menu"
          onClick={() => useMeridian.getState().setSidebar(false)}
        />
      ) : null}
      <aside
        className={cn(
          "flex h-full w-[248px] shrink-0 flex-col border-r border-border bg-surface",
          "fixed inset-y-0 left-0 z-50 transition-transform duration-200",
          open ? "translate-x-0" : "-translate-x-full",
          "md:relative md:z-auto md:translate-x-0",
        )}
      >
        <div className="flex items-center gap-2.5 px-4 pt-5 pb-3">
          <MeridianMark className="size-8" />
          <div className="min-w-0 flex-1">
            <div className="font-display text-lg leading-none tracking-tight">Meridian</div>
            <div className="mt-1 text-[10px] tracking-[0.14em] text-subtle uppercase">Grounded intelligence</div>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            className="md:hidden"
            aria-label="Close"
            onClick={() => useMeridian.getState().setSidebar(false)}
          >
            <X />
          </Button>
        </div>

        <div className="px-3">
          <Button
            className="w-full justify-start"
            onClick={() => useMeridian.getState().newChat()}
          >
            <MessageSquarePlus />
            New query
          </Button>
        </div>

        <nav className="mt-3 grid grid-cols-1 gap-0.5 px-2">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => useMeridian.getState().setView(item.id)}
                className={cn(
                  "flex h-10 items-center gap-2.5 rounded-md px-3 text-sm transition-colors duration-150",
                  active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/70 hover:text-fg",
                )}
              >
                <Icon className="size-4" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="mt-4 flex items-center justify-between px-4">
          <span className="text-[10px] tracking-[0.16em] text-subtle uppercase">History</span>
          <button
            type="button"
            className="text-subtle hover:text-danger"
            aria-label="Clear history"
            onClick={() => {
              if (confirm("Clear all conversations?")) useMeridian.getState().clearHistory();
            }}
          >
            <Trash2 className="size-3.5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-2">
          {history.length === 0 ? (
            <p className="px-2 py-3 text-xs text-subtle">No queries yet</p>
          ) : (
            history.map((c) => (
              <div
                key={c.id}
                className={cn(
                  "group flex items-center gap-1 rounded-md",
                  c.id === currentId ? "bg-elevated" : "hover:bg-elevated/60",
                )}
              >
                <button
                  type="button"
                  className={cn(
                    "min-w-0 flex-1 truncate px-3 py-2 text-left text-[13px]",
                    c.id === currentId ? "text-fg" : "text-muted",
                  )}
                  onClick={() => useMeridian.getState().loadChat(c.id)}
                >
                  {c.title}
                </button>
                <button
                  type="button"
                  className="px-2 py-2 text-subtle opacity-0 group-hover:opacity-100 hover:text-danger"
                  aria-label="Delete conversation"
                  onClick={() => useMeridian.getState().deleteChat(c.id)}
                >
                  <X className="size-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        <Separator />
        <div className="flex items-center gap-2 px-3 py-3">
          <span className={cn("size-1.5 rounded-full", grokOn ? "bg-ok" : "bg-subtle")} />
          <span className="flex-1 font-mono text-[11px] text-muted">{grokOn ? "Grok live" : "Lattice only"}</span>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Settings"
            onClick={() => useMeridian.getState().setSettingsOpen(true)}
          >
            <Settings />
          </Button>
        </div>
      </aside>
    </>
  );
}
