import { useEffect, useState } from "react";
import { useMeridian } from "@/lib/store";
import { fabric } from "@/lib/engine/fabric";
import { pixels } from "@/lib/engine/pixels";
import { WAL } from "@/lib/engine/wal";
import { KNOWLEDGE } from "@/lib/engine/knowledge";
import { cacheStats } from "@/lib/engine/oracle";
import { fmtUptime } from "@/lib/utils";

export function StatusBar() {
  const grokOn = useMeridian((s) => s.grokOn);
  const bootAt = useMeridian((s) => s.bootAt);
  const model = useMeridian((s) => s.settings.model);
  const [, tick] = useState(0);

  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const fab = fabric.stats();
  const px = pixels.stats();

  const items = [
    { k: "Grok", v: grokOn ? "live" : "off", ok: grokOn },
    { k: "Model", v: model },
    { k: "Lattice", v: String(KNOWLEDGE.length) },
    { k: "Fabric", v: `${fab.dims}D · ${fab.shots}` },
    { k: "Pixels", v: String(px.count) },
    { k: "WAL", v: String(WAL.entries.length) },
    { k: "Cache", v: String(cacheStats().size) },
    { k: "Up", v: fmtUptime(Date.now() - bootAt) },
  ];

  return (
    <footer className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 border-t border-border bg-surface px-4 py-1.5 font-mono text-[10px] text-muted">
      {items.map((it) => (
        <span key={it.k} className="inline-flex items-center gap-1.5 tabular-nums">
          <span className="text-subtle">{it.k}</span>
          <span className={it.ok ? "text-ok" : "text-fg"}>{it.v}</span>
        </span>
      ))}
    </footer>
  );
}
