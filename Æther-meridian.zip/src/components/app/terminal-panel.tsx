import { useRef } from "react";
import { useMeridian } from "@/lib/store";
import { handleCommand } from "@/lib/engine/oracle";
import { runAether } from "@/lib/engine/aether";
import { cn } from "@/lib/utils";

export function TerminalPanel() {
  const lines = useMeridian((s) => s.term);
  const grokOn = useMeridian((s) => s.grokOn);
  const ref = useRef<HTMLInputElement>(null);

  async function run(raw: string) {
    const cmd = raw.trim();
    if (!cmd) return;
    const log = useMeridian.getState().termLog;
    log("in", "$ " + cmd);
    if (cmd === "clear") {
      useMeridian.setState({ term: [] });
      return;
    }
    if (cmd === "help") {
      log("out", "aether <code> · /help · /status · /lattice · /factor n · clear");
      return;
    }
    try {
      if (cmd.startsWith("/")) {
        const r = await handleCommand(cmd, grokOn);
        if (r) log(r.ok ? "ok" : "err", r.text);
        return;
      }
      const r = runAether(cmd);
      if (!r.ok) log("err", r.error || "error");
      else if (r.output.length) r.output.forEach((l) => log("out", l));
      else log("ok", String(r.value ?? "(ok)"));
    } catch (e) {
      log("err", e instanceof Error ? e.message : String(e));
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-code">
      <div className="border-b border-border px-5 py-3">
        <h1 className="font-display text-xl text-fg">Terminal</h1>
        <p className="text-xs text-subtle">Aether REPL. Prefix slash commands with /</p>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3 font-mono text-[12.5px] leading-relaxed">
        {lines.length === 0 ? <div className="text-subtle">Ready. Try print(2+2) or /help</div> : null}
        {lines.map((l) => (
          <div
            key={l.id}
            className={cn(
              "whitespace-pre-wrap",
              l.kind === "in" && "text-muted",
              l.kind === "out" && "text-fg",
              l.kind === "ok" && "text-ok",
              l.kind === "err" && "text-danger",
            )}
          >
            {l.text}
          </div>
        ))}
      </div>
      <form
        className="flex items-center gap-2 border-t border-border px-3 py-2"
        onSubmit={(e) => {
          e.preventDefault();
          const el = ref.current;
          if (!el) return;
          const v = el.value;
          el.value = "";
          void run(v);
        }}
      >
        <span className="font-mono text-ok">$</span>
        <input
          ref={ref}
          className="h-10 flex-1 bg-transparent font-mono text-sm text-fg outline-none"
          placeholder="print(factor(99991))"
          autoComplete="off"
        />
      </form>
    </div>
  );
}
