import { useMemo, useState } from "react";
import { FileText, Trash2, Download } from "lucide-react";
import { pixels } from "@/lib/engine/pixels";
import { Button } from "@/components/ui/button";
import { fmtBytes } from "@/lib/utils";
import { toast } from "sonner";

export function WorkspacePanel() {
  const [q, setQ] = useState("");
  const [tick, setTick] = useState(0);
  const items = useMemo(() => pixels.search(q), [q, tick]);

  function refresh() {
    setTick((n) => n + 1);
  }

  function onFiles(files: FileList | null) {
    if (!files) return;
    void Promise.all(
      [...files].map(
        (file) =>
          new Promise<void>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => {
              const text = typeof reader.result === "string" ? reader.result : `Binary ${file.name}`;
              pixels.set({
                key: `file:${file.name}:${file.size}`,
                title: file.name,
                text: text.slice(0, 200_000),
                kind: "file",
                meta: { mime: file.type || "unknown", bytes: file.size },
              });
              resolve();
            };
            reader.onerror = () => resolve();
            if (file.size > 1_500_000) {
              pixels.set({
                key: `file:${file.name}:${file.size}`,
                title: file.name,
                text: `Large file (${fmtBytes(file.size)}). Name stored; content skipped.`,
                kind: "file",
                meta: { mime: file.type || "unknown", bytes: file.size },
              });
              resolve();
            } else {
              reader.readAsText(file);
            }
          }),
      ),
    ).then(() => {
      toast.success("Ingested into workspace");
      refresh();
    });
  }

  return (
    <div
      className="flex min-h-0 flex-1 flex-col"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onFiles(e.dataTransfer.files);
      }}
    >
      <div className="border-b border-border px-5 py-4">
        <h1 className="font-display text-2xl">Workspace</h1>
        <p className="mt-1 text-sm text-muted">Notes, files, Wikipedia extracts, and proofs. Drop files anywhere here.</p>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Filter pixels"
            className="h-10 w-full max-w-sm rounded-md border border-border bg-elevated px-3 text-sm outline-none focus:ring-2 focus:ring-accent/25"
          />
          <label className="inline-flex h-10 cursor-pointer items-center rounded-md bg-elevated px-3 text-sm text-fg shadow-[var(--elev-shadow)]">
            Add files
            <input type="file" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
          </label>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              const title = prompt("Note title");
              if (!title) return;
              const text = prompt("Note body") || "";
              pixels.set({ key: `note:${title}`, title, text, kind: "note" });
              refresh();
            }}
          >
            New note
          </Button>
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {items.length === 0 ? (
          <p className="px-2 py-10 text-center text-sm text-subtle">Empty. Drop a file or write a note.</p>
        ) : (
          <ul className="mx-auto max-w-3xl divide-y divide-border rounded-lg bg-surface shadow-[var(--elev-shadow)]">
            {items.map((p) => (
              <li key={p.key} className="flex items-start gap-3 px-4 py-3">
                <FileText className="mt-0.5 size-4 shrink-0 text-muted" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{p.title}</span>
                    <span className="text-[10px] tracking-wider text-subtle uppercase">{p.kind}</span>
                    <span className="font-mono text-[10px] text-subtle">{fmtBytes(p.size)}</span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[13px] text-muted">{p.text}</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Download"
                  onClick={() => {
                    const blob = new Blob([p.text], { type: "text/plain" });
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(blob);
                    a.download = p.title || "pixel.txt";
                    a.click();
                  }}
                >
                  <Download />
                </Button>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Delete"
                  onClick={() => {
                    pixels.delete(p.key);
                    refresh();
                  }}
                >
                  <Trash2 />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
