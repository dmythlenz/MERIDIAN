import { Hash } from "./hash";

const PRIMES: bigint[] = (() => {
  const p: number[] = [];
  const isP = (n: number) => {
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
    return n > 1;
  };
  let n = 2;
  while (p.length < 256) {
    if (isP(n)) p.push(n);
    n++;
  }
  return p.map((x) => BigInt(x));
})();

/** Deterministic 128-bit address for any payload. Fast hash for long strings; prime product for short. */
export function projectToInfiniteD(data: unknown): bigint {
  const str = typeof data === "string" ? data : JSON.stringify(data);
  if (str.length > 96) {
    let h1 = 0x811c9dc5 | 0;
    let h2 = 0x9e3779b9 | 0;
    let h3 = 0x85ebca6b | 0;
    let h4 = 0xc2b2ae35 | 0;
    for (let i = 0; i < str.length; i++) {
      const c = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761);
      h1 = (h1 ^ (h1 >>> 13)) | 0;
      h2 = Math.imul(h2 ^ (c + 0x9e), 1597334677);
      h2 = (h2 ^ (h2 >>> 16)) | 0;
      h3 = Math.imul(h3 ^ ((c * 31) | 0), 2246822519);
      h3 = (h3 ^ (h3 >>> 13)) | 0;
      h4 = Math.imul(h4 ^ (c << 3), 3266489917);
      h4 = (h4 ^ (h4 >>> 16)) | 0;
    }
    return (
      (BigInt(h1 >>> 0) << 96n) |
      (BigInt(h2 >>> 0) << 64n) |
      (BigInt(h3 >>> 0) << 32n) |
      BigInt(h4 >>> 0)
    );
  }
  let addr = 1n;
  for (let i = 0; i < str.length; i++) {
    const p = PRIMES[i % PRIMES.length]!;
    addr *= p ** BigInt((str.charCodeAt(i) % 16) + 1);
  }
  return addr;
}

export function addrKey(data: unknown): string {
  return projectToInfiniteD(data).toString(16);
}

export function fabricCoords(content: string) {
  const a = Hash.fnv(content);
  const b = Hash.djb2(content);
  return {
    screen: a % 64,
    y: (a >>> 8) % 256,
    x: b % 256,
    dim: (b >>> 10) % 1000,
  };
}
