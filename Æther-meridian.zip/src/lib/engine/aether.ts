/**
 * Aether — a real in-browser language: tokenizer, recursive-descent parser, evaluator.
 * Supports lets, functions, loops, arrays, and a small standard library.
 */

export type AetherResult = {
  ok: boolean;
  output: string[];
  value: unknown;
  error?: string;
  ms: number;
};

type Tok =
  | { type: "num"; value: number }
  | { type: "str"; value: string }
  | { type: "id"; value: string }
  | { type: "op"; value: string }
  | { type: "eof" };

const OPS = new Set([
  "(",
  ")",
  "{",
  "}",
  "[",
  "]",
  ",",
  ";",
  "=",
  "!",
  "+",
  "-",
  "*",
  "/",
  "%",
  "^",
  "<",
  ">",
  "&",
  "|",
  ":",
]);

function tokenize(src: string): Tok[] {
  const tokens: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i]!;
    if (c === "#" || (c === "/" && src[i + 1] === "/")) {
      while (i < src.length && src[i] !== "\n") i++;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      i++;
      continue;
    }
    if (c === '"' || c === "'") {
      const q = c;
      i++;
      let s = "";
      while (i < src.length && src[i] !== q) {
        if (src[i] === "\\" && i + 1 < src.length) {
          const n = src[i + 1];
          s += n === "n" ? "\n" : n === "t" ? "\t" : n === "\\" ? "\\" : n === q ? q : n;
          i += 2;
        } else {
          s += src[i];
          i++;
        }
      }
      i++;
      tokens.push({ type: "str", value: s });
      continue;
    }
    if (/[0-9]/.test(c) || (c === "." && /[0-9]/.test(src[i + 1] ?? ""))) {
      let n = "";
      while (i < src.length && /[0-9.]/.test(src[i]!)) {
        n += src[i];
        i++;
      }
      tokens.push({ type: "num", value: Number(n) });
      continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let id = "";
      while (i < src.length && /[A-Za-z0-9_]/.test(src[i]!)) {
        id += src[i];
        i++;
      }
      tokens.push({ type: "id", value: id });
      continue;
    }
    if (OPS.has(c)) {
      let op = c;
      const two = c + (src[i + 1] ?? "");
      if (
        two === "==" ||
        two === "!=" ||
        two === "<=" ||
        two === ">=" ||
        two === "&&" ||
        two === "||" ||
        two === "=>"
      ) {
        op = two;
        i += 2;
      } else {
        i++;
      }
      tokens.push({ type: "op", value: op });
      continue;
    }
    i++;
  }
  tokens.push({ type: "eof" });
  return tokens;
}

type Node =
  | { type: "num"; value: number }
  | { type: "str"; value: string }
  | { type: "bool"; value: boolean }
  | { type: "var"; name: string }
  | { type: "array"; elements: Node[] }
  | { type: "binary"; op: string; left: Node; right: Node }
  | { type: "unary"; op: string; expr: Node }
  | { type: "call"; name: string; args: Node[] }
  | { type: "index"; target: Node; index: Node }
  | { type: "print"; expr: Node }
  | { type: "let"; name: string; mutable: boolean; expr: Node }
  | { type: "assign"; name: string; expr: Node }
  | { type: "if"; cond: Node; then: Node; else?: Node }
  | { type: "for"; varName: string; iterable: Node; body: Node }
  | { type: "while"; cond: Node; body: Node }
  | { type: "fn"; name: string; params: string[]; body: Node }
  | { type: "return"; expr: Node }
  | { type: "block"; stmts: Node[] }
  | { type: "expr"; expr: Node };

class Parser {
  pos = 0;
  constructor(private tokens: Tok[]) {}
  peek(): Tok {
    return this.tokens[this.pos] ?? { type: "eof" };
  }
  next(): Tok {
    return this.tokens[this.pos++] ?? { type: "eof" };
  }
  eat(v: string): boolean {
    const t = this.peek();
    if (t.type === "op" && t.value === v) {
      this.next();
      return true;
    }
    if (t.type === "id" && t.value === v) {
      this.next();
      return true;
    }
    return false;
  }
  expectOp(v: string) {
    const t = this.next();
    if (t.type !== "op" || t.value !== v) throw new Error(`Expected '${v}'`);
  }

  parseProgram(): Node[] {
    const stmts: Node[] = [];
    while (this.peek().type !== "eof") {
      const s = this.parseStmt();
      if (s) stmts.push(s);
      this.eat(";");
    }
    return stmts;
  }

  parseStmt(): Node | null {
    const t = this.peek();
    if (t.type === "eof") return null;
    if (t.type === "id") {
      if (t.value === "print") {
        this.next();
        return { type: "print", expr: this.parseExpr() };
      }
      if (t.value === "let" || t.value === "mut") {
        this.next();
        const nameTok = this.next();
        if (nameTok.type !== "id") throw new Error("Expected name after let");
        this.expectOp("=");
        return { type: "let", name: nameTok.value, mutable: t.value === "mut", expr: this.parseExpr() };
      }
      if (t.value === "if") {
        this.next();
        const cond = this.parseExpr();
        const then = this.parseBlock();
        let els: Node | undefined;
        if (this.peek().type === "id" && this.peek().type === "id" && (this.peek() as { value?: string }).value === "else") {
          this.next();
          els = this.parseBlock();
        }
        return { type: "if", cond, then, else: els };
      }
      if (t.value === "for") {
        this.next();
        const nameTok = this.next();
        if (nameTok.type !== "id") throw new Error("Expected loop variable");
        const inTok = this.next();
        if (inTok.type !== "id" || inTok.value !== "in") throw new Error("Expected 'in'");
        const iterable = this.parseExpr();
        const body = this.parseBlock();
        return { type: "for", varName: nameTok.value, iterable, body };
      }
      if (t.value === "while") {
        this.next();
        const cond = this.parseExpr();
        return { type: "while", cond, body: this.parseBlock() };
      }
      if (t.value === "fn") {
        this.next();
        const nameTok = this.next();
        if (nameTok.type !== "id") throw new Error("Expected function name");
        this.expectOp("(");
        const params: string[] = [];
        while (!(this.peek().type === "op" && this.peek().type === "op" ? false : false) && !(this.peek().type === "op" && (this.peek() as { value?: string }).value === ")")) {
          if (this.peek().type === "eof") break;
          if (this.peek().type === "op" && (this.peek() as { value?: string }).value === ")") break;
          const p = this.next();
          if (p.type === "id") params.push(p.value);
          this.eat(",");
        }
        this.expectOp(")");
        return { type: "fn", name: nameTok.value, params, body: this.parseBlock() };
      }
      if (t.value === "return") {
        this.next();
        return { type: "return", expr: this.parseExpr() };
      }
      if (this.tokens[this.pos + 1]?.type === "op" && (this.tokens[this.pos + 1] as { value?: string }).value === "=") {
        const name = t.value;
        this.next();
        this.next();
        return { type: "assign", name, expr: this.parseExpr() };
      }
    }
    if (t.type === "op" && t.value === "{") return this.parseBlock();
    return { type: "expr", expr: this.parseExpr() };
  }

  parseBlock(): Node {
    if (this.peek().type === "op" && (this.peek() as { value?: string }).value === "{") {
      this.next();
      const stmts: Node[] = [];
      while (!(this.peek().type === "op" && (this.peek() as { value?: string }).value === "}") && this.peek().type !== "eof") {
        const s = this.parseStmt();
        if (s) stmts.push(s);
        this.eat(";");
      }
      this.expectOp("}");
      return { type: "block", stmts };
    }
    const s = this.parseStmt();
    return { type: "block", stmts: s ? [s] : [] };
  }

  parseExpr(): Node {
    return this.parseOr();
  }
  parseOr(): Node {
    let left = this.parseAnd();
    while (this.peek().type === "op" && (this.peek() as { value?: string }).value === "||") {
      this.next();
      left = { type: "binary", op: "||", left, right: this.parseAnd() };
    }
    return left;
  }
  parseAnd(): Node {
    let left = this.parseEq();
    while (this.peek().type === "op" && (this.peek() as { value?: string }).value === "&&") {
      this.next();
      left = { type: "binary", op: "&&", left, right: this.parseEq() };
    }
    return left;
  }
  parseEq(): Node {
    let left = this.parseCmp();
    while (this.peek().type === "op" && ["==", "!="].includes((this.peek() as { value?: string }).value ?? "")) {
      const op = (this.next() as { value: string }).value;
      left = { type: "binary", op, left, right: this.parseCmp() };
    }
    return left;
  }
  parseCmp(): Node {
    let left = this.parseAdd();
    while (this.peek().type === "op" && ["<", ">", "<=", ">="].includes((this.peek() as { value?: string }).value ?? "")) {
      const op = (this.next() as { value: string }).value;
      left = { type: "binary", op, left, right: this.parseAdd() };
    }
    return left;
  }
  parseAdd(): Node {
    let left = this.parseMul();
    while (this.peek().type === "op" && ["+", "-"].includes((this.peek() as { value?: string }).value ?? "")) {
      const op = (this.next() as { value: string }).value;
      left = { type: "binary", op, left, right: this.parseMul() };
    }
    return left;
  }
  parseMul(): Node {
    let left = this.parsePow();
    while (this.peek().type === "op" && ["*", "/", "%"].includes((this.peek() as { value?: string }).value ?? "")) {
      const op = (this.next() as { value: string }).value;
      left = { type: "binary", op, left, right: this.parsePow() };
    }
    return left;
  }
  parsePow(): Node {
    let left = this.parseUnary();
    if (this.peek().type === "op" && (this.peek() as { value?: string }).value === "^") {
      this.next();
      left = { type: "binary", op: "^", left, right: this.parsePow() };
    }
    return left;
  }
  parseUnary(): Node {
    if (this.peek().type === "op" && ["-", "!"].includes((this.peek() as { value?: string }).value ?? "")) {
      const op = (this.next() as { value: string }).value;
      return { type: "unary", op, expr: this.parseUnary() };
    }
    return this.parsePost();
  }
  parsePost(): Node {
    let node = this.parsePrimary();
    while (this.peek().type === "op" && (this.peek() as { value?: string }).value === "[") {
      this.next();
      const idx = this.parseExpr();
      this.expectOp("]");
      node = { type: "index", target: node, index: idx };
    }
    return node;
  }
  parsePrimary(): Node {
    const t = this.next();
    if (t.type === "num") return { type: "num", value: t.value };
    if (t.type === "str") return { type: "str", value: t.value };
    if (t.type === "id") {
      if (t.value === "true") return { type: "bool", value: true };
      if (t.value === "false") return { type: "bool", value: false };
      if (this.peek().type === "op" && (this.peek() as { value?: string }).value === "(") {
        this.next();
        const args: Node[] = [];
        while (!(this.peek().type === "op" && (this.peek() as { value?: string }).value === ")") && this.peek().type !== "eof") {
          args.push(this.parseExpr());
          this.eat(",");
        }
        this.expectOp(")");
        return { type: "call", name: t.value, args };
      }
      return { type: "var", name: t.value };
    }
    if (t.type === "op" && t.value === "(") {
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    if (t.type === "op" && t.value === "[") {
      const elements: Node[] = [];
      while (!(this.peek().type === "op" && (this.peek() as { value?: string }).value === "]") && this.peek().type !== "eof") {
        elements.push(this.parseExpr());
        this.eat(",");
      }
      this.expectOp("]");
      return { type: "array", elements };
    }
    throw new Error(`Unexpected token`);
  }
}

type Env = Map<string, unknown>;

class ReturnSignal {
  constructor(public value: unknown) {}
}

function stringify(v: unknown): string {
  if (v === undefined) return "undefined";
  if (v === null) return "null";
  if (typeof v === "string") return v;
  if (typeof v === "function") return "<fn>";
  if (Array.isArray(v)) return "[" + v.map(stringify).join(", ") + "]";
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

function makeGlobal(capture: string[]): Env {
  const g: Env = new Map();
  const num = (fn: (...a: number[]) => number) => (...args: unknown[]) => fn(...args.map(Number));
  g.set("print", (...args: unknown[]) => {
    const s = args.map(stringify).join(" ");
    capture.push(s);
    return s;
  });
  g.set("str", (v: unknown) => stringify(v));
  g.set("len", (v: unknown) => (v && typeof v === "object" && "length" in (v as object) ? (v as { length: number }).length : String(v ?? "").length));
  g.set("range", (start: unknown, end?: unknown, step?: unknown) => {
    let a = Number(start),
      b = end === undefined ? a : Number(end),
      s = step === undefined ? 1 : Number(step);
    if (end === undefined) {
      b = a;
      a = 0;
    }
    if (s === 0) s = 1;
    const out: number[] = [];
    if (s > 0) for (let i = a; i < b; i += s) out.push(i);
    else for (let i = a; i > b; i += s) out.push(i);
    return out;
  });
  g.set("PI", Math.PI);
  g.set("E", Math.E);
  g.set("sin", num(Math.sin));
  g.set("cos", num(Math.cos));
  g.set("tan", num(Math.tan));
  g.set("sqrt", num(Math.sqrt));
  g.set("abs", num(Math.abs));
  g.set("pow", (a: unknown, b: unknown) => Math.pow(Number(a), Number(b)));
  g.set("floor", num(Math.floor));
  g.set("ceil", num(Math.ceil));
  g.set("round", num(Math.round));
  g.set("min", (...a: unknown[]) => Math.min(...a.map(Number)));
  g.set("max", (...a: unknown[]) => Math.max(...a.map(Number)));
  g.set("log", num(Math.log));
  g.set("exp", num(Math.exp));
  g.set("now", () => Date.now());
  g.set("push", (arr: unknown, val: unknown) => {
    if (!Array.isArray(arr)) throw new Error("push expects array");
    arr.push(val);
    return arr;
  });
  g.set("pop", (arr: unknown) => {
    if (!Array.isArray(arr)) throw new Error("pop expects array");
    return arr.pop();
  });
  g.set("join", (arr: unknown, sep?: unknown) => {
    if (!Array.isArray(arr)) return String(arr);
    return arr.map(stringify).join(String(sep ?? ","));
  });
  g.set("map", (arr: unknown, fn: unknown) => {
    if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("map(arr, fn)");
    return arr.map((x) => (fn as (v: unknown) => unknown)(x));
  });
  g.set("filter", (arr: unknown, fn: unknown) => {
    if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("filter(arr, fn)");
    return arr.filter((x) => (fn as (v: unknown) => unknown)(x));
  });
  g.set("reduce", (arr: unknown, fn: unknown, init?: unknown) => {
    if (!Array.isArray(arr) || typeof fn !== "function") throw new Error("reduce(arr, fn, init)");
    return arr.reduce((a, b) => (fn as (x: unknown, y: unknown) => unknown)(a, b), init);
  });
  g.set("sum", (arr: unknown) => {
    if (!Array.isArray(arr)) return Number(arr);
    return arr.reduce((a: number, b) => a + Number(b), 0);
  });
  g.set("sort", (arr: unknown) => {
    if (!Array.isArray(arr)) return arr;
    return [...arr].sort((a, b) => Number(a) - Number(b));
  });
  g.set("rev", (arr: unknown) => (Array.isArray(arr) ? [...arr].reverse() : String(arr).split("").reverse().join("")));
  g.set("factor", (n: unknown) => factorInt(Math.trunc(Number(n))));
  g.set("isPrime", (n: unknown) => isPrime(Math.trunc(Number(n))));
  g.set("gcd", (a: unknown, b: unknown) => gcd(Math.trunc(Number(a)), Math.trunc(Number(b))));
  g.set("fib", (n: unknown) => fib(Math.trunc(Number(n))));
  return g;
}

function isPrime(n: number): boolean {
  if (n < 2) return false;
  if (n % 2 === 0) return n === 2;
  for (let i = 3; i * i <= n; i += 2) if (n % i === 0) return false;
  return true;
}
function gcd(a: number, b: number): number {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}
function factorInt(n: number): number[] {
  n = Math.abs(n);
  const out: number[] = [];
  if (n < 2) return [n];
  while (n % 2 === 0) {
    out.push(2);
    n /= 2;
  }
  for (let i = 3; i * i <= n; i += 2) {
    while (n % i === 0) {
      out.push(i);
      n /= i;
    }
  }
  if (n > 1) out.push(n);
  return out;
}
function fib(n: number): number {
  if (n <= 0) return 0;
  if (n === 1) return 1;
  let a = 0,
    b = 1;
  for (let i = 2; i <= n; i++) {
    const t = a + b;
    a = b;
    b = t;
  }
  return b;
}

function evalNode(node: Node, env: Env, global: Env): unknown {
  switch (node.type) {
    case "num":
      return node.value;
    case "str":
      return node.value;
    case "bool":
      return node.value;
    case "array":
      return node.elements.map((e) => evalNode(e, env, global));
    case "var": {
      if (env.has(node.name)) return env.get(node.name);
      if (global.has(node.name)) return global.get(node.name);
      throw new Error(`Undefined: ${node.name}`);
    }
    case "unary": {
      const v = evalNode(node.expr, env, global);
      if (node.op === "-") return -Number(v);
      if (node.op === "!") return !v;
      return v;
    }
    case "binary": {
      const l = evalNode(node.left, env, global);
      const r = evalNode(node.right, env, global);
      switch (node.op) {
        case "+":
          return typeof l === "string" || typeof r === "string" ? String(l) + String(r) : Number(l) + Number(r);
        case "-":
          return Number(l) - Number(r);
        case "*":
          return Number(l) * Number(r);
        case "/":
          return Number(l) / Number(r);
        case "%":
          return Number(l) % Number(r);
        case "^":
          return Math.pow(Number(l), Number(r));
        case "==":
          return l === r;
        case "!=":
          return l !== r;
        case "<":
          return Number(l) < Number(r);
        case ">":
          return Number(l) > Number(r);
        case "<=":
          return Number(l) <= Number(r);
        case ">=":
          return Number(l) >= Number(r);
        case "&&":
          return Boolean(l) && Boolean(r);
        case "||":
          return Boolean(l) || Boolean(r);
        default:
          return 0;
      }
    }
    case "call": {
      const fn = env.get(node.name) ?? global.get(node.name);
      if (typeof fn !== "function") throw new Error(`Not a function: ${node.name}`);
      const args = node.args.map((a) => evalNode(a, env, global));
      return (fn as (...a: unknown[]) => unknown)(...args);
    }
    case "index": {
      const t = evalNode(node.target, env, global);
      const i = evalNode(node.index, env, global);
      if (Array.isArray(t) || typeof t === "string") return (t as string | unknown[])[Number(i)];
      return undefined;
    }
    case "print": {
      const v = evalNode(node.expr, env, global);
      const print = global.get("print") as (...a: unknown[]) => unknown;
      print(v);
      return v;
    }
    case "let": {
      const v = evalNode(node.expr, env, global);
      env.set(node.name, v);
      return v;
    }
    case "assign": {
      if (!env.has(node.name) && !global.has(node.name)) throw new Error(`Undefined: ${node.name}`);
      const v = evalNode(node.expr, env, global);
      if (env.has(node.name)) env.set(node.name, v);
      else global.set(node.name, v);
      return v;
    }
    case "if": {
      if (evalNode(node.cond, env, global)) return evalNode(node.then, env, global);
      if (node.else) return evalNode(node.else, env, global);
      return undefined;
    }
    case "for": {
      const iter = evalNode(node.iterable, env, global);
      const list = Array.isArray(iter) ? iter : typeof iter === "string" ? [...iter] : [];
      let last: unknown;
      for (const item of list) {
        const child = new Map(env);
        child.set(node.varName, item);
        last = evalNode(node.body, child, global);
      }
      return last;
    }
    case "while": {
      let last: unknown;
      let guard = 0;
      while (evalNode(node.cond, env, global)) {
        last = evalNode(node.body, env, global);
        if (++guard > 100000) throw new Error("Loop exceeded 100000 iterations");
      }
      return last;
    }
    case "fn": {
      const fn = (...args: unknown[]) => {
        const child = new Map(env);
        node.params.forEach((p, i) => child.set(p, args[i]));
        try {
          return evalNode(node.body, child, global);
        } catch (e) {
          if (e instanceof ReturnSignal) return e.value;
          throw e;
        }
      };
      env.set(node.name, fn);
      global.set(node.name, fn);
      return fn;
    }
    case "return":
      throw new ReturnSignal(evalNode(node.expr, env, global));
    case "block": {
      let last: unknown;
      const child = new Map(env);
      for (const s of node.stmts) last = evalNode(s, child, global);
      return last;
    }
    case "expr":
      return evalNode(node.expr, env, global);
    default:
      return undefined;
  }
}

export function runAether(src: string): AetherResult {
  const t0 = performance.now();
  const output: string[] = [];
  try {
    const tokens = tokenize(src);
    const parser = new Parser(tokens);
    const program = parser.parseProgram();
    const global = makeGlobal(output);
    const env: Env = new Map(global);
    let value: unknown;
    for (const stmt of program) value = evalNode(stmt, env, global);
    return { ok: true, output, value, ms: performance.now() - t0 };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { ok: false, output, value: undefined, error: msg, ms: performance.now() - t0 };
  }
}

export const AETHER_HELP = `Aether language

let x = 10
mut y = 0
print(x * 2)
fn square(n) { return n * n }
print(square(12))
for i in range(5) { print(i) }
let a = [3, 1, 4]
print(sum(a), sort(a), factor(123456789))
if 2 < 3 { print("yes") } else { print("no") }

Builtins: print str len range PI E sin cos tan sqrt abs pow floor ceil round
min max log exp now push pop join map filter reduce sum sort rev factor isPrime gcd fib`;
