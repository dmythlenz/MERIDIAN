import { searchKnowledge, type KnowledgeEntry } from "./knowledge";

export type Expert = {
  id: string;
  name: string;
  domain: string;
  keywords: string[];
  blurb: string;
};

export const EXPERTS: Expert[] = [
  {
    id: "phys",
    name: "Helia",
    domain: "physics",
    keywords: ["physics", "quantum", "relativity", "light", "energy", "force", "entropy", "wave", "particle", "gravity"],
    blurb: "First-principles physics: constants, fields, and spacetime.",
  },
  {
    id: "math",
    name: "Axioma",
    domain: "math",
    keywords: ["math", "prime", "proof", "algebra", "calculus", "pi", "number", "matrix", "probability", "logarithm", "factor"],
    blurb: "Pure mathematics, from integers to incompleteness.",
  },
  {
    id: "bio",
    name: "Soma",
    domain: "biology",
    keywords: ["biology", "dna", "cell", "evolution", "neuron", "gene", "photosynthesis", "organism"],
    blurb: "Living systems, from molecules to selection.",
  },
  {
    id: "chem",
    name: "Valence",
    domain: "chemistry",
    keywords: ["chemistry", "atom", "bond", "element", "molecule", "periodic", "carbon", "water", "reaction"],
    blurb: "Structure, bonding, and the table of elements.",
  },
  {
    id: "cs",
    name: "Ada",
    domain: "cs",
    keywords: ["code", "algorithm", "computer", "program", "compiler", "hash", "ai", "http", "database", "os", "crypto", "turing", "complexity"],
    blurb: "Computation, systems, and cryptographic hardness.",
  },
  {
    id: "astro",
    name: "Lyra",
    domain: "astronomy",
    keywords: ["star", "planet", "galaxy", "black hole", "cosmos", "orbit", "moon", "sun", "kepler", "big bang"],
    blurb: "The sky: orbits, collapse, and origin.",
  },
  {
    id: "hist",
    name: "Annal",
    domain: "history",
    keywords: ["history", "war", "empire", "revolution", "democracy", "economy", "civilization"],
    blurb: "What people did, and what followed.",
  },
  {
    id: "med",
    name: "Clinic",
    domain: "medicine",
    keywords: ["medicine", "health", "disease", "vaccine", "heart", "cancer", "anatomy"],
    blurb: "Human physiology — general knowledge, not advice.",
  },
  {
    id: "eng",
    name: "Forge",
    domain: "engineering",
    keywords: ["engine", "chip", "cpu", "flight", "gps", "transistor", "circuit", "machine"],
    blurb: "How artifacts actually work.",
  },
  {
    id: "geo",
    name: "Meridian",
    domain: "earth",
    keywords: ["earth", "climate", "map", "time", "longitude", "meridian", "ocean", "continent"],
    blurb: "The planet as a measured object.",
  },
];

export function routeExpert(query: string): { expert: Expert; score: number; hits: KnowledgeEntry[] } | null {
  const q = query.toLowerCase();
  let best: { expert: Expert; score: number } | null = null;
  for (const ex of EXPERTS) {
    let s = 0;
    for (const kw of ex.keywords) if (q.includes(kw)) s += 2;
    if (q.includes(ex.domain)) s += 3;
    if (q.includes(ex.name.toLowerCase())) s += 4;
    if (!best || s > best.score) best = { expert: ex, score: s };
  }
  if (!best || best.score < 2) return null;
  const hits = searchKnowledge(query, 4)
    .filter((h) => h.entry.category === best!.expert.domain || h.score > 5)
    .map((h) => h.entry);
  return { expert: best.expert, score: best.score, hits };
}
