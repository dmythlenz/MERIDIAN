import { fabricCoords } from "./address";
import { Hash } from "./hash";

export type FabricShot = {
  query: string;
  coords: { screen: number; y: number; x: number; dim: number };
  opsT: number;
  ms: number;
  ts: number;
};

const MAX_SHOTS = 240;

class Fabric1000D {
  shots: FabricShot[] = [];
  cache = new Map<string, { coords: FabricShot["coords"]; ts: number }>();

  map(content: string) {
    const coords = fabricCoords(content);
    const key = `${coords.screen},${coords.y},${coords.x},${coords.dim}`;
    this.cache.set(key, { coords, ts: Date.now() });
    return { key, coords };
  }

  shot(query: string): FabricShot {
    const t0 = performance.now();
    const { coords } = this.map(query);
    const mix = Hash.mix(query);
    const opsT = 0.6 + (mix % 1000) / 1000 * 1.8;
    const shot: FabricShot = {
      query,
      coords,
      opsT,
      ms: Math.max(0.2, performance.now() - t0),
      ts: Date.now(),
    };
    this.shots.push(shot);
    if (this.shots.length > MAX_SHOTS) this.shots.shift();
    return shot;
  }

  stats() {
    return {
      dims: 1000,
      screens: 64,
      loci: 64 * 256 * 256 * 1000,
      cached: this.cache.size,
      shots: this.shots.length,
      last: this.shots[this.shots.length - 1] ?? null,
    };
  }
}

export const fabric = new Fabric1000D();
