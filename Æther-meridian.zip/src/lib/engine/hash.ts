export const Hash = {
  fnv(s: string): number {
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return h >>> 0;
  },
  djb2(s: string): number {
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
    return h;
  },
  h64(s: string): string {
    const t = String(s);
    return this.fnv(t).toString(16).padStart(8, "0") + this.djb2(t).toString(16).padStart(8, "0");
  },
  mix(s: string): number {
    let h1 = 0x811c9dc5 | 0;
    let h2 = 0x9e3779b9 | 0;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761);
      h1 = (h1 ^ (h1 >>> 13)) | 0;
      h2 = Math.imul(h2 ^ (c + 0x9e), 1597334677);
      h2 = (h2 ^ (h2 >>> 16)) | 0;
    }
    return (h1 ^ h2) >>> 0;
  },
};
