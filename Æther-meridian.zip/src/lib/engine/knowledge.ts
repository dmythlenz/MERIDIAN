export type KnowledgeEntry = {
  id: string;
  title: string;
  category: string;
  keywords: string[];
  body: string;
  source: string;
};

export const KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "c",
    title: "Speed of light",
    category: "physics",
    keywords: ["light", "c", "vacuum", "relativity", "einstein", "299792458"],
    body: "The speed of light in vacuum is defined as exactly 299,792,458 metres per second. It is a universal constant (c) and the conversion factor between mass and energy in E = mc². Nothing with rest mass can reach c in vacuum; light itself has no rest mass. In 1983 the metre was redefined so that c is exact rather than measured.",
    source: "SI Brochure / CODATA",
  },
  {
    id: "g-const",
    title: "Newtonian gravitational constant",
    category: "physics",
    keywords: ["gravity", "newton", "constant", "G", "cavendish"],
    body: "Newton's law of universal gravitation: F = G·m₁·m₂ / r². The constant G is approximately 6.67430 × 10⁻¹¹ m³ kg⁻¹ s⁻² (CODATA 2018). Gravity in general relativity is spacetime curvature sourced by the stress-energy tensor, not a force at a distance.",
    source: "CODATA 2018",
  },
  {
    id: "planck",
    title: "Planck constant",
    category: "physics",
    keywords: ["planck", "quantum", "h", "hbar", "photon"],
    body: "The Planck constant h is exactly 6.62607015 × 10⁻³⁴ J·s (SI 2019). The reduced constant ℏ = h / 2π. Photon energy E = hν. The 2019 SI redefinition fixed h, e, k, and N_A as exact, making the kilogram a derived unit.",
    source: "SI 2019",
  },
  {
    id: "entangle",
    title: "Quantum entanglement",
    category: "physics",
    keywords: ["entanglement", "quantum", "bell", "epr", "qubit", "spooky"],
    body: "Entanglement is a non-classical correlation: the joint state of two or more systems cannot be written as a product of individual states. Measuring one subsystem instantly updates the description of the other, but this cannot transmit information faster than light (no-signalling). Bell tests (Aspect, Zeilinger, Clauser — Nobel 2022) rule out local hidden-variable theories.",
    source: "Nobel Prize 2022 / QM textbooks",
  },
  {
    id: "relativity",
    title: "Special and general relativity",
    category: "physics",
    keywords: ["relativity", "einstein", "spacetime", "lorentz", "time dilation"],
    body: "Special relativity (1905): the laws of physics are the same in all inertial frames; c is invariant. Consequences include time dilation, length contraction, and E² = (pc)² + (mc²)². General relativity (1915): gravity is the curvature of spacetime; Einstein field equations G_μν + Λg_μν = (8πG/c⁴) T_μν. Confirmed by perihelion of Mercury, gravitational lensing, GPS corrections, and gravitational waves (LIGO 2015).",
    source: "Einstein 1905/1915",
  },
  {
    id: "thermo2",
    title: "Second law of thermodynamics",
    category: "physics",
    keywords: ["entropy", "thermodynamics", "second law", "kelvin", "clausius"],
    body: "The entropy of an isolated system never decreases. Heat does not spontaneously flow from cold to hot. Equivalent statements: Kelvin–Planck (no perfect heat engine) and Clausius. Statistical mechanics identifies entropy with S = k ln Ω. The second law gives time its thermodynamic arrow.",
    source: "Clausius / Boltzmann",
  },
  {
    id: "em-spectrum",
    title: "Electromagnetic spectrum",
    category: "physics",
    keywords: ["electromagnetic", "spectrum", "radio", "xray", "gamma", "infrared"],
    body: "Electromagnetic waves are oscillations of electric and magnetic fields traveling at c in vacuum. In order of increasing frequency: radio, microwave, infrared, visible (≈400–700 nm), ultraviolet, X-ray, gamma. Energy of a photon is E = hν = hc/λ.",
    source: "Maxwell / quantum optics",
  },
  {
    id: "pi",
    title: "Pi (π)",
    category: "math",
    keywords: ["pi", "circle", "transcendental", "3.14159", "archimedes"],
    body: "π is the ratio of a circle's circumference to its diameter, approximately 3.141592653589793. It is irrational (Lambert 1761) and transcendental (Lindemann 1882). Appears in Fourier analysis, Gaussian integrals, Euler's identity e^{iπ} + 1 = 0, and the volume of an n-ball.",
    source: "Classical analysis",
  },
  {
    id: "e-const",
    title: "Euler's number e",
    category: "math",
    keywords: ["euler", "e", "exponential", "2.718", "natural log"],
    body: "e ≈ 2.718281828459045 is the base of the natural logarithm. Defined as lim (1+1/n)^n, or Σ 1/n!. The unique base where d/dx a^x = a^x. Euler's identity: e^{iθ} = cos θ + i sin θ.",
    source: "Euler",
  },
  {
    id: "fibonacci",
    title: "Fibonacci sequence",
    category: "math",
    keywords: ["fibonacci", "sequence", "golden", "phi", "recurrence"],
    body: "F₀ = 0, F₁ = 1, Fₙ = Fₙ₋₁ + Fₙ₋₂. The sequence begins 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89… The ratio Fₙ₊₁/Fₙ → φ = (1+√5)/2 ≈ 1.6180339887 (the golden ratio). Binet's formula: Fₙ = (φⁿ − (−φ)⁻ⁿ) / √5.",
    source: "Number theory",
  },
  {
    id: "primes",
    title: "Prime numbers",
    category: "math",
    keywords: ["prime", "number", "sieve", "eratosthenes", "goldbach"],
    body: "A prime is an integer greater than 1 with no positive divisors other than 1 and itself. There are infinitely many (Euclid). The prime-number theorem: π(n) ∼ n / ln n. Fundamental theorem of arithmetic: every integer > 1 has a unique prime factorization. Goldbach's conjecture (every even integer > 2 is the sum of two primes) is verified to enormous bounds but unproven.",
    source: "Number theory",
  },
  {
    id: "pythagoras",
    title: "Pythagorean theorem",
    category: "math",
    keywords: ["pythagoras", "triangle", "hypotenuse", "a2+b2"],
    body: "In a right triangle, a² + b² = c² where c is the hypotenuse. Equivalent to the Euclidean inner-product identity. Generalizes to the law of cosines c² = a² + b² − 2ab cos γ, and to Parseval's theorem in Hilbert space.",
    source: "Euclid I.47",
  },
  {
    id: "calculus",
    title: "Fundamental theorem of calculus",
    category: "math",
    keywords: ["calculus", "integral", "derivative", "newton", "leibniz"],
    body: "If F'(x) = f(x), then ∫_a^b f(x) dx = F(b) − F(a). Differentiation and integration are inverse operations. Newton and Leibniz developed the infinitesimal calculus independently in the 17th century; the modern ε-δ foundation is due to Cauchy and Weierstrass.",
    source: "Analysis",
  },
  {
    id: "euler-id",
    title: "Euler's identity",
    category: "math",
    keywords: ["euler", "identity", "e", "pi", "complex"],
    body: "e^{iπ} + 1 = 0. It unites the five most important constants in mathematics (e, i, π, 1, 0) in a single equation, a special case of Euler's formula e^{iθ} = cos θ + i sin θ.",
    source: "Complex analysis",
  },
  {
    id: "dna",
    title: "DNA structure",
    category: "biology",
    keywords: ["dna", "double helix", "watson", "crick", "gene", "base"],
    body: "Deoxyribonucleic acid stores genetic information as a double helix of complementary base pairs: adenine–thymine (two hydrogen bonds) and guanine–cytosine (three). The sugar-phosphate backbone is antiparallel (5' to 3'). Watson and Crick (1953), building on Franklin and Wilkins, proposed the structure. The human genome has ~3.2 billion base pairs across 23 chromosome pairs.",
    source: "Watson & Crick 1953",
  },
  {
    id: "cancer",
    title: "Cancer",
    category: "medicine",
    keywords: ["cancer", "tumor", "oncology", "metastasis", "cell"],
    body: "Cancer is a group of diseases of uncontrolled cell growth with potential to invade or metastasize. Hallmarks (Hanahan & Weinberg) include sustaining proliferation, evading growth suppressors, resisting cell death, enabling replicative immortality, inducing angiogenesis, and activating invasion. Causes include mutations, carcinogens, viruses (HPV, HBV), and inherited syndromes. Early detection and a combination of surgery, radiotherapy, chemotherapy, immunotherapy, and targeted drugs improve outcomes. This is general information, not medical advice.",
    source: "Hanahan & Weinberg / WHO",
  },
  {
    id: "photosynthesis",
    title: "Photosynthesis",
    category: "biology",
    keywords: ["photosynthesis", "chlorophyll", "plant", "calvin", "glucose"],
    body: "6 CO₂ + 6 H₂O + photons → C₆H₁₂O₆ + 6 O₂. Light reactions in thylakoid membranes split water and produce ATP and NADPH; the Calvin cycle in the stroma fixes carbon. Chlorophyll a absorbs primarily blue and red light, which is why plants appear green.",
    source: "Plant physiology",
  },
  {
    id: "evolution",
    title: "Natural selection",
    category: "biology",
    keywords: ["evolution", "darwin", "selection", "fitness", "species"],
    body: "Darwin and Wallace: heritable variation + differential reproductive success → adaptation over generations. Modern synthesis unites this with Mendelian genetics and population genetics. Evidence includes fossils, biogeography, homology, observed speciation, and genomic phylogenies.",
    source: "Darwin 1859 / modern synthesis",
  },
  {
    id: "atom",
    title: "Atomic structure",
    category: "chemistry",
    keywords: ["atom", "electron", "proton", "neutron", "orbital", "bohr"],
    body: "An atom has a nucleus of protons and neutrons, surrounded by electrons in orbitals described by quantum mechanics (not classical Bohr orbits). Atomic number Z = proton count, which defines the element. Isotopes differ in neutron count. The periodic table arranges elements by Z and recurring chemical properties.",
    source: "Quantum chemistry",
  },
  {
    id: "periodic",
    title: "Periodic table",
    category: "chemistry",
    keywords: ["periodic", "mendeleev", "element", "group", "period"],
    body: "Mendeleev (1869) arranged elements by atomic weight and chemical periodicity; the modern table uses atomic number. Groups share valence-electron configuration (alkali metals, halogens, noble gases). Periods correspond to filling of electron shells. There are 118 confirmed elements.",
    source: "IUPAC",
  },
  {
    id: "water",
    title: "Water (H₂O)",
    category: "chemistry",
    keywords: ["water", "h2o", "hydrogen bond", "solvent", "ice"],
    body: "Water is a polar molecule with a bent geometry (≈104.5°) due to two lone pairs on oxygen. Hydrogen bonding gives it a high boiling point, high heat capacity, and the unusual property that ice is less dense than liquid water. It is the universal solvent of terrestrial biochemistry.",
    source: "Physical chemistry",
  },
  {
    id: "cs-complexity",
    title: "P versus NP",
    category: "cs",
    keywords: ["p vs np", "complexity", "turing", "algorithm", "np-complete"],
    body: "P is the class of decision problems solvable in polynomial time by a deterministic Turing machine. NP is the class verifiable in polynomial time. P ⊆ NP; whether P = NP is the central open problem of theoretical computer science (Clay Millennium Problem). NP-complete problems (SAT, TSP decision, clique) are the hardest in NP: a polynomial algorithm for one yields one for all.",
    source: "Cook–Levin / Clay Institute",
  },
  {
    id: "turing",
    title: "Turing machine",
    category: "cs",
    keywords: ["turing", "computability", "halting", "church", "algorithm"],
    body: "A Turing machine is an abstract computer: an infinite tape, a head, and a finite state table. Church–Turing thesis: anything effectively computable is computable by a Turing machine. The halting problem is undecidable — no algorithm can determine, for every program and input, whether the program halts.",
    source: "Turing 1936",
  },
  {
    id: "http",
    title: "HTTP and the web",
    category: "cs",
    keywords: ["http", "web", "html", "browser", "tcp", "internet"],
    body: "HTTP is the application protocol of the web, typically over TCP port 80 (HTTPS over TLS on 443). A request has a method (GET, POST, PUT, DELETE…), path, headers, and optional body. Status codes: 2xx success, 3xx redirect, 4xx client error, 5xx server error. HTML, CSS, and JavaScript are the browser's native triad.",
    source: "IETF RFCs",
  },
  {
    id: "transformer",
    title: "Transformer architecture",
    category: "cs",
    keywords: ["transformer", "attention", "llm", "gpt", "neural", "bert"],
    body: "The Transformer (Vaswani et al., 2017) replaces recurrence with self-attention: each token attends to every other token in the sequence. Multi-head attention + position-wise feed-forward layers + residual connections + layer norm. This is the backbone of modern large language models. Complexity is O(n²) in sequence length, motivating sparse and linear-attention variants.",
    source: "Vaswani et al. 2017",
  },
  {
    id: "sha256",
    title: "SHA-256",
    category: "cs",
    keywords: ["sha256", "hash", "cryptography", "bitcoin", "digest"],
    body: "SHA-256 is a 256-bit cryptographic hash in the SHA-2 family (NSA, 2001). It is collision-resistant in practice, used in Bitcoin's proof-of-work, TLS, and digital signatures. Output is 32 bytes (64 hex chars). It is not encryption — hashes are one-way.",
    source: "FIPS 180-4",
  },
  {
    id: "sort",
    title: "Sorting algorithms",
    category: "cs",
    keywords: ["sort", "quicksort", "mergesort", "heapsort", "big-o"],
    body: "Comparison sorts require Ω(n log n) comparisons in the worst case. Mergesort and heapsort achieve O(n log n) worst-case; quicksort is O(n log n) average, O(n²) worst. Timsort (Python, Java) is a hybrid mergesort optimized for real-world partially-sorted data. Radix and counting sorts can beat n log n when keys have extra structure.",
    source: "CLRS",
  },
  {
    id: "solar",
    title: "Solar System",
    category: "astronomy",
    keywords: ["solar", "planet", "sun", "jupiter", "earth", "orbit"],
    body: "The Sun is a G2V star holding eight planets: Mercury, Venus, Earth, Mars (terrestrial) and Jupiter, Saturn, Uranus, Neptune (giant). Dwarf planets include Pluto, Ceres, Eris. Earth orbits at 1 AU ≈ 149.6 million km with a sidereal year of 365.256 days. The Sun is ≈4.6 billion years old and about halfway through its main-sequence life.",
    source: "IAU / NASA",
  },
  {
    id: "blackhole",
    title: "Black holes",
    category: "astronomy",
    keywords: ["black hole", "event horizon", "schwarzschild", "hawking", "singularity"],
    body: "A black hole is a region where gravity is so strong that not even light can escape. The Schwarzschild radius is r_s = 2GM/c². Event Horizon Telescope imaged M87* (2019) and Sgr A* (2022). Hawking radiation implies black holes evaporate thermally, leading to the information paradox — an open question in quantum gravity.",
    source: "GR / EHT",
  },
  {
    id: "bigbang",
    title: "Big Bang cosmology",
    category: "astronomy",
    keywords: ["big bang", "cmb", "universe", "hubble", "expansion"],
    body: "The universe expanded from a hot, dense state ≈13.8 billion years ago. Evidence: Hubble–Lemaître expansion, the cosmic microwave background (Penzias & Wilson 1965; Planck satellite), and primordial light-element abundances. ΛCDM is the standard model: cold dark matter plus a cosmological constant driving late-time acceleration.",
    source: "Planck / ΛCDM",
  },
  {
    id: "earth",
    title: "Earth",
    category: "earth",
    keywords: ["earth", "planet", "atmosphere", "core", "plate"],
    body: "Earth is the third planet from the Sun, radius ≈6371 km, mass ≈5.97 × 10²⁴ kg. Structure: inner solid iron core, outer liquid core (geodynamo), silicate mantle, crust. Plate tectonics recycles crust. Atmosphere is 78% N₂, 21% O₂. Surface is ≈71% ocean. Axial tilt 23.44° produces seasons.",
    source: "USGS / NASA",
  },
  {
    id: "climate",
    title: "Climate and greenhouse effect",
    category: "earth",
    keywords: ["climate", "carbon", "greenhouse", "warming", "co2"],
    body: "Greenhouse gases (CO₂, CH₄, H₂O, N₂O) absorb outgoing longwave radiation, warming the surface. Pre-industrial CO₂ ≈280 ppm; it now exceeds 420 ppm, primarily from fossil fuels and land-use change. IPCC assessments attribute recent warming to human activity with high confidence. This is scientific consensus, not a political statement.",
    source: "IPCC AR6",
  },
  {
    id: "ww2",
    title: "Second World War",
    category: "history",
    keywords: ["ww2", "world war", "1945", "hitler", "allies", "axis"],
    body: "World War II (1939–1945) was the deadliest conflict in history. It began with Germany's invasion of Poland and ended with Germany's surrender (May 1945) and Japan's (September 1945) after the atomic bombings of Hiroshima and Nagasaki. The United Nations, bipolar Cold War, and decolonization followed.",
    source: "Historical consensus",
  },
  {
    id: "rome",
    title: "Roman Empire",
    category: "history",
    keywords: ["rome", "caesar", "augustus", "empire", "republic"],
    body: "Rome grew from a city-state to a Mediterranean empire. The Republic ended as Octavian became Augustus (27 BCE). The Western Empire traditionally falls in 476 CE; the Eastern (Byzantine) Empire continued until 1453. Latin, law, engineering, and urbanism shaped Europe.",
    source: "Classical history",
  },
  {
    id: "printing",
    title: "Printing press",
    category: "history",
    keywords: ["gutenberg", "printing", "press", "book", "reformation"],
    body: "Johannes Gutenberg's movable-type press (Mainz, c. 1440) made books cheap and standardized. It accelerated the Reformation, scientific correspondence, and vernacular literacy — a communications revolution comparable to the internet.",
    source: "History of technology",
  },
  {
    id: "internet",
    title: "Internet",
    category: "cs",
    keywords: ["internet", "tcp", "ip", "packet", "arpanet", "dns"],
    body: "The internet is a global packet-switched network using the TCP/IP suite. ARPANET (1969) pioneered it; TCP/IP was standardized on 1 January 1983. Addressing is hierarchical (IP); names resolve via DNS. The web (Berners-Lee, 1989–91) is one application among many (email, SSH, streaming).",
    source: "RFC 791 / CERN",
  },
  {
    id: "john316",
    title: "John 3:16",
    category: "language",
    keywords: ["bible", "john", "verse", "scripture", "gospel"],
    body: "John 3:16 (KJV): “For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.” It is among the most-cited verses in the Christian New Testament, summarizing the Gospel's claim of divine love and salvation.",
    source: "Gospel of John",
  },
  {
    id: "shakespeare",
    title: "William Shakespeare",
    category: "language",
    keywords: ["shakespeare", "hamlet", "play", "sonnet", "globe"],
    body: "William Shakespeare (1564–1616), Stratford-upon-Avon, wrote about 39 plays and 154 sonnets. Hamlet, King Lear, Macbeth, Othello, Romeo and Juliet, and the history cycle defined English drama. His vocabulary and phrasing still structure the language.",
    source: "Literary history",
  },
  {
    id: "music-12",
    title: "Twelve-tone equal temperament",
    category: "language",
    keywords: ["music", "octave", "temperament", "semitone", "hz", "a440"],
    body: "Western common-practice music divides the octave into 12 equal semitones; frequency ratio of a semitone is 2^(1/12). Concert pitch A4 = 440 Hz (ISO 16). An octave doubles frequency. Harmony is built from stacked thirds (triads) and functional progression.",
    source: "Music theory / ISO 16",
  },
  {
    id: "cpu",
    title: "How a CPU works",
    category: "engineering",
    keywords: ["cpu", "processor", "alu", "pipeline", "instruction", "von neumann"],
    body: "A CPU fetches, decodes, and executes instructions. The von Neumann model shares memory for code and data. Pipelining overlaps stages; caches hide DRAM latency; branch predictors guess control flow. Performance is a product of clock, IPC, and energy, constrained by Dennard scaling's end and the memory wall.",
    source: "Computer architecture",
  },
  {
    id: "semiconductor",
    title: "Semiconductors and transistors",
    category: "engineering",
    keywords: ["transistor", "silicon", "semiconductor", "moore", "chip"],
    body: "Silicon doped with boron (p) or phosphorus (n) forms p–n junctions. The MOSFET is the switch of modern computing. Moore's law observed transistor density doubling roughly every two years; physical limits (leakage, heat, lithography) now force 3D stacking, chiplets, and specialized accelerators.",
    source: "Solid-state physics",
  },
  {
    id: "flight",
    title: "How airplanes fly",
    category: "engineering",
    keywords: ["airplane", "lift", "wing", "bernoulli", "aerodynamics"],
    body: "A wing produces lift by turning airflow downward (Newton's third law); the pressure difference (Bernoulli) is the same physics in another language. Four forces: lift, weight, thrust, drag. Control surfaces (aileron, elevator, rudder) change moments about the three axes.",
    source: "Aerodynamics",
  },
  {
    id: "gps",
    title: "GPS",
    category: "engineering",
    keywords: ["gps", "satellite", "navigation", "relativity", "gnss"],
    body: "GPS is a GNSS constellation of ~24+ MEO satellites broadcasting time-stamped signals. A receiver trilaterates position from four or more clocks. Relativistic corrections are mandatory: satellite clocks run faster by ~38 μs/day due to weaker gravity (GR) minus special-relativistic velocity delay. Without them, errors would accumulate kilometres per day.",
    source: "GPS ICD / relativity",
  },
  {
    id: "vaccine",
    title: "Vaccines",
    category: "medicine",
    keywords: ["vaccine", "immune", "antibody", "mrna", "immunization"],
    body: "Vaccines present antigen so the adaptive immune system forms memory B and T cells without causing the disease. Types: live attenuated, inactivated, subunit, toxoid, viral vector, mRNA. They are among the most effective public-health interventions (smallpox eradication, polio near-eradication). This is general information, not medical advice.",
    source: "WHO / immunology",
  },
  {
    id: "heart",
    title: "Human heart",
    category: "medicine",
    keywords: ["heart", "blood", "cardiac", "atrium", "ventricle", "pulse"],
    body: "The heart is a four-chamber pump: right atrium/ventricle send blood to the lungs; left atrium/ventricle send oxygenated blood to the body. A normal resting adult rate is about 60–100 beats per minute. The sinoatrial node is the pacemaker. This is general information, not medical advice.",
    source: "Anatomy",
  },
  {
    id: "french-rev",
    title: "French Revolution",
    category: "history",
    keywords: ["french", "revolution", "1789", "bastille", "napoleon"],
    body: "The French Revolution (1789–1799) overthrew the Bourbon monarchy, issued the Declaration of the Rights of Man, and entered the Terror before Napoleon Bonaparte's rise. It exported nationalism, metrication, and the idea of popular sovereignty across Europe.",
    source: "Modern European history",
  },
  {
    id: "moon",
    title: "The Moon",
    category: "astronomy",
    keywords: ["moon", "luna", "apollo", "tide", "satellite"],
    body: "The Moon is Earth's only natural satellite, mean distance ≈384,400 km, radius 1,737 km. It is tidally locked (same face). Apollo 11 landed 20 July 1969. Lunar tides arise because the Moon's gravity gradient stretches Earth. Giant-impact hypothesis: a Mars-sized body (Theia) struck early Earth, ejecting the Moon.",
    source: "NASA / planetary science",
  },
  {
    id: "ai",
    title: "Artificial intelligence",
    category: "cs",
    keywords: ["ai", "machine learning", "neural", "intelligence", "model"],
    body: "AI is the field of machines performing tasks that appear to require intelligence. Modern progress is dominated by statistical machine learning, especially deep neural networks trained by gradient descent on large datasets. It is not sentience; it is function approximation plus search. Capabilities and failure modes (hallucination, bias, distribution shift) must be evaluated empirically.",
    source: "ML textbooks",
  },
  {
    id: "entropy-info",
    title: "Information entropy",
    category: "cs",
    keywords: ["shannon", "entropy", "information", "bit", "compression"],
    body: "Shannon entropy H(X) = −Σ p(x) log₂ p(x) measures average surprise in bits. It is the lower bound on lossless compression. Mutual information I(X;Y) = H(X) − H(X|Y) measures shared information. Cross-entropy is the training loss of most classifiers and language models.",
    source: "Shannon 1948",
  },
  {
    id: "market",
    title: "Supply and demand",
    category: "history",
    keywords: ["economics", "supply", "demand", "price", "market", "equilibrium"],
    body: "In a competitive market, price tends toward the intersection of supply and demand. A surplus pushes prices down; a shortage pushes them up. Elasticity measures responsiveness. Real markets include frictions: monopoly power, externalities, information asymmetry, and public goods — the starting point of welfare economics.",
    source: "Microeconomics",
  },
  {
    id: "democracy",
    title: "Democracy",
    category: "history",
    keywords: ["democracy", "vote", "republic", "election", "athens"],
    body: "Democracy is rule by the people, typically via contested elections, civil liberties, and constraint of power. Classical Athens practiced direct democracy for citizens; modern states are mostly representative republics. Schumpeter's minimal definition: an institutional arrangement for arriving at political decisions by competitive struggle for the people's vote.",
    source: "Political theory",
  },
  {
    id: "language-family",
    title: "Indo-European languages",
    category: "language",
    keywords: ["indo-european", "language", "sanskrit", "latin", "germanic"],
    body: "Indo-European is the language family of most of Europe and much of South and West Asia: Germanic, Romance, Slavic, Indo-Iranian, Celtic, Greek, Albanian, Armenian, Baltic. Reconstructed Proto-Indo-European was likely spoken on the Pontic–Caspian steppe (Yamna hypothesis) in the 4th–3rd millennia BCE.",
    source: "Historical linguistics",
  },
  {
    id: "zero",
    title: "The number zero",
    category: "math",
    keywords: ["zero", "0", "placeholder", "brahmagupta", "nothing"],
    body: "Zero serves as both a placeholder in positional notation and a number in its own right. Babylonians used a placeholder; Indian mathematicians (Brahmagupta, 7th century) treated 0 as a number with arithmetic rules. It is the additive identity: x + 0 = x. Division by zero is undefined in the reals.",
    source: "History of mathematics",
  },
  {
    id: "set-theory",
    title: "Sets and infinity",
    category: "math",
    keywords: ["set", "cantor", "infinity", "cardinal", "aleph"],
    body: "Cantor showed infinities come in sizes: |ℕ| = ℵ₀, |ℝ| = 2^ℵ₀ = 𝔠. Cantor's theorem: |P(S)| > |S| for any set S. Continuum hypothesis (is 𝔠 = ℵ₁?) is independent of ZFC (Gödel, Cohen). Modern mathematics is routinely founded on Zermelo–Fraenkel set theory with choice.",
    source: "Set theory",
  },
  {
    id: "godel",
    title: "Gödel's incompleteness theorems",
    category: "math",
    keywords: ["godel", "incompleteness", "undecidable", "consistency", "arithmetic"],
    body: "Any consistent, recursively axiomatizable theory capable of expressing basic arithmetic is incomplete: there are true statements it cannot prove. The second theorem: such a theory cannot prove its own consistency. These results ended Hilbert's program of a complete finitary foundation for mathematics.",
    source: "Gödel 1931",
  },
  {
    id: "periodic-motion",
    title: "Simple harmonic motion",
    category: "physics",
    keywords: ["harmonic", "oscillator", "spring", "pendulum", "frequency"],
    body: "SHM: acceleration proportional to minus displacement, a = −ω²x. Solutions are sinusoids. Period of a mass-spring is T = 2π√(m/k); small-angle pendulum T ≈ 2π√(L/g). Fourier analysis decomposes general periodic signals into harmonic oscillators.",
    source: "Classical mechanics",
  },
  {
    id: "maxwell",
    title: "Maxwell's equations",
    category: "physics",
    keywords: ["maxwell", "electromagnetism", "gauss", "faraday", "ampere"],
    body: "Four equations unify electricity and magnetism: Gauss's law for E and B, Faraday's law, and the Ampère–Maxwell law. They imply electromagnetic waves at speed c = 1/√(ε₀μ₀). Light is an electromagnetic wave. Special relativity was partly motivated by the inconsistency of Maxwell with Galilean relativity.",
    source: "Maxwell 1865",
  },
  {
    id: "periodic-table-c",
    title: "Carbon",
    category: "chemistry",
    keywords: ["carbon", "organic", "diamond", "graphite", "covalent"],
    body: "Carbon (Z = 6) forms four covalent bonds, enabling the vast chemistry of life (organic chemistry). Allotropes: diamond (sp³), graphite/graphene (sp²), fullerenes, nanotubes. The carbon cycle moves C among atmosphere, biosphere, oceans, and crust.",
    source: "Inorganic / organic chemistry",
  },
  {
    id: "neuron",
    title: "Neurons and synapses",
    category: "biology",
    keywords: ["neuron", "brain", "synapse", "action potential", "axon"],
    body: "Neurons transmit information as action potentials — all-or-none voltage spikes — along axons, then chemically at synapses via neurotransmitters. The Hodgkin–Huxley model (1952) describes the ionic basis (Na⁺, K⁺). Brains compute with both spikes and synaptic weights, the inspiration for artificial neural nets (a loose analogy, not an identity).",
    source: "Neuroscience",
  },
  {
    id: "cell",
    title: "The cell",
    category: "biology",
    keywords: ["cell", "eukaryote", "prokaryote", "organelle", "membrane"],
    body: "The cell is the basic unit of life. Prokaryotes (bacteria, archaea) lack a nucleus; eukaryotes have membrane-bound organelles including a nucleus, mitochondria, and (in plants) chloroplasts. The plasma membrane is a phospholipid bilayer with proteins. All cells store hereditary information in nucleic acids and use ribosomes to make proteins.",
    source: "Cell biology",
  },
  {
    id: "metric",
    title: "SI units",
    category: "physics",
    keywords: ["si", "metric", "kilogram", "metre", "second", "units"],
    body: "The International System of Units has seven base units: second, metre, kilogram, ampere, kelvin, mole, candela. Since 2019 all are defined by fixing constants of nature (c, h, e, k, N_A, Δν_Cs, K_cd). Prefixes: k = 10³, M = 10⁶, m = 10⁻³, μ = 10⁻⁶, n = 10⁻⁹.",
    source: "BIPM SI Brochure",
  },
  {
    id: "logarithm",
    title: "Logarithms",
    category: "math",
    keywords: ["logarithm", "log", "ln", "exponent", "decibel"],
    body: "log_b(x) is the exponent to which b must be raised to obtain x. Natural log ln is log_e. Change of base: log_b(x) = ln x / ln b. They turn multiplication into addition, which is why they appear in complexity (log n), information theory (bits), and perception (decibels, magnitude scales).",
    source: "Algebra",
  },
  {
    id: "matrix",
    title: "Matrices and linear algebra",
    category: "math",
    keywords: ["matrix", "linear", "eigenvalue", "vector", "determinant"],
    body: "A matrix represents a linear map between vector spaces. Multiplication is composition of maps (non-commutative). Eigenvalues satisfy Av = λv. Determinants measure signed volume scaling; a matrix is invertible iff det ≠ 0. SVD decomposes any real matrix; it is the workhorse of PCA, recommendation, and numerical ML.",
    source: "Linear algebra",
  },
  {
    id: "probability",
    title: "Probability",
    category: "math",
    keywords: ["probability", "bayes", "random", "distribution", "statistics"],
    body: "Probability is a measure on events in [0, 1] obeying Kolmogorov's axioms. Conditional probability P(A|B) = P(A∩B)/P(B). Bayes' theorem: P(H|D) = P(D|H)P(H)/P(D). The law of large numbers and the central limit theorem explain why averages stabilize and why Gaussians appear so often.",
    source: "Probability theory",
  },
  {
    id: "compiler",
    title: "Compilers",
    category: "cs",
    keywords: ["compiler", "lexer", "parser", "ast", "codegen", "llvm"],
    body: "A compiler translates source to a target (often machine code) through lexing, parsing, semantic analysis, optimization, and code generation. Interpreters execute without a full ahead-of-time compile. LLVM and Cranelift are modern backend infrastructures. Aether in this workspace is a small interpreted language following the same pipeline.",
    source: "Dragon Book / LLVM",
  },
  {
    id: "unicode",
    title: "Unicode",
    category: "cs",
    keywords: ["unicode", "utf-8", "character", "emoji", "encoding"],
    body: "Unicode assigns a code point to every character (U+0000 to U+10FFFF). UTF-8 is a variable-width encoding compatible with ASCII: code points U+0000–U+007F are single bytes. It is the encoding of the web. A 'character' is not always one code point (grapheme clusters, combining marks).",
    source: "Unicode Consortium",
  },
  {
    id: "rel-db",
    title: "Relational databases",
    category: "cs",
    keywords: ["sql", "database", "relational", "codd", "join", "index"],
    body: "Codd's relational model stores data in tables (relations) with keys. SQL is the declarative query language: SELECT, JOIN, GROUP BY. ACID transactions (atomicity, consistency, isolation, durability) are the traditional contract. Indexes (B-trees, hashes) make lookups sublinear. Normalization reduces redundancy; denormalization trades it for read speed.",
    source: "Codd 1970",
  },
  {
    id: "os",
    title: "Operating systems",
    category: "cs",
    keywords: ["os", "kernel", "process", "thread", "scheduler", "linux"],
    body: "An OS multiplexes hardware among programs: process isolation, virtual memory, file systems, device drivers, and a scheduler. The kernel runs in privileged mode. Linux, Windows NT, and XNU (macOS) are the dominant general-purpose kernels. User programs talk to the kernel via system calls.",
    source: "OSTEP / Tanenbaum",
  },
  {
    id: "encryption",
    title: "Public-key cryptography",
    category: "cs",
    keywords: ["encryption", "rsa", "public key", "aes", "tls", "pgp"],
    body: "Symmetric ciphers (AES) use one shared key. Public-key (RSA, elliptic curves) uses a key pair: encrypt with the public, decrypt with the private; or sign with the private, verify with the public. TLS combines both: public-key handshake to establish a symmetric session key. Security rests on computational hardness, not secrecy of the algorithm (Kerckhoffs).",
    source: "Applied cryptography",
  },
  {
    id: "kepler",
    title: "Kepler's laws",
    category: "astronomy",
    keywords: ["kepler", "orbit", "ellipse", "planet", "period"],
    body: "1. Planets orbit in ellipses with the Sun at one focus. 2. Equal areas in equal times (conservation of angular momentum). 3. T² ∝ a³ (period squared proportional to semi-major axis cubed). Newton derived them from inverse-square gravity.",
    source: "Kepler / Newton",
  },
  {
    id: "periodic-waves",
    title: "Sound",
    category: "physics",
    keywords: ["sound", "wave", "frequency", "hz", "decibel", "air"],
    body: "Sound in air is a longitudinal pressure wave. Speed ≈343 m/s at 20 °C. Human hearing ≈20 Hz–20 kHz. Pitch tracks frequency; loudness tracks intensity on a logarithmic (decibel) scale. Timbre is the overtone spectrum.",
    source: "Acoustics",
  },
  {
    id: "color",
    title: "Color and light",
    category: "physics",
    keywords: ["color", "rgb", "wavelength", "cone", "srgb"],
    body: "Visible light is electromagnetic radiation ≈400–700 nm. Human color vision is trichromatic (S, M, L cones). Displays mix red, green, and blue primaries (additive). Pigments mix subtractively (CMY). sRGB is the default web color space; hex #RRGGBB encodes 8-bit channels.",
    source: "Color science",
  },
  {
    id: "map-proj",
    title: "Map projections",
    category: "earth",
    keywords: ["map", "mercator", "projection", "gis", "latitude"],
    body: "You cannot flatten a sphere without distortion (Gauss's theorema egregium). Mercator preserves angles (useful for sailing) but inflates high latitudes. Equal-area projections (Gall–Peters, Mollweide) preserve area at the cost of shape. Choose the projection for the question.",
    source: "Cartography",
  },
  {
    id: "time-zones",
    title: "Time and time zones",
    category: "earth",
    keywords: ["time", "utc", "timezone", "leap", "second", "calendar"],
    body: "Civil time is UTC plus an offset. UTC tracks atomic time (TAI) with leap seconds to stay near Earth rotation (UT1). A day is 86,400 SI seconds except when a leap second is inserted. ISO 8601 writes timestamps as 2026-08-25T00:00:00Z.",
    source: "IERS / ISO 8601",
  },
  {
    id: "meridian-geo",
    title: "Meridian (geography)",
    category: "earth",
    keywords: ["meridian", "longitude", "greenwich", "prime", "latitude"],
    body: "A meridian is a half great-circle from pole to pole — a line of constant longitude. The prime meridian (0°) was internationally agreed at Greenwich in 1884. Longitude east or west of it, with latitude, specifies a position on Earth. Local solar noon occurs when the Sun crosses the local meridian.",
    source: "Geodesy / IERS",
  },
  {
    id: "factor-example",
    title: "Integer factorization",
    category: "math",
    keywords: ["factor", "factorization", "123456789", "composite"],
    body: "Every integer greater than 1 factors uniquely into primes (fundamental theorem of arithmetic). Example: 123,456,789 = 3² × 3,607 × 3,803. Trial division up to √n is enough for 64-bit integers; cryptographic moduli (RSA) are products of two large primes chosen so that factoring is intractable with known classical algorithms.",
    source: "Number theory",
  },
];

const STOP = new Set(
  "a an the of to in on for and or is are was were be been being what who whom which that this those these how why when where who what is are do does did can could should would will with from about into over after before than then also not no yes it its it's you your we our they their as at by if so such just than".split(
    " ",
  ),
);

export function tokenizeQuery(q: string): string[] {
  return q
    .toLowerCase()
    .replace(/[^a-z0-9+.\-]+/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP.has(w));
}

export function searchKnowledge(query: string, limit = 6): { entry: KnowledgeEntry; score: number }[] {
  const q = query.trim();
  if (!q) return [];
  const tokens = tokenizeQuery(q);
  const ql = q.toLowerCase();
  const scored = KNOWLEDGE.map((entry) => {
    let score = 0;
    const title = entry.title.toLowerCase();
    const body = entry.body.toLowerCase();
    if (title === ql) score += 12;
    if (ql.includes(title) || title.includes(ql)) score += 6;
    for (const kw of entry.keywords) {
      if (ql.includes(kw) || kw.includes(ql)) score += 3.5;
      if (tokens.includes(kw)) score += 2;
    }
    let hit = 0;
    for (const t of tokens) {
      if (title.includes(t)) {
        score += 2.4;
        hit++;
      }
      if (entry.keywords.some((k) => k.includes(t) || t.includes(k))) {
        score += 1.6;
        hit++;
      }
      if (body.includes(t)) {
        score += 0.45;
        hit++;
      }
    }
    if (tokens.length) score += (hit / tokens.length) * 2;
    if (entry.category && ql.includes(entry.category)) score += 0.8;
    return { entry, score };
  })
    .filter((x) => x.score >= 2.2)
    .sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}

export function bestKnowledge(query: string): { entry: KnowledgeEntry; score: number } | null {
  const hits = searchKnowledge(query, 1);
  const top = hits[0];
  if (!top || top.score < 4.5) return null;
  return top;
}

export const CATEGORIES = [...new Set(KNOWLEDGE.map((k) => k.category))];
