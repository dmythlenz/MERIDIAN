import { Fragment, type ReactNode } from "react";

function inline(text: string): ReactNode[] {
  const parts: ReactNode[] = [];
  const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\([^)]+\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("`")) {
      parts.push(
        <code key={i++} className="rounded-sm bg-elevated px-1 py-px font-mono text-[0.85em] text-accent">
          {tok.slice(1, -1)}
        </code>,
      );
    } else if (tok.startsWith("**")) {
      parts.push(
        <strong key={i++} className="font-medium text-fg">
          {inline(tok.slice(2, -2))}
        </strong>,
      );
    } else if (tok.startsWith("*")) {
      parts.push(
        <em key={i++} className="italic">
          {inline(tok.slice(1, -1))}
        </em>,
      );
    } else {
      const lm = tok.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
      if (lm) {
        const href = lm[2].startsWith("http") ? lm[2] : "#";
        parts.push(
          <a key={i++} href={href} target="_blank" rel="noreferrer" className="text-accent underline-offset-2 hover:underline">
            {lm[1]}
          </a>,
        );
      }
    }
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

export function Markdown({ text }: { text: string }) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const nodes: ReactNode[] = [];
  let i = 0;
  let key = 0;
  while (i < lines.length) {
    const line = lines[i] ?? "";
    if (line.startsWith("```")) {
      const lang = line.slice(3).trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i]!.startsWith("```")) {
        buf.push(lines[i]!);
        i++;
      }
      i++;
      nodes.push(
        <pre key={key++} className="my-3 overflow-x-auto rounded-lg bg-code px-3.5 py-3 font-mono text-xs leading-relaxed text-fg">
          {lang ? <div className="mb-2 text-micro uppercase tracking-wider text-subtle">{lang}</div> : null}
          <code>{buf.join("\n")}</code>
        </pre>,
      );
      continue;
    }
    if (/^#{1,3}\s/.test(line)) {
      const level = line.match(/^#+/)![0].length;
      const cls =
        level === 1
          ? "mt-4 mb-2 font-display text-xl text-fg"
          : level === 2
            ? "mt-3 mb-1.5 font-display text-lg text-fg"
            : "mt-3 mb-1 text-sm font-medium text-fg";
      nodes.push(
        <div key={key++} className={cls}>
          {inline(line.replace(/^#+\s/, ""))}
        </div>,
      );
      i++;
      continue;
    }
    if (/^[-*]\s/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*]\s/.test(lines[i] ?? "")) {
        items.push((lines[i] ?? "").replace(/^[-*]\s/, ""));
        i++;
      }
      nodes.push(
        <ul key={key++} className="my-2 list-disc space-y-1 pl-5 text-prose leading-relaxed">
          {items.map((it, idx) => (
            <li key={idx}>{inline(it)}</li>
          ))}
        </ul>,
      );
      continue;
    }
    if (/^\d+\.\s/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i] ?? "")) {
        items.push((lines[i] ?? "").replace(/^\d+\.\s/, ""));
        i++;
      }
      nodes.push(
        <ol key={key++} className="my-2 list-decimal space-y-1 pl-5 text-prose leading-relaxed">
          {items.map((it, idx) => (
            <li key={idx}>{inline(it)}</li>
          ))}
        </ol>,
      );
      continue;
    }
    if (line.startsWith("> ")) {
      const buf: string[] = [];
      while (i < lines.length && (lines[i] ?? "").startsWith("> ")) {
        buf.push((lines[i] ?? "").slice(2));
        i++;
      }
      nodes.push(
        <blockquote key={key++} className="my-2 border-l-2 border-border pl-3 text-muted">
          {buf.map((b, idx) => (
            <p key={idx}>{inline(b)}</p>
          ))}
        </blockquote>,
      );
      continue;
    }
    if (!line.trim()) {
      i++;
      continue;
    }
    const buf: string[] = [line];
    i++;
    while (
      i < lines.length &&
      lines[i]?.trim() &&
      !/^#{1,3}\s/.test(lines[i]!) &&
      !/^[-*]\s/.test(lines[i]!) &&
      !/^\d+\.\s/.test(lines[i]!) &&
      !lines[i]!.startsWith("```") &&
      !lines[i]!.startsWith("> ")
    ) {
      buf.push(lines[i]!);
      i++;
    }
    nodes.push(
      <p key={key++} className="my-2 text-prose leading-relaxed text-pretty text-fg">
        {buf.map((b, idx) => (
          <Fragment key={idx}>
            {idx ? " " : null}
            {inline(b)}
          </Fragment>
        ))}
      </p>,
    );
  }
  return <div className="markdown min-w-0">{nodes}</div>;
}
