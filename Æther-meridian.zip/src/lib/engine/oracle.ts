import { addrKey } from "./address";
import { runAether, AETHER_HELP } from "./aether";
import { bestKnowledge, searchKnowledge, KNOWLEDGE, CATEGORIES } from "./knowledge";
import { routeExpert, EXPERTS } from "./experts";
import { fabric } from "./fabric";
import { pixels } from "./pixels";
import { WAL } from "./wal";
import { wikiSearch } from "./wiki";
import { askGrok, type ChatTurn } from "@/lib/ai/grok";
import { Hash } from "./hash";

export type ModelId = "auto" | "grok" | "oracle" | "aether" | "expert";

export type AskOpts = {
  model: ModelId;
  think?: boolean;
  search?: boolean;
  history?: ChatTurn[];
  grokOn?: boolean;
};

export type AskResult = {
  ok: boolean;
  text: string;
  kind: string;
  cached?: boolean;
  ms: number;
  sources?: string[];
  error?: string;
};

const responseCache = new Map<string, string>();
const MAX_CACHE = 400;

function cacheSet(key: string, val: string) {
  responseCache.set(key, val);
  if (responseCache.size > MAX_CACHE) {
    const first = responseCache.keys().next().value;
    if (first) responseCache.delete(first);
  }
}

export function cacheStats() {
  return { size: responseCache.size };
}

function formatEntry(title: string, body: string, source?: string) {
  return `**${title}**\n\n${body}${source ? `\n\n— ${source}` : ""}`;
}

function localMath(query: string): string | null {
  const q = query.trim();
  const factor = q.match(/^(?:factor|factorize|prime factors?(?: of)?)\s+(-?\d+)\s*\??$/i);
  if (factor) {
    const n = Number(factor[1]);
    const r = runAether(`print(join(factor(${n}), " × "))`);
    return r.ok ? `**${n}** = ${r.output[0] || n}` : null;
  }
  const fib = q.match(/^(?:fibonacci|fib)\s+(\d+)\s*\??$/i);
  if (fib) {
    const n = Number(fib[1]);
    if (n > 80) return "Fibonacci index capped at 80 in the local engine.";
    const r = runAether(`print(fib(${n}))`);
    return r.ok ? `F(${n}) = ${r.output[0]}` : null;
  }
  const prime = q.match(/^(?:is\s+)?(\d+)\s+(?:prime|a prime)\??$/i) || q.match(/^isPrime\s+(\d+)/i);
  if (prime) {
    const n = Number(prime[1]);
    const r = runAether(`print(isPrime(${n}))`);
    return r.ok ? `${n} is ${r.output[0] === "true" ? "" : "not "}prime.` : null;
  }
  if (/^help\s*$/i.test(q) || q === "?") return null;
  const expr = q.match(/^(?:what(?:'s| is)|compute|calc(?:ulate)?|eval)\s+(.+?)\??$/i);
  const raw = expr ? expr[1] : /^(?:[\d.+\-*/^()%\s]+|[a-z]+\([^)]*\))$/i.test(q) ? q : null;
  if (raw && /[\d)]/.test(raw) && !/[a-z]{4,}/i.test(raw.replace(/sin|cos|tan|sqrt|abs|pow|pi|log|exp/gi, ""))) {
    const code = raw.replace(/\bpi\b/gi, "PI").replace(/\^/g, "^");
    const r = runAether(`print(${code})`);
    if (r.ok && r.output[0] && r.output[0] !== "undefined") return `= ${r.output[0]}`;
  }
  return null;
}

function pixelHits(query: string): string[] {
  return pixels
    .search(query)
    .slice(0, 3)
    .filter((p) => p.kind !== "chat")
    .map((p) => `(${p.kind}) ${p.title}: ${p.text.slice(0, 600)}`);
}

export async function askOracle(query: string, opts: AskOpts): Promise<AskResult> {
  const t0 = performance.now();
  const q = query.trim();
  if (!q) return { ok: false, text: "", kind: "error", ms: 0, error: "Empty query" };

  fabric.shot(q);
  WAL.push("ask", { q: q.slice(0, 200), model: opts.model });
  const key = addrKey(`${opts.model}|${opts.think ? 1 : 0}|${opts.search ? 1 : 0}|${q}`);
  const cached = responseCache.get(key);
  if (cached && opts.model !== "aether") {
    return { ok: true, text: cached, kind: "cache", cached: true, ms: performance.now() - t0, sources: ["cache"] };
  }

  const finish = (text: string, kind: string, sources?: string[]): AskResult => {
    cacheSet(key, text);
    pixels.set({ key: `ans:${key.slice(0, 12)}`, title: q.slice(0, 72), text, kind: "chat" });
    return { ok: true, text, kind, ms: performance.now() - t0, sources };
  };

  if (q.startsWith("run:") || opts.model === "aether") {
    const code = q.startsWith("run:") ? q.slice(4).trim() : q;
    const r = runAether(code);
    if (!r.ok) return { ok: false, text: r.error || "Aether error", kind: "aether", ms: r.ms, error: r.error };
    const out = r.output.length ? r.output.join("\n") : stringifyVal(r.value);
    return finish("```\n" + (out || "(no output)") + "\n```", "aether", ["aether"]);
  }

  const math = localMath(q);
  if (math && (opts.model === "auto" || opts.model === "oracle")) {
    return finish(math, "oracle", ["lattice"]);
  }

  const kb = bestKnowledge(q);
  const related = searchKnowledge(q, 4);
  const expert = routeExpert(q);
  const storeHits = pixelHits(q);

  if (opts.model === "oracle") {
    if (kb) return finish(formatEntry(kb.entry.title, kb.entry.body, kb.entry.source), "oracle", ["lattice"]);
    if (related[0]) {
      const e = related[0].entry;
      return finish(formatEntry(e.title, e.body, e.source), "oracle", ["lattice"]);
    }
    return {
      ok: true,
      text: "No grounded lattice entry for that query. Switch to Auto or Grok, or ingest a note in Workspace.",
      kind: "oracle",
      ms: performance.now() - t0,
      sources: [],
    };
  }

  if (opts.model === "expert") {
    if (!expert) {
      return {
        ok: true,
        text: "No expert claimed this query. Try a domain word (physics, math, biology, code) or switch to Auto.",
        kind: "expert",
        ms: performance.now() - t0,
      };
    }
    const bits = expert.hits.map((h) => formatEntry(h.title, h.body, h.source));
    const head = `**${expert.expert.name}** · ${expert.expert.domain}\n${expert.expert.blurb}\n`;
    const body = bits.length ? bits.join("\n\n") : "No lattice notes in this domain for that wording.";
    return finish(head + "\n" + body, "expert", [expert.expert.name]);
  }

  let wiki: { title: string; extract: string; url?: string } | null = null;
  if (opts.search) {
    wiki = await wikiSearch(q);
    if (wiki) {
      pixels.set({
        key: `wiki:${wiki.title}`,
        title: wiki.title,
        text: wiki.extract,
        kind: "wiki",
        meta: wiki.url ? { url: wiki.url } : undefined,
      });
    }
  }

  const contextParts: string[] = [];
  if (kb) contextParts.push(`Lattice: ${kb.entry.title}\n${kb.entry.body}\nSource: ${kb.entry.source}`);
  for (const h of related.slice(0, 3)) {
    if (h.entry.id === kb?.entry.id) continue;
    contextParts.push(`${h.entry.title}: ${h.entry.body}`);
  }
  if (wiki) contextParts.push(`Wikipedia (${wiki.title}): ${wiki.extract}${wiki.url ? "\n" + wiki.url : ""}`);
  if (storeHits.length) contextParts.push("Workspace notes:\n" + storeHits.join("\n"));
  if (expert) contextParts.push(`Routed expert: ${expert.expert.name} (${expert.expert.domain})`);

  const wantGrok = opts.model === "grok" || (opts.model === "auto" && opts.grokOn !== false);
  const grokNeeded = opts.model === "grok" || opts.think || !kb || (kb && kb.score < 8) || opts.search;

  if (wantGrok && grokNeeded) {
    const grok = await askGrok({
      data: {
        prompt: q,
        context: contextParts.join("\n\n---\n\n"),
        think: opts.think,
        history: opts.history,
      },
    });
    if (grok.ok) {
      const sources = [
        kb ? "lattice" : null,
        wiki ? "wikipedia" : null,
        "grok-4.5",
        expert ? expert.expert.name : null,
      ].filter(Boolean) as string[];
      return finish(grok.text, opts.think ? "think" : "grok", sources);
    }
    if (opts.model === "grok") {
      return { ok: false, text: grok.error || "Grok unavailable", kind: "error", ms: performance.now() - t0, error: grok.error };
    }
  }

  if (kb) return finish(formatEntry(kb.entry.title, kb.entry.body, kb.entry.source), "oracle", ["lattice"]);
  if (wiki) {
    return finish(
      formatEntry(wiki.title, wiki.extract, wiki.url || "Wikipedia"),
      "wiki",
      ["wikipedia"],
    );
  }
  if (related[0] && related[0].score >= 3) {
    const e = related[0].entry;
    return finish(formatEntry(e.title, e.body, e.source), "oracle", ["lattice"]);
  }

  return {
    ok: true,
    text: "I don't have a grounded local answer, and live reasoning is unavailable. Try a lattice topic (light, DNA, primes, HTTP), run Aether with `run:`, or attach a note in Workspace.",
    kind: "oracle",
    ms: performance.now() - t0,
  };
}

function stringifyVal(v: unknown): string {
  if (v === undefined) return "";
  if (typeof v === "string") return v;
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

export function handleCommand(raw: string, grokOn: boolean): Promise<AskResult> | AskResult | null {
  if (!raw.startsWith("/")) return null;
  const [cmd, ...rest] = raw.slice(1).trim().split(/\s+/);
  const args = rest.join(" ");
  const t0 = performance.now();
  const ok = (text: string, kind = "cmd"): AskResult => ({ ok: true, text, kind, ms: performance.now() - t0 });

  switch ((cmd || "").toLowerCase()) {
    case "help":
      return ok(
        [
          "**Meridian** — grounded intelligence workspace",
          "",
          "**Models:** Auto, Grok, Oracle, Aether, Expert",
          "",
          "**Chat**",
          "Plain language queries. Auto uses the lattice first, then Grok 4.5 with retrieved context.",
          "`run: <code>` — execute Aether",
          "Toggle Deep Think or Search (Wikipedia) on the composer.",
          "",
          "**Commands**",
          "/help — this list",
          "/aether <code> — run Aether",
          "/factor <n> — prime factorization",
          "/wiki <topic> — ingest a Wikipedia summary",
          "/prove <claim> — hash a notary proof",
          "/experts — list domain experts",
          "/lattice — knowledge stats",
          "/status — engine snapshot",
          "/reset confirm — wipe local memory",
          "",
          AETHER_HELP,
        ].join("\n"),
      );
    case "aether": {
      const r = runAether(args || 'print("Meridian")');
      if (!r.ok) return { ok: false, text: r.error || "error", kind: "aether", ms: r.ms, error: r.error };
      return ok("```\n" + (r.output.join("\n") || stringifyVal(r.value) || "(no output)") + "\n```", "aether");
    }
    case "factor": {
      const n = Number(args.replace(/[^\d-]/g, ""));
      if (!Number.isFinite(n)) return ok("Usage: /factor 123456789");
      const r = runAether(`print(join(factor(${n}), " × "))`);
      return ok(`**${n}** = ${r.output[0]}`);
    }
    case "experts":
      return ok(
        EXPERTS.map((e) => `**${e.name}** · ${e.domain} — ${e.blurb}`).join("\n\n"),
      );
    case "lattice":
      return ok(
        `Lattice entries: **${KNOWLEDGE.length}**\nCategories: ${CATEGORIES.join(", ")}\nCache: ${responseCache.size}\nPixels: ${pixels.stats().count}`,
      );
    case "status":
      return ok(
        JSON.stringify(
          {
            grok: grokOn,
            lattice: KNOWLEDGE.length,
            experts: EXPERTS.length,
            fabric: fabric.stats(),
            wal: WAL.entries.length,
            pixels: pixels.stats(),
            cache: responseCache.size,
          },
          null,
          2,
        ),
      );
    case "prove": {
      if (!args) return ok("Usage: /prove <claim>");
      const ts = Date.now();
      const proofHash = Hash.h64(args + ts);
      WAL.push("prove", { claim: args, proofHash });
      pixels.set({ key: `proof:${proofHash}`, title: args.slice(0, 80), text: proofHash, kind: "proof" });
      return ok(`Notary proof\n\nClaim: ${args}\nHash: \`${proofHash}\`\nTime: ${new Date(ts).toISOString()}`);
    }
    case "wiki":
      return (async () => {
        const hit = await wikiSearch(args || "Meridian (geography)");
        if (!hit) return { ok: false, text: "No Wikipedia extract.", kind: "wiki", ms: performance.now() - t0, error: "miss" };
        pixels.set({ key: `wiki:${hit.title}`, title: hit.title, text: hit.extract, kind: "wiki" });
        return ok(formatEntry(hit.title, hit.extract, hit.url || "Wikipedia"), "wiki");
      })();
    case "reset":
      if (args !== "confirm") return ok("Type `/reset confirm` to wipe local cache, pixels, and WAL.");
      responseCache.clear();
      pixels.items.clear();
      pixels.persist();
      WAL.clear();
      return ok("Local memory wiped.");
    default:
      return ok(`Unknown command \`/${cmd}\`. Try /help.`);
  }
}

export function notaryProve(claim: string, answer: string) {
  const ts = Date.now();
  const proofHash = Hash.h64(claim + answer + ts);
  WAL.push("prove", { claim, proofHash });
  return { proofHash, ts };
}
