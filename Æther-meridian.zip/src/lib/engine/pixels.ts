import { Hash } from "./hash";
import { addrKey } from "./address";
import { safeJsonParse } from "@/lib/utils";

export type Pixel = {
  key: string;
  addr: string;
  title: string;
  text: string;
  kind: "note" | "file" | "wiki" | "chat" | "proof" | "code";
  ts: number;
  size: number;
  meta?: Record<string, string | number | boolean>;
};

const KEY = "meridian.pixels";
const MAX = 200;

class PixelStore {
  items = new Map<string, Pixel>();

  load() {
    const raw = typeof localStorage === "undefined" ? null : localStorage.getItem(KEY);
    const list = safeJsonParse<Pixel[]>(raw, []);
    this.items = new Map(list.map((p) => [p.key, p]));
  }

  persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify([...this.items.values()].slice(-MAX)));
    } catch {
      /* quota */
    }
  }

  set(partial: Omit<Pixel, "addr" | "size" | "ts"> & { ts?: number }): Pixel {
    const pixel: Pixel = {
      ...partial,
      addr: addrKey(partial.key),
      size: partial.text.length,
      ts: partial.ts ?? Date.now(),
    };
    this.items.set(pixel.key, pixel);
    if (this.items.size > MAX) {
      const oldest = [...this.items.values()].sort((a, b) => a.ts - b.ts)[0];
      if (oldest) this.items.delete(oldest.key);
    }
    this.persist();
    return pixel;
  }

  get(key: string) {
    return this.items.get(key) ?? null;
  }

  delete(key: string) {
    this.items.delete(key);
    this.persist();
  }

  list(): Pixel[] {
    return [...this.items.values()].sort((a, b) => b.ts - a.ts);
  }

  search(q: string): Pixel[] {
    const s = q.toLowerCase();
    if (!s) return this.list();
    return this.list().filter(
      (p) =>
        p.title.toLowerCase().includes(s) ||
        p.text.toLowerCase().includes(s) ||
        p.kind.includes(s) ||
        p.key.toLowerCase().includes(s),
    );
  }

  stats() {
    const list = this.list();
    return {
      count: list.length,
      bytes: list.reduce((a, p) => a + p.size, 0),
      hash: Hash.h64(list.map((p) => p.addr).join("|")),
    };
  }
}

export const pixels = new PixelStore();
