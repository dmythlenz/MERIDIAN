import { askOracle, handleCommand } from "./oracle";
import { useMeridian } from "@/lib/store";
import { toast } from "sonner";

export async function sendQuery(text: string) {
  const q = text.trim();
  if (!q) return;
  const store = useMeridian.getState();
  if (store.busy) return;
  store.pushUser(q);
  store.setBusy(true);
  store.termLog("in", q);
  try {
    const cmd = handleCommand(q, store.grokOn);
    const conv = useMeridian.getState().current();
    const history = (conv?.msgs ?? [])
      .filter((m) => m.role === "user" || m.role === "assistant")
      .slice(-8)
      .map((m) => ({ role: m.role as "user" | "assistant", content: m.text }));
    const result = cmd
      ? await cmd
      : await askOracle(q, {
          model: store.settings.model,
          think: store.settings.think,
          search: store.settings.search,
          history,
          grokOn: store.grokOn,
        });
    if (!result.ok) {
      store.pushAssistant({
        text: result.error || result.text || "Something went wrong.",
        kind: "error",
        ms: result.ms,
      });
      store.termLog("err", result.error || result.text);
      if (/quota|not authorized|not available/i.test(result.error || result.text)) {
        store.setGrokOn(false);
      }
      return;
    }
    store.pushAssistant({
      text: result.text,
      kind: result.kind,
      cached: result.cached,
      ms: result.ms,
      sources: result.sources,
    });
    store.termLog("ok", `${result.kind} · ${Math.round(result.ms)}ms`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    store.pushAssistant({ text: msg, kind: "error" });
    toast.error(msg);
    store.termLog("err", msg);
  } finally {
    store.setBusy(false);
  }
}
