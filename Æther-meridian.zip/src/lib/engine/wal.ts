import { Hash } from "./hash";
import { safeJsonParse } from "@/lib/utils";

export type WalEntry = {
  ts: number;
  op: string;
  data: unknown;
  hash: string;
};

const KEY = "meridian.wal";
const MAX = 800;

class WriteAheadLog {
  entries: WalEntry[] = [];

  load() {
    this.entries = safeJsonParse<WalEntry[]>(
      typeof localStorage === "undefined" ? null : localStorage.getItem(KEY),
      [],
    );
  }

  persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.entries.slice(-240)));
    } catch {
      /* quota */
    }
  }

  push(op: string, data: unknown): WalEntry {
    const ts = Date.now();
    const entry: WalEntry = {
      ts,
      op,
      data,
      hash: Hash.h64(op + JSON.stringify(data) + ts),
    };
    this.entries.push(entry);
    if (this.entries.length > MAX) this.entries.splice(0, this.entries.length - MAX);
    this.persist();
    return entry;
  }

  queryAt(ts: number): WalEntry[] {
    return this.entries.filter((e) => e.ts <= ts);
  }

  clear() {
    this.entries = [];
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
  }
}

export const WAL = new WriteAheadLog();
