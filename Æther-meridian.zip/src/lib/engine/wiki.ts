export type WikiHit = {
  title: string;
  extract: string;
  url?: string;
  description?: string;
};

export async function wikiSearch(query: string): Promise<WikiHit | null> {
  const q = query.trim();
  if (!q) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const open = await fetch(
      `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=1&namespace=0&format=json&origin=*`,
      { signal: ctrl.signal },
    );
    if (!open.ok) throw new Error("opensearch");
    const data = (await open.json()) as [string, string[], string[], string[]];
    const title = data[1]?.[0];
    if (!title) return null;
    const sum = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`,
      { signal: ctrl.signal, headers: { Accept: "application/json" } },
    );
    if (!sum.ok) throw new Error("summary");
    const j = (await sum.json()) as {
      title?: string;
      extract?: string;
      description?: string;
      content_urls?: { desktop?: { page?: string } };
    };
    const extract = (j.extract || "").trim();
    if (!extract) return null;
    return {
      title: j.title || title,
      extract,
      description: j.description,
      url: j.content_urls?.desktop?.page,
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
