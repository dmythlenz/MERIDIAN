import { create } from "zustand";
import { uid, safeJsonParse } from "@/lib/utils";
import type { ModelId } from "@/lib/engine/oracle";
import { WAL } from "@/lib/engine/wal";
import { pixels } from "@/lib/engine/pixels";

export type ViewId = "chat" | "lattice" | "fabric" | "workspace" | "terminal";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  kind?: string;
  cached?: boolean;
  ms?: number;
  sources?: string[];
  ts: number;
};

export type Conversation = {
  id: string;
  title: string;
  msgs: ChatMessage[];
  ts: number;
};

export type TermLine = { id: string; kind: "in" | "out" | "err" | "ok"; text: string };

type Settings = {
  theme: "dark" | "light";
  think: boolean;
  search: boolean;
  model: ModelId;
};

type State = {
  ready: boolean;
  grokOn: boolean;
  view: ViewId;
  sidebarOpen: boolean;
  settingsOpen: boolean;
  paletteOpen: boolean;
  settings: Settings;
  history: Conversation[];
  currentId: string | null;
  busy: boolean;
  bootAt: number;
  term: TermLine[];
  setView: (v: ViewId) => void;
  setSidebar: (open: boolean) => void;
  setSettingsOpen: (open: boolean) => void;
  setPaletteOpen: (open: boolean) => void;
  setGrokOn: (on: boolean) => void;
  patchSettings: (p: Partial<Settings>) => void;
  current: () => Conversation | null;
  newChat: () => void;
  loadChat: (id: string) => void;
  deleteChat: (id: string) => void;
  clearHistory: () => void;
  pushUser: (text: string) => Conversation;
  pushAssistant: (msg: Omit<ChatMessage, "id" | "role" | "ts">) => void;
  setBusy: (b: boolean) => void;
  termLog: (kind: TermLine["kind"], text: string) => void;
  hydrate: () => void;
};

const HIST_KEY = "meridian.history";
const SET_KEY = "meridian.settings";

function persistHistory(history: Conversation[]) {
  try {
    localStorage.setItem(HIST_KEY, JSON.stringify(history.slice(0, 40)));
  } catch {
    /* quota */
  }
}
function persistSettings(s: Settings) {
  try {
    localStorage.setItem(SET_KEY, JSON.stringify(s));
  } catch {
    /* quota */
  }
}

export const useMeridian = create<State>((set, get) => ({
  ready: false,
  grokOn: false,
  view: "chat",
  sidebarOpen: false,
  settingsOpen: false,
  paletteOpen: false,
  settings: { theme: "dark", think: false, search: false, model: "auto" },
  history: [],
  currentId: null,
  busy: false,
  bootAt: Date.now(),
  term: [],
  setView: (view) => set({ view, sidebarOpen: false }),
  setSidebar: (sidebarOpen) => set({ sidebarOpen }),
  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
  setPaletteOpen: (paletteOpen) => set({ paletteOpen }),
  setGrokOn: (grokOn) => set({ grokOn }),
  patchSettings: (p) => {
    const settings = { ...get().settings, ...p };
    persistSettings(settings);
    if (p.theme) {
      document.documentElement.setAttribute("data-theme", settings.theme);
    }
    set({ settings });
  },
  current: () => get().history.find((c) => c.id === get().currentId) ?? null,
  newChat: () => {
    const conv: Conversation = { id: uid("c"), title: "New query", msgs: [], ts: Date.now() };
    const history = [conv, ...get().history];
    persistHistory(history);
    set({ history, currentId: conv.id, view: "chat", sidebarOpen: false });
  },
  loadChat: (id) => set({ currentId: id, view: "chat", sidebarOpen: false }),
  deleteChat: (id) => {
    const history = get().history.filter((c) => c.id !== id);
    persistHistory(history);
    set({ history, currentId: get().currentId === id ? (history[0]?.id ?? null) : get().currentId });
  },
  clearHistory: () => {
    persistHistory([]);
    set({ history: [], currentId: null });
  },
  pushUser: (text) => {
    let { history, currentId } = get();
    let conv = history.find((c) => c.id === currentId);
    if (!conv) {
      conv = { id: uid("c"), title: text.slice(0, 42), msgs: [], ts: Date.now() };
      history = [conv, ...history];
      currentId = conv.id;
    }
    if (conv.title === "New query") conv = { ...conv, title: text.slice(0, 42) };
    const msg: ChatMessage = { id: uid("m"), role: "user", text, ts: Date.now() };
    conv = { ...conv, msgs: [...conv.msgs, msg], ts: Date.now() };
    history = history.map((c) => (c.id === conv!.id ? conv! : c));
    persistHistory(history);
    set({ history, currentId });
    return conv;
  },
  pushAssistant: (partial) => {
    const { history, currentId } = get();
    const conv = history.find((c) => c.id === currentId);
    if (!conv) return;
    const msg: ChatMessage = { id: uid("m"), role: "assistant", ts: Date.now(), ...partial };
    const next = { ...conv, msgs: [...conv.msgs, msg], ts: Date.now() };
    const hist = history.map((c) => (c.id === next.id ? next : c));
    persistHistory(hist);
    set({ history: hist });
  },
  setBusy: (busy) => set({ busy }),
  termLog: (kind, text) =>
    set({ term: [...get().term, { id: uid("t"), kind, text }].slice(-400) }),
  hydrate: () => {
    try {
      WAL.load();
      pixels.load();
      const settings = safeJsonParse<Settings>(
        typeof localStorage === "undefined" ? null : localStorage.getItem(SET_KEY),
        get().settings,
      );
      const history = safeJsonParse<Conversation[]>(
        typeof localStorage === "undefined" ? null : localStorage.getItem(HIST_KEY),
        [],
      );
      document.documentElement.setAttribute("data-theme", settings.theme);
      set({
        ready: true,
        settings,
        history,
        currentId: history[0]?.id ?? null,
        bootAt: Date.now(),
      });
    } catch {
      set({ ready: true, bootAt: Date.now() });
    }
  },
}));
